import { IConfigurationTemplate } from "../../../../actions/criteria/models";

export default interface IEngineConfigTabProps {
  selectedParams: IPipeline;
  template: IConfigurationTemplate;
  isEditable: boolean;
  analysisId: string;
  analysisVersion: number;
  horizonServices: any;
}
