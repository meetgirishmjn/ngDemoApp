import React from "react";
import { filterDataByPrescs, filterDataByBlups } from "./helper";
import { IResultData } from "../../../models/IResults";

const colNames = ["Col1"];

const prescData: IResultData = {
  data: {
    run: {
      keys: [
        {
          key: [
            {
              name: "LINE_NAME",
              value: "A1",
            },
          ],
          values: [
            {
              column: "PRESC",
              numvalue: 0,
              strvalue: "rejected",
              uom: "",
            },
          ],
        },
        // no string value
        {
            key: [
              {
                name: "LINE_NAME",
                value: "A1",
              },
            ],
            values: [
              {
                column: "PRESC",
                numvalue: 1,
                strvalue: "",
                uom: "",
              },
            ],
          },
        {
          key: [
            {
              name: "LINE_NAME",
              value: "A2",
            },
          ],
          values: [
            {
              column: "PRESC",
              numvalue: 0,
              strvalue: "recommended",
              uom: "",
            },
          ],
        },
      ],
    },
  },
};

describe("Helpers", () => {
  it("test get allResults data", async () => {
    jest.mock("../../../actions/results/advanceActions", () => ({
      getBlupsData: () => {
        return jest.fn().mockReturnValue({});
      },
    }));
    let dataByPrescsAndBlups = {
      advanceData: [],
      dropData: [],
      noMatchData: []
    } 
    dataByPrescsAndBlups = await filterDataByPrescs(
      prescData,
      dataByPrescsAndBlups
    );
    expect(dataByPrescsAndBlups.advanceData).toHaveLength(2);
    expect(dataByPrescsAndBlups.dropData).toHaveLength(1);
    expect(dataByPrescsAndBlups.noMatchData).toHaveLength(0);
  });
});
