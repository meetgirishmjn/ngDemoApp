export default class Constants {
  public static CropCodes = {
    Hybrid: {
      Corn: "CORN",
      OsrCanola: "CNLA",
      Sorghum: "SRGM",
      Watermelon: "WTML",
      Tomato: "TOMT",
      Rice: "RICE",
    },
    Varietal: {
      Cotton: "CTTN",
      Soybeans: "SYBN",
      Wheat: "WHET",
    },
  };
  public static HarvestTypes = {
    Lint: { key: "L", value: "Lint" },
    Grain: { key: "G", value: "Grain" },
  };
  public static AnalysisTypes = {
    ATTRIBUTES: { name: "ATTRIBUTES" },
    ADVANCEMENT_TARGET: { name: "ADVANCEMENT TARGETS" },
    ADVANCEMENT_DATES: { name: "ADVANCEMENT DATES" },
    PRESCRIPTION: "PRESCRIPTION",
    PREDICTION: "PREDICTION",
    BLUP: "BLUP",
    PIPELINE_REPORT: "PIPELINE_REPORT",
    INDEX: { name: "INDEX" },
    RANK: { name: "RANK" },
    LSMEANS: { name: "LSMEANS" },
    MEANS: { name: "MEANS" },
    CLUSTER: { name: "CLUSTER" },
  };
  public static productStageTypes: IProductStageGroup[] = [
    { groupName: "SC1-SC2", productStageNames: ["SC1", "SC2"] },
    { groupName: "PS0", productStageNames: ["PS0"] },
    { groupName: "PS1-PS2", productStageNames: ["PS1", "PS2"] },
    { groupName: "PS2.5", productStageNames: ["PS2.5"] },
    { groupName: "PS3-PS4", productStageNames: ["PS3", "PS4"] },
  ];
  public static lineAttrHierarchy = {
    COTTON: "CottonAtt",
    CORN: "CornAtt",
    OSR_CANOLA: "OSR-CanolaAtt",
    RICE: "RiceAtt",
    WHEAT: "WheatAtt",
    SOYBEAN: "SoyAtt",
    VIEWLINE: "ViewLine",
  };

  public static ALL_TRAIT_KEY = "-1";
  public static ALL_TRAIT_VALUE = "All Traits";
  public static ALL_SUBMARKETS = "All Sub Markets";
  public static productStages = {
    SCREENING: "SCREENING",
    PCM: "PCM",
    CM: "CM",
  };
  public static entitlementGroups: IEntitlementGroups[] = [
    {
      groupName: "BreedingIT-Tejas-Group",
      crop: "ALL",
      region: "ALL",
      groupId: "BREEDINGITTEJASGROUP",
    },
    // { groupName: 'BREEDING-APC-COMMUNITY', crop: 'ALL', region: 'ALL', groupId: 'BREEDING-APC-COMMUNITY' },
    {
      groupName: "Advance-Products-Testers",
      crop: "ALL",
      region: "ALL",
      groupId: "Advance-Products-Testers",
    },
    {
      groupName: "Breeding-IT-Deployment-Team",
      crop: "ALL",
      region: "ALL",
      groupId: "Breeding-IT-Deployment-Team",
    },
    {
      groupName: "NA Corn Breeders",
      crop: "Corn",
      region: "NA",
      groupId: "NA-CORN-BREEDERS",
    },
    {
      groupName: "NA Corn Product Systems",
      crop: "Corn",
      region: "NA",
      groupId: "NA-CORN-PRODUCT-SYSTEMS",
    },
    {
      groupName: "NA Soybean Breeders",
      crop: "Soybean",
      region: "NA",
      groupId: "NA-SOYBEAN-BREEDERS",
    },
    {
      groupName: "NA Soybean Product Systems",
      crop: "Soybean",
      region: "NA",
      groupId: "NA-SOYBEAN-PRODUCT-SYSTEMS",
    },
    {
      groupName: "NA Sorghum Breeders",
      crop: "Sorghum",
      region: "NA",
      groupId: "NA-SORGHUM-BREEDERS",
    },
    {
      groupName: "NA Sorghum Product Systems",
      crop: "Sorghum",
      region: "NA",
      groupId: "NA-PRODUCT-SYSTEMS-SORGHUM",
    },
    {
      groupName: "NA OSR-Canola Breeders",
      crop: "OSR-Canola",
      region: "NA",
      groupId: "NA-OSRCANOLA-BREEDERS",
    },
    {
      groupName: "NA OSR-Canola Product Systems",
      crop: "OSR-Canola",
      region: "NA",
      groupId: "NA-OSRCANOLA-PRODUCT-SYSTEMS",
    },
    {
      groupName: "NA Wheat Breeders",
      crop: "Wheat",
      region: "NA",
      groupId: "NA-WHEAT-BREEDERS",
    },
    {
      groupName: "NA Wheat Product Systems",
      crop: "Wheat",
      region: "NA",
      groupId: "NA-WHEAT-PRODUCT-SYSTEMS",
    },
    {
      groupName: "NA Cotton Breeders",
      crop: "Cotton",
      region: "NA",
      groupId: "NA-COTTON-BREEDERS",
    },
    {
      groupName: "NA Cotton Product Systems",
      crop: "Cotton",
      region: "NA",
      groupId: "NA-COTTON-PRODUCT-SYSTEMS",
    },
    {
      groupName: "LATAM Corn Breeders",
      crop: "Corn",
      region: "BRA",
      groupId: "LATAM-CORN-BREEDERS",
    },
    {
      groupName: "LATAM Soybean Breeders",
      crop: "Soybean",
      region: "BRA",
      groupId: "LATAM-SOYBEAN-BREEDERS",
    },
    {
      groupName: "LATAM Sorghum Breeders",
      crop: "Sorghum",
      region: "BRA",
      groupId: "LATAM-SORGHUM-BREEDERS",
    },
    {
      groupName: "LATAM Corn Breeders",
      crop: "Corn",
      region: "LAS",
      groupId: "LATAM-CORN-BREEDERS",
    },
    {
      groupName: "LATAM Soybean Breeders",
      crop: "Soybean",
      region: "LAS",
      groupId: "LATAM-SOYBEAN-BREEDERS",
    },
    {
      groupName: "LATAM Sorghum Breeders",
      crop: "Sorghum",
      region: "LAS",
      groupId: "LATAM-SORGHUM-BREEDERS",
    },
    {
      groupName: "LATAM Corn Breeders",
      crop: "Corn",
      region: "LAN",
      groupId: "LATAM-CORN-BREEDERS",
    },
    {
      groupName: "LATAM Sorghum Breeders",
      crop: "Sorghum",
      region: "LAN",
      groupId: "LATAM-SORGHUM-BREEDERS",
    },
    {
      groupName: "EMEA - EU- Corn Breeders",
      crop: "Corn",
      region: "EU",
      groupId: "EU-CORN-BREEDER",
    },
    {
      groupName: "EMEA - OSR Breeder",
      crop: "OSR-Canola",
      region: "EU",
      groupId: "EU-OSR-BREEDING",
    },
    {
      groupName: "APAC Corn Breeders",
      crop: "Corn",
      region: "India",
      groupId: "APAC-BREEDERS-CORN",
    },
    {
      groupName: "APAC Cotton Breeders",
      crop: "Cotton",
      region: "India",
      groupId: "APAC-BREEDERS-COTTON",
    },
    {
      groupName: "APAC Rice Breeders",
      crop: "Rice",
      region: "India",
      groupId: "APAC-BREEDERS-RICE",
    },
    {
      groupName: "RSA Breeders",
      crop: "Corn",
      region: "EAF",
      groupId: "RSA-BREEDERS",
    },
    {
      groupName: "RSA Breeders",
      crop: "Corn",
      region: "SAF",
      groupId: "RSA-BREEDERS",
    },
    {
      groupName: "RSA Breeders",
      crop: "Corn",
      region: "WAF",
      groupId: "RSA-BREEDERS",
    },
    {
      groupName: "APAC Corn Breeders",
      crop: "Corn",
      region: "China",
      groupId: "APAC-BREEDERS-CORN",
    },
    {
      groupName: "APAC Corn Breeders",
      crop: "Corn",
      region: "Pan-Sea",
      groupId: "APAC-BREEDERS-CORN",
    },
    {
      groupName: "APAC Rice Breeders",
      crop: "Rice",
      region: "Pan-Sea",
      groupId: "APAC-BREEDERS-RICE",
    },
  ];
  public static INFO_MESSAGE =
    "This is Read-Only view because you do not have editing privileges. Ask Breeding if you have any questions.";
  public static ADVANCE_PRODUCTS_SUBSTRING = "advanceproducts";
  public static TRACKER_INIT_FAILED_MESSAGE =
    "Failed to connect Db. Please try refreshing your browser or contact Ask Breeding";
}

export interface IProductStageGroup {
  groupName: string;
  productStageNames: string[];
}

export interface IEntitlementGroups {
  groupName: string;
  crop: string;
  region: string;
  groupId: string;
}
