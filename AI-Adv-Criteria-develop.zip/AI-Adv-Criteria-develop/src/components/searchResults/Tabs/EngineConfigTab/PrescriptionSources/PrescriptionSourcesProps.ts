import { IAnalysisSubType } from "../../../../../models/IAnalyticModel";

export default interface IPrescriptionSourcesProps {
  selectedTab: string;
  selectedParams: IPipeline;
  isDataLoading: boolean;
  analysisSubTypes: IAnalysisSubType[];
  versionId: string;
  horizonServices: any;
  isEditable: boolean;
}
