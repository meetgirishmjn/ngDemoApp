import React from "react";
import { shallow, mount } from "enzyme";
import SaveToAdvModal from ".";

const horizonServicesMocked = {
    alert: {
        error: (message: string) => { }
    }
}

describe("SaveToAdvModal Tests", () => {
    it('render SaveToAdvModal with default props', async () => {
        const wrapper = await mount(<SaveToAdvModal
            horizonServices={horizonServicesMocked}
            selectedVersion={{ analyseId: "1", isInProgress: false, isLocked: false, name: "Test1", runs: [], uid: "1", version: 1, versionDesc: "1" }}
            onModalHide={() => { }}
            showModalDialog={true}
        />);
      
        expect(wrapper.find('div.ui-react-confirmation-dlg.saveToAdv-modal')).toHaveLength(1);
    });

    it('cancel button should work', async () => {

        const onModalHide = jest.fn();

        const wrapper = await mount(<SaveToAdvModal
            horizonServices={horizonServicesMocked}
            selectedVersion={{ analyseId: "1", isInProgress: false, isLocked: false, name: "Test1", runs: [], uid: "1", version: 1, versionDesc: "1" }}
            onModalHide={onModalHide}
            showModalDialog={true}
        />);
        wrapper.find('.saveToAdv-modal').find('button.cancel').simulate("click");
        expect(onModalHide).toBeCalledTimes(1);
    })

    it('submit button should work', async () => {

        const wrapper = await mount(<SaveToAdvModal
            horizonServices={horizonServicesMocked}
            selectedVersion={{ analyseId: "1", isInProgress: false, isLocked: false, name: "Test1", runs: [], uid: "1", version: 1, versionDesc: "1" }}
            onModalHide={() => { }}
            showModalDialog={true}
        />);
        wrapper.find('.saveToAdv-modal').find('button.submit').simulate("click");
        expect(wrapper.find('div.ui-react-confirmation-dlg.saveToAdv-modal')).toHaveLength(1);
    })
})