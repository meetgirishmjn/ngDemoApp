interface IKvp<T1, T2> {
  id?: number;
  key: T1;
  value: T2;
}
