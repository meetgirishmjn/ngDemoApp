import axios from "axios";
import { updateConfig, handle401 } from "./_apiConfigHelper";

const evaApi = axios.create({
    baseURL: process.env.EVA_SERVICE,
});

evaApi.interceptors.request.use((config) => {
    const configRes = updateConfig(config);
    return configRes;
});

evaApi.interceptors.response.use(
    (response) => {
        return response;
    },
    (error) => {
        const status = error.response ? error.response.status : null;
        if (status === 401) {
            // will loop if refreshToken returns 401
            return handle401(error);
        }
        return Promise.reject(error);
    }
);

export default evaApi;
