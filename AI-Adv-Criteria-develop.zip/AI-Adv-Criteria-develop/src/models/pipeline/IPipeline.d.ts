interface IPipeline {
  Crop?: ICrop;
  Year?: string;
  Region?: IStringKvp;
  HarvestType?: IStringKvp;
  Market?: IStringKvp;
  SubMarket?: IStringKvp;
  StageType?: IStringKvp;
  ProductStage?: IStringKvp;
  Trait?: IStringKvp;
  DecisionEngine?: IStringKvp;
}

interface IPsRef {
  productStageId: number;
  productStageName: string;
  productStageType: string;
  priority: number;
  productStageDesc: string;
  combineProductStageId: number;
  pipelineAvail: boolean;
  refActive: boolean;
}

interface IPipelineValue {
  displayText?: string;
  value: string | string[];
}

interface IPipelineSelections {
  Crop?: IPipelineValue;
  Year?: IPipelineValue;
  Region?: IPipelineValue;
  HarvestType?: IPipelineValue;
  Market?: IPipelineValue;
  SubMarket?: IPipelineValue;
  StageType?: IPipelineValue;
  ProductStage?: IPipelineValue;
  Trait?: IPipelineValue;
  Cycle?: IPipelineValue;
  [index: string]: IPipelineValue | undefined;
}
