import React from "react";
import ConnectedPipelineEditedSubHeader, {
  PipelineEditedSubHeader,
} from "./PipelineEditedSubHeader";
import { PipelineDisplay } from "@monsantoit/ui-react-pipeline-select";
import { mount, shallow } from "enzyme";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import configureMockStore from "redux-mock-store";
import thunk from "redux-thunk";

const selectedParams = {
  Crop: { id: 65601536, key: "CORN", value: "Corn", cropId: 65601536 },
  Year: "2020",
  Region: { id: 100001, key: "NA", value: "NA" },
  HarvestType: { id: 81985536, key: "G", value: "Grain" },
  Market: { id: 123456, key: "RM080", value: "RM080" },
  SubMarket: { id: 51283, key: "BRACHYTIC", value: "BRACHYTIC" },
  StageType: { key: "SCREENING", value: "SCREENING" },
  ProductStage: { key: 10061, value: "SC2" },
  Trait: [
    { key: "RR2", value: "RR2" },
    { key: "CONV", value: "CONV" },
  ],
  DecisionEngine: { key: "EVA", value: "EVA" },
};

const horizonServices = {};

const mockStore = configureMockStore([thunk]);

describe("<PipelineEditedSubHeader />", () => {
  it("renders component", async () => {
    const store = mockStore({
      userPreferences: {
        userPreferences: selectedParams,
      },
    });
    const wrapper = mount(
      <BrowserRouter>
        <Provider store={store}>
          <ConnectedPipelineEditedSubHeader
            horizonServices={horizonServices}
            store={store}
          />
        </Provider>
      </BrowserRouter>
    );
    expect(wrapper.find("PipelineDisplay")).toBeTruthy();
    expect(wrapper.find("FormModal")).toBeTruthy();
    wrapper.find("a.color-primary").simulate("click");
  });
});
