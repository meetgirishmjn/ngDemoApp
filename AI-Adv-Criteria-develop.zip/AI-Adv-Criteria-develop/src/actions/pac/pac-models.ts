export interface IPacApiBaseRes<T> {
    hasError: boolean;
    errorMessage?: string;
    errorCode?: string;
    data?: T;
}

export interface ICreateRunResponse {
    run: { id: number };
    uploadUrl: string;
}

export interface ICreateEvaAnalysisResponse {
    id: number;
    reportName: string;
    version: number;
}

export interface ICreateRunTaskResponse {
    runTask: { id: number };
}

export interface ICreateTaskStatusResponse {
    taskStatus: { id: number };
}

export interface IExecuteAirflowOutput {
    status: string;
}

export interface IFinalizeRunResponse {
    run: { id: number };
}

export interface IUpdateRunResponse {
    run: {
        id: number
        isUsedForAdvancements: boolean;
        usedForAdvancementsReason: string
    }
}
export interface IQueryRunResponse {
    id: number
    isFinished: boolean;
    isUsedForAdvancements: boolean;
    finalizedStatus: string
}