import { IRuleGroup, ICurrentState } from "@monsantoit/ui-react-ap-rules/dist/CriteriaCreation/ICriteriaCreationProps";
import { IModelVersion } from "../../../../actions/criteria/models";

export interface IRuleGroupsTabProps {
    horizonServices: any;
    selectedParams: IPipeline;
    onRuleGroupsModified: (groups: IRuleGroup[]) => void;
    onStateModified: (componentState: ICurrentState) => void;
    selectedVersion: IModelVersion;
    hasEntitlements: boolean;
    componentState: ICurrentState;
}
