import initialState from "../store/initialState";
import types from "../actions/ActionTypes";

export default (state = initialState.graphData, action) => {
  switch (action.type) {
      case types.SAVE_GRAPH_DATA:
          return { ...state, ...action.payload };
      case types.SAVE_BLUPS:
          let newState = { ...state };
          newState.blupsDataForSelectedVersion[action.payload.key] = action.payload.dataSet;
          return newState;
      case types.DELETE_BLUPS:
          let newStateToDeleteBlups = { ...state };
          newStateToDeleteBlups.blupsDataForSelectedVersion = {};
          return newStateToDeleteBlups;
    default:
      return state;
  }
};
