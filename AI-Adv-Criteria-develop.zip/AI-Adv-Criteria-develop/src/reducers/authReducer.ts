import initialState from "../store/initialState";
import types from "../actions/ActionTypes";

export default (state = initialState.auth, action) => {
  switch (action.type) {
    case types.AUTHENTICATION_SUCCESS:
      return { ...state, ...action.payload };
    case types.SAVE_ENTITLEMENTS:
      return { ...state, ...action.payload };
    case types.AUTHENTICATION_FAILED:
      return { ...state, ...action.payload };
    default:
      return state;
  }
};
