import React, { Component } from "react";
import { isEmpty, get, isEqual, find } from "lodash";
import IProps from "./IPipelineSharedComponentProps";
import IState from "./IPipelineSharedComponentState";
import { getProductStageRefs } from "../../../actions/pipeline/pipelineActions";
import { PipelineSelect } from "@monsantoit/ui-react-pipeline-select";
import Constants from "../../../shared/constants";
import { defaultUserPreferences } from "../../../models/IUserPreferences";
import buildDropdownComponent from "../DropdownComponent";
import ISelection from "@monsantoit/ui-react-pipeline-select/dist/PipelineSelect/interfaces/ISelection";
import {
  getDEData,
  getTraits,
  getProductStages,
  getYearSelections,
  getCustomSubMarkets,
  getStageTypes,
} from "./helper";

export class PipelineSharedComponent extends Component<IProps, IState> {
  public readonly emptyParameters: any = {
    selectedKeys: ["DEFAULT"],
    items: () => Promise.resolve([{ key: "DEFAULT", value: "DEFAULT" }]),
    hidden: true,
  };
  constructor(props: IProps) {
    super(props);
    const initialPipeline: IPipeline = isEmpty(props.Pipeline)
      ? defaultUserPreferences
      : props.Pipeline;
    this.state = {
      PipelineComponentKey: 1,
      pipelineSelections: initialPipeline,
      selectorProps: {},
      psRefs: [],
      // DE dropdown state
      enableDEDropdown: false,
      loadDEDropdown: false,
      decisionEngineData: [],
      selectedDE: undefined,
      // hack to set for first time
      setDefaultDE: true,
    } as IState;
  }

  public componentDidMount = async () => {
    const psRefs = await getProductStageRefs();
    this.setState({ psRefs });
  };

  public shouldComponentUpdate = (
    nextProps: IProps,
    nextState: IState
  ): boolean => {
    return (
      get(this.state, "pipelineSelections", undefined) !==
      get(nextProps, "Pipeline", undefined)
    );
  };

  public onSelectionChangePipelineParams = async (
    Crop?: ICrop,
    Year?: IStringKvp,
    Region?: IStringKvp,
    HarvestType?: IStringKvp,
    Market?: IStringKvp,
    SubMarket?: any | any[],
    StageType?: any | any[],
    ProductStage?: any | any[],
    Trait?: IStringKvp,
    unusedCycle?: any | any[],
    updatedProps?: () => void
  ) => {
    const { pipelineSelections, setDefaultDE } = this.state;
    const selections: Partial<IPipeline> = { ...this.state.pipelineSelections };
    selections.Crop = Crop;
    selections.Year = Year ? Year.value : undefined;
    selections.Region = Region;
    selections.HarvestType = HarvestType;
    selections.Market = Market;
    selections.SubMarket = SubMarket;
    selections.StageType = StageType;
    selections.ProductStage = ProductStage;
    selections.Trait = Trait;

    if (!Trait) {
      selections.DecisionEngine = undefined;
      this.setState({ enableDEDropdown: false });
      this.props.deSelectorRef.current.updateSelections([], false);
    }
    if (
      Trait &&
      !isEqual(Trait, pipelineSelections.Trait) &&
      !this.state.loadDEDropdown
    ) {
      selections.DecisionEngine = undefined;
      this.props.deSelectorRef.current.updateSelections([], false);
      this.setState({ loadDEDropdown: true, selectedDE: undefined });
      const decisionEngineData: ISelection[] = await getDEData(
        Crop,
        Year,
        Region,
        HarvestType,
        Market,
        this.props.HorizonServices
      );
      decisionEngineData.length &&
        this.setState(
          {
            enableDEDropdown: true,
            decisionEngineData,
            loadDEDropdown: false,
            selectedDE:
              decisionEngineData.length === 1
                ? decisionEngineData[0]
                : undefined,
          },
          () => {
            if (setDefaultDE && !isEmpty(this.props.Pipeline)) {
              const { Pipeline } = this.props;
              selections.DecisionEngine = find(
                decisionEngineData,
                (data) =>
                  data.key ===
                  (Pipeline.DecisionEngine ? Pipeline.DecisionEngine.key : "")
              )
                ? this.props.Pipeline.DecisionEngine
                : undefined;
              this.props.deSelectorRef.current.updateSelections(
                this.props.Pipeline.DecisionEngine,
                true
              );
              this.setState({ setDefaultDE: false });
            } else {
              this.state.selectedDE &&
                this.onDESelectionChanged("DE", this.state.selectedDE);
            }
          }
        );
      !decisionEngineData.length &&
        this.setState({
          enableDEDropdown: false,
          decisionEngineData: [],
          loadDEDropdown: false,
        });
    }

    if (StageType && !isEqual(StageType, pipelineSelections.StageType)) {
      this.props.setSelectorRef.current.stageTypeDropdownRef.current.updateSelections(
        StageType,
        true
      );
    }

    this.setState(
      {
        pipelineSelections: selections,
      },
      () => {
        if (typeof updatedProps === "function") {
          updatedProps();
        }
      }
    );
    if (typeof this.props.onSelectionChanged === "function") {
      this.props.onSelectionChanged(selections as IPipeline);
    }
  };

  public onDESelectionChanged = (name, selectedDE) => {
    const selections: Partial<IPipeline> = { ...this.state.pipelineSelections };
    selections.DecisionEngine = selectedDE;
    this.setState(
      {
        pipelineSelections: selections,
      },
      () => {
        if (typeof this.props.onSelectionChanged === "function") {
          this.props.onSelectionChanged(selections as IPipeline);
        }
      }
    );
  };

  public render() {
    const userPreferences = this.props.Pipeline;
    const {
      enableDEDropdown,
      decisionEngineData,
      loadDEDropdown,
      selectedDE,
    } = this.state;
    return (
      <PipelineSelect
        onSelectionChange={this.onSelectionChangePipelineParams}
        horizonServices={this.props.HorizonServices}
        crop={{
          selectedKeys: userPreferences.Crop ? [userPreferences.Crop.key] : [],
        }}
        year={{
          selectedKeys: [userPreferences.Year],
          items: getYearSelections as any,
        }}
        region={{
          selectedKeys: userPreferences.Region
            ? [userPreferences.Region.key]
            : [],
        }}
        harvestType={{
          selectedKeys: userPreferences.HarvestType
            ? [userPreferences.HarvestType.key]
            : [],
        }}
        market={{
          selectedKeys: userPreferences.Market
            ? [userPreferences.Market.key]
            : [],
        }}
        subMarket={{
          selectedKeys: userPreferences.SubMarket
            ? [userPreferences.SubMarket.key]
            : [],
          items: getCustomSubMarkets,
        }}
        stageType={{
          selectedKeys: userPreferences.StageType
            ? [userPreferences.StageType.key]
            : [],
          items: getStageTypes,
        }}
        productStage={{
          selectedKeys: userPreferences.ProductStage
            ? [userPreferences.ProductStage.key]
            : [],
          items: getProductStages.bind(this, this.props, this.state),
        }}
        trait={{
          selectedKeys: userPreferences.Trait
            ? [userPreferences.Trait.key]
            : [Constants.ALL_TRAIT_KEY],
          items: getTraits.bind(this, this.props),
          multiSelect: false,
        }}
        cycle={this.emptyParameters}
        ref={this.props.setSelectorRef}
        waitForUpdates={false}
      >
        {buildDropdownComponent(
          decisionEngineData,
          "Decision Engine",
          this.onDESelectionChanged,
          this.props.deSelectorRef,
          selectedDE,
          true,
          false,
          loadDEDropdown,
          !enableDEDropdown
        )}
      </PipelineSelect>
    );
  }
}

export default PipelineSharedComponent;
