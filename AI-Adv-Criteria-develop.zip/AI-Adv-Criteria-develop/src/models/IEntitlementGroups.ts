export default interface IEntitlementGroups {
  name: string;
  id: string;
  entitlements?: IEntitlements[];
}

export interface IEntitlements {
  name: string;
  id: string;
  description: string;
}
