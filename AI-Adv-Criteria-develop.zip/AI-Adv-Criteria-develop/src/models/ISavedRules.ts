export interface ISavedRules {
    analysis: IAnalysis;
}

export interface IAnalysis {
    id: number;
    version: number;
    rules: IDecisionRule[]
    analyticModelVersionId: number;
    analysisSubTypeId: number;
}

export interface IDecisionRule {
    name: string;
    decision: string;
    ruleGroupId: number;
    rules: IRule[];
}

export interface IRule {
    value: number;
    gender: string;
    ruleId: number;
    category: string;
    dataType: string;
    lineName: string;
    maxValue: string;
    minValue: string;
    operator: string;
    checkType: string;
    ruleLevel: string;
    valueType: string;
    distroPerc: number,
    categoryType: string;
    displayValue: number;
    distribution: string;
    operatorNotation: string;
    traitOrAttribute: string;
    distributionNotation: string;
    traitOrAttributeDataType: string;
    traitOrAttributeDisplayName: string;
    subMarketId: number;
    subMarketName: string;
}