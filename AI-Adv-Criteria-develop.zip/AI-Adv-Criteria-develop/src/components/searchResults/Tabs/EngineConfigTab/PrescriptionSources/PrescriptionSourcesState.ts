import { IAnalysisSubType } from "../../../../../models/IAnalyticModel";

export default interface IPrescriptionSourcesState {
  tabHash: { [name: string]: string[] };
  analysisSubTypes: IAnalysisSubType[];
  filteredData: IAnalysisSubType[];
}
