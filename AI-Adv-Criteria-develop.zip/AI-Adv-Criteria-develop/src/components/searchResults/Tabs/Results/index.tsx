import React, { Component } from "react";
import { GridContainer } from "@monsantoit/ui-react-grid-container";
import { isEqual, findIndex, cloneDeep } from "lodash";
import "./results.scss";
import { ITabData } from "src/models/IResults";

export enum ITabType {
  Advance = "Advance",
  Drop = "Drop",
  NoMatch = "NoMatch",
}

interface IProps {
  type: ITabType;
  selectedVersion: string;
  data: ITabData[];
  isDataLoading: boolean;
  columnOrder: any[];
  onColumnOrderChange?: (columnState: any[], type: ITabType) => void;
}

interface IState {
  columns: any[];
  data: ITabData[];
}

class ResultsTab extends Component<IProps, IState> {
  private columns = [
    {
      headerName: "Decision",
      field: "decision",
      colId: "decision",
      filter: "agTextColumnFilter",
      suppressSizeToFit: true,
      suppressResize: true,
      resizable: false,
      width: 100,
      cellRenderer: (params: any) => {
        let content = "";
        switch (this.props.type) {
          case ITabType.Advance:
            content =
              '<span class="rectangle-badge bg-color-status-green">Advance</span>';
            break;
          case ITabType.Drop:
            content =
              '<span class="rectangle-badge bg-color-status-red">Drop</span>';
            break;
          case ITabType.NoMatch:
            content =
              '<span class="rectangle-badge bg-color-status-orange">No Match</span>';
            break;
        }
        return content;
      },
    },
    // {
    //   headerName: "Rule Group",
    //   field: "ruleGroup",
    //   colId: "ruleGroup",
    //   filter: "agTextColumnFilter",
    // }, // Not required for MVP, remove comment when required.
    {
      headerName: "Line Name",
      field: "lineName",
      colId: "lineName",
      filter: "agTextColumnFilter",
    },
  ];
  gridContainer: React.RefObject<GridContainer>;

  constructor(props: IProps) {
    super(props);
    this.gridContainer = React.createRef<GridContainer>();
    this.state = {
      columns: this.generateColumns(this.columns, props.data),
      data: props.data,
    };
  }

  public componentWillReceiveProps(nextProps: IProps) {
    if (!isEqual(nextProps.data, this.state.data)) {
      this.gridContainer = React.createRef<GridContainer>();
      this.setState({
        data: nextProps.data,
        columns: this.generateColumns(this.columns, nextProps.data),
      });
    }
  }

  public shouldComponentUpdate = (
    nextProps: IProps,
    nextState: IState
  ): boolean => {
    return !isEqual(nextProps, this.props);
  };

  public generateColumns = (columns: any[], data: ITabData[]) => {
    data.length > 0 &&
      Object.keys(data[0]).forEach((key: string) => {
        if (
          key !== columns[0].field &&
          key !== columns[1].field 
          // key !== columns[2].field
        ) {
          columns.push({
            headerName: key,
            field: key,
            colId: key,
            filter: "agTextColumnFilter",
          });
        }
      });
    return columns;
  };

  setColumnOrder = () => {
    const { columnOrder } = this.props;
    const { columns } = this.state;
    let newColumnOrder = cloneDeep(columns);
    columnOrder && columnOrder.forEach((element, index) => {
      if(element.colId) {
        //find index in all columns
        const colIndex = findIndex(newColumnOrder, (column) => column.field === element.colId);
        //move to stored index
        if(colIndex !== -1) {
          var element = newColumnOrder[colIndex];
          newColumnOrder.splice(colIndex, 1);
          newColumnOrder.splice(index, 0, element);
        }
      }
    });
    this.gridContainer && this.gridContainer.current && this.gridContainer.current.GridColumnApi.setColumnState(
      newColumnOrder
    );
  }


  public render() {
    const menu: JSX.Element = null;
    const { isDataLoading, type } = this.props;
    const { data, columns } = this.state;
    return (
      <div className="tabInfo">
        {isDataLoading && (
          <div className="loading-div">
            <span
              className="spinner-grow spinner-grow-sm"
              role="status"
              aria-hidden="true"
            />
            Loading...
          </div>
        )}
        {data.length > 0 && !isDataLoading && (
          <GridContainer
            ref={this.gridContainer}
            data={data || []}
            columnDefs={columns}
            menu={menu}
            searchCol={{
              colId: "lineName",
              placeHolderText: "Search Line Name",
            }}
            gridConfig={{
              getRowNodeId: (data: any) => {
                return data.lineName;
              },
              onGridReady: () => {
                this.gridContainer.current.GridApi.sizeColumnsToFit();
                this.setColumnOrder();
                {/* !isEmpty(columnOrder) &&
                  this.gridContainer.current.GridColumnApi.setColumnState(
                    columnOrder
                  ); */}
              },
              onDragStopped: (event: any) => {
                this.props.onColumnOrderChange &&
                  this.props.onColumnOrderChange(
                    event.columnApi.getColumnState(),
                    type
                  );
              },
              domLayout: "autoHeight",
            }}
            downloadConfig={{
              customDownload: () => {
                this.downloadReports();
              },
              enabled: true,
            }}
          />
        )}
      </div>
    );
  }

  private download = (fileName: string, content: Blob): void => {
    if (window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(content, fileName);
    } else {
      // Chrome
      const element: HTMLAnchorElement = document.createElement("a");
      const url: string = window.URL.createObjectURL(content);
      element.setAttribute("href", url);
      element.setAttribute("download", fileName);
      element.style.display = "none";
      document.body.appendChild(element);
      element.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(element);
    }
  };

  private downloadReports = async (): Promise<void> => {
    const params = {
      allColumns: false,
      fileName: `${this.props.type}_data.csv`,
    };

    try {
      const data: string = this.gridContainer.current.GridApi.getDataAsCsv(
        params
      );
      const blob: Blob = new Blob([data], {
        type: "text/csv;charset=utf-8;",
      });
      this.download(params.fileName, blob);
    } catch (ex) {
      console.log(ex);
    }
  };
}

export default ResultsTab;
