import {
  IModelVersion,
  IConfigurationTemplate,
} from "../../../actions/criteria/models";
import { ViewTypes } from "../SearchResultsState";

interface IVersionSelectorProps {
    selectedParams: IPipeline;
    userId: string;
    selectedVersion?: IModelVersion;
    onVersionSelectionChanged: (version: IModelVersion) => void;
    onRunIdSelectionChanged?: (version: IModelVersion, runId: number | undefined) => void;
    onVersionCreated: (version: IModelVersion) => void;
    versions: IModelVersion[];
    isVersionDataLoading: boolean;
    onSaveButtonClick: () => void;
    onViewResultsClick?: () => void;
    horizonServices: any;
    hasEntitlements: boolean;
    template: IConfigurationTemplate;
    enableRunButton: boolean;
    viewType?: ViewTypes;
    selectedRunId?: number;
}

export default IVersionSelectorProps;
