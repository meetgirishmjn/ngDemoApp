const express = require('express');
const bodyParser = require("body-parser");
const path = require('path');
const app = express();

const port = process.env.PORT || 80;
const BUILD_ENV = process.env.BUILD_ENV || '';

let baseUrl = '/advance-products/advancement-criteria'
if (BUILD_ENV === 'dev') {
    baseUrl = '/advance-products-dev/advancement-criteria'
}
const baseDir = `/dist${baseUrl}/index.html`;
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
// Serve the static files from the React app
app.use(express.static(path.join(__dirname, 'dist')));
// log message should be an object, example below
// axios.post('/log', { message: 'logging from app' });
app.post(`${baseUrl}/log`, (req, res) => {
    console.log(req.body.logText);
    res.send();
});
baseUrl = `${baseUrl}/*`;
// Handles any requests that don't match the ones above
app.get(`${baseUrl}`, (req, res) => {
    res.sendFile(path.join(__dirname + baseDir));
});
app.listen(port);