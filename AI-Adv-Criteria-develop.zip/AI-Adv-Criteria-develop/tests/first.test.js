const puppeteer = require('puppeteer');
const select = require ('puppeteer-select');
const chai = require('chai');
const prompt = require('prompt');

const AUTH_TOKEN = 'https://breeding-np.ag/advance-products-dev/auth-token-info';
const ADV_HOME =
	'http://localhost:3000/advance-products-dev/advancement-criteria';
const ADV_RESULTS_PAGE = `${ADV_HOME}/searchResults`
describe('Test page load', () => {
	let browser;
	let credentials;
	// eslint-disable-next-line no-undef
	before(async () => {
		var schema = {
			properties: {
				username: {
					pattern: /^[a-zA-Z\s\-]+$/,
					message: 'Name must be only letters, spaces, or dashes',
					required: true,
				},
				password: {
					hidden: true,
				},
			},
		};
		credentials = await new Promise((resolve, reject) => {
			prompt.get(schema, (error, result) => {
				resolve(result)
			})
		});
		browser = await puppeteer.launch({
			headless: false,
			defaultViewport: null,
			dumpio: true,
		})
	})

	it('should launch browser with token page', async () => {
		const page = await browser.newPage()
		await page.goto(AUTH_TOKEN, {
			waitUntil: 'load',
			timeout: 0,
		})
		const username = credentials.username;
		const password = credentials.password;
		await page.type('#username', username)
		await page.type('#password', password)
		await page.click('.amp-button', { clickCount: 1 })
		await page.waitForTimeout(5000)
		await page.close()
	})

	it('launch criteria homepage and submit click', async () => {
		const advPage = await browser.newPage()
		await advPage.goto(ADV_HOME, {
			waitUntil: 'load',
			timeout: 0,
		});
		await advPage.waitForSelector('#pipeline-submit-btn:not([disabled])', {
			timeout: 0,
		})
		await advPage.click('#pipeline-submit-btn');
		await advPage.waitForTimeout(5000);
		chai.expect(advPage.url()).contains('/searchResults');
		await advPage.close();
	});

	it('launch page and edit pipeline and click on viewResults', async () => {
		const advPage = await browser.newPage()
		await advPage.goto(ADV_HOME, {
			waitUntil: 'load',
			timeout: 0,
		});
		await advPage.waitForSelector('#pipeline-submit-btn:not([disabled])', {
			timeout: 0,
		});
		await advPage.waitForTimeout(5000);
		await advPage.waitForSelector('#Crop_dropdownMenuButton:not([disabled])', {
			timeout: 0,
		});
		await advPage.click('#Crop_dropdownMenuButton');
		await advPage.click('div[title="Corn"]');
		// select year
		await advPage.waitForSelector('#Year_dropdownMenuButton:not([disabled])', {
			timeout: 0,
		});
		await advPage.click('#Year_dropdownMenuButton');
		await advPage.click('div[title="2020"]');
		// select region
		await advPage.waitForSelector('#Region_dropdownMenuButton:not([disabled])', {
			timeout: 0,
		});
		await advPage.click('#Region_dropdownMenuButton');
		await advPage.click('div[title="NA"]');
		// select harvestType
		await advPage.waitForSelector('#Harvest\\ Type_dropdownMenuButton:not([disabled])', {
			timeout: 0,
		});
		await advPage.click('#Harvest\\ Type_dropdownMenuButton');
		await advPage.click('div[title="Grain"]');
		// select market
		await advPage.waitForSelector('#Market_dropdownMenuButton:not([disabled])', {
			timeout: 0,
		});
		await advPage.click('#Market_dropdownMenuButton');
		await advPage.click('div[title="RM110"]');
		// select subMarket Sub Market_dropdownMenuButton
		await advPage.waitForSelector('#Sub\\ Market_dropdownMenuButton:not([disabled])', {
			timeout: 0,
		});
		await advPage.click('#Sub\\ Market_dropdownMenuButton');
		await advPage.click('div[title="DEFAULT"]');
		// select stage type
		await advPage.waitForSelector('#Stage\\ Type_dropdownMenuButton:not([disabled])', {
			timeout: 0,
		});
		await advPage.click('#Stage\\ Type_dropdownMenuButton');
		await advPage.click('div[title="SCREENING"]');
		// select productStage
		await advPage.waitForSelector('#Product\\ Stage_dropdownMenuButton:not([disabled])', {
			timeout: 0,
		});
		await advPage.click('#Product\\ Stage_dropdownMenuButton');
		await advPage.click('div[title="SC2"]');
		// select Trait Trait_dropdownMenuButton
		await advPage.waitForSelector('#Trait_dropdownMenuButton:not([disabled])', {
			timeout: 0,
		});
		await advPage.click('#Trait_dropdownMenuButton');
		await advPage.click('div[title="CONV"]');
		// select DecisionEngine
		await advPage.waitForSelector('#Decision\\ Engine_dropdownMenuButton:not([disabled])', {
			timeout: 0,
		});
		// const DE = await advPage.$$('#Decision\\ Engine_dropdownMenuButton');
		await advPage.click('#Decision\\ Engine_dropdownMenuButton');
		await advPage.click('div[title="EVA-0.1.23"]');
		await advPage.waitForTimeout(2000);
		await advPage.waitForSelector('#pipeline-submit-btn:not([disabled])', {
			timeout: 0,
		})
		await advPage.click('#pipeline-submit-btn');
		await advPage.waitForTimeout(5000);
		chai.expect(advPage.url()).contains('/searchResults');
		await advPage.waitForTimeout(10000); 

		// click on version history tab and wait for grid
		let elements = await advPage.$$('li.nav-item');
		elements[3].click();
		await advPage.waitForSelector('.version-history-container', {
			timeout: 5000,
		});
		await advPage.waitForTimeout(10000);

		// click on view Results button
		await advPage.click('a[title="Click to view"]');
		await advPage.waitForTimeout(10000);
		await advPage.close();
	});

	it('launch results page', async () => {
		const advPage = await browser.newPage()
		await advPage.goto(ADV_RESULTS_PAGE, {
			waitUntil: 'load',
			timeout: 0,
		});
		await advPage.waitForTimeout(5000);
	})
	// eslint-disable-next-line no-undef
	after(async () => {
		browser && browser.close()
	})
})
