// HELPER TO SUPPORT DYNAMIC ITEMS IN PIPELINE
import { isArray, filter, each, groupBy } from "lodash";
import {
  getSearchAnalyses,
  getAnalyticModelVersion,
} from "../../../actions/pac/pacActions";
import { IAnalyses } from "../../../models/ISearchAnalyses";
import {
  IAnalyticModelVersion,
  IAnalyticModel,
  IVersion,
} from "../../../models/IAnalyticModel";
import ISelection from "@monsantoit/ui-react-pipeline-select/dist/PipelineSelect/interfaces/ISelection";
import {
  loadTraits,
  getSubMarkets,
} from "../../../actions/pipeline/pipelineActions";
import Constants from "../../../shared/constants";
import { ISubMarket } from "../../../models/ISearchResults";

const PIPELINE_NOT_EXISTS = "No pipeline exists for the selected parameters";

export const getYearSelections = async (): Promise<IStringKvp> => {
  let returnedYears = null;
  const thisYear = new Date().getFullYear();
  let years = null;
  years = [`${thisYear + 1}`, thisYear.toString(), `${thisYear - 1}`];
  returnedYears = years.map((year) => ({ key: year, value: year }));
  return returnedYears;
};

export const getStageTypes = () =>
  Promise.resolve([
    { key: "PCM", value: "PCM" },
    { key: "SCREENING", value: "SCREENING" },
    { key: "CM", value: "CM" },
  ]);

export const getDEData = async (
  selectedCrop: any,
  selectedYear: any,
  selectedRegion: any,
  selectedHarvestType: any,
  selectedMarket: any,
  horizonServices: any
) => {
  const deData: ISelection[] = [];
  const analyses: IAnalyses[] = await getSearchAnalyses(
    selectedCrop.value,
    selectedYear.value,
    selectedRegion.key,
    selectedHarvestType.key,
    selectedMarket.value
  );
  if(analyses.length) {
    const groupedAnalyses = groupBy(analyses, "analyticModelVersionId");
    const analyticModelVersionIds: string[] = Object.keys(groupedAnalyses);
    const analyticModelDatas: IAnalyticModelVersion[] = analyticModelVersionIds.length ?
      await getAnalyticModelVersion(analyticModelVersionIds) : [];
    analyticModelDatas.forEach((analyticModelData) => {
      const analyticModel: IAnalyticModel = analyticModelData.analyticModel;
      const deName: string = analyticModel.name.toUpperCase();
      analyticModel.versions.forEach((version: IVersion) => {
        const releaseVersion: string = version.releaseUrl.substr(
          version.releaseUrl.lastIndexOf("/") + 1
        );
        deData.push({
          key: `${deName}-${releaseVersion}`,
          value: `${deName}-${releaseVersion}`,
        });
      });
    });
  } else {
    horizonServices.toast.error("No Decision Engine defined for this pipeline");
  }
  return deData;
};

export const getTraits = async (props): Promise<any> => {
  let traits = [];
  const {
    selectedCrop,
    selectedYear,
    selectedRegion,
    selectedHarvestType,
    selectedMarket,
  } = props.setSelectorRef.current.state;
  let cropRegions = await loadTraits(
    !isArray(selectedCrop) && selectedCrop.value,
    !isArray(selectedYear) && selectedYear.value,
    !isArray(selectedRegion) && selectedRegion.value,
    !isArray(selectedHarvestType) && selectedHarvestType.key,
    !isArray(selectedMarket) && selectedMarket.key
  );
  const validProdStages = [
    Constants.productStages.SCREENING,
    Constants.productStages.PCM,
    Constants.productStages.CM,
  ];
  cropRegions = cropRegions.filter((o) =>
    validProdStages.includes(o.productStageType)
  );
  traits = cropRegions.map((o) => ({ key: o.traitId, value: o.traitName }));
  if (traits.length) {
    traits.push({
      key: Constants.ALL_TRAIT_KEY,
      value: Constants.ALL_TRAIT_VALUE,
    });
  } else {
    // show alert
    const { HorizonServices } = props;
    HorizonServices.toast.warning(PIPELINE_NOT_EXISTS);
  }
  return traits;
};

export const getProductStages = (props, state) => {
  const { psRefs, pipelineSelections } = state;
  const { selectedStageType } = props.setSelectorRef.current.state;
  const productStages = [];
  const selectedStageKey = selectedStageType
    ? selectedStageType.key
    : pipelineSelections &&
      pipelineSelections.StageType &&
      pipelineSelections.StageType.key;
  const filteredPsrefs =
    selectedStageKey &&
    filter(psRefs, (psRef: IPsRef) => {
      return psRef.productStageType === selectedStageKey;
    });
  each(filteredPsrefs, (psRef: IPsRef) => {
    productStages.push({
      key: psRef.productStageId,
      value: psRef.productStageName,
    });
  });
  return Promise.resolve(productStages);
};

export const getCustomSubMarkets = async (
  selectedCrop: any,
  selectedYear: any,
  selectedRegion: any,
  selectedHarvestType: any,
  selectedMarket: any
) => {
  let subMarkets = [];
  const response: ISubMarket[] = await getSubMarkets(
    selectedCrop.value,
    selectedYear.value,
    selectedRegion.key,
    selectedHarvestType.key,
    selectedMarket.value
  );
  subMarkets = response.map((o) => ({ id: o.id, key: o.name, value: o.name }));
  if (subMarkets.length) {
    subMarkets.push({
      id: -1,
      key: "",
      value: Constants.ALL_SUBMARKETS,
    });
  }
  return Promise.resolve(subMarkets);
};
