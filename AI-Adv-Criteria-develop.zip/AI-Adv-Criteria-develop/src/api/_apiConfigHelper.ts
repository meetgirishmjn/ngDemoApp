import axios from "axios";
import { store } from "../store/configureStore";
import IAuth from "../models/IAuth";
import {
  getToken,
  authenticationSuccess,
} from "../actions/authentication/authActions";

export const updateConfig = (config) => {
  const state = store.getState();
  const authInfo: IAuth = state.auth;
  if (authInfo.access_token) {
    config.headers["Authorization"] = `Bearer ${authInfo.access_token}`;
  }
  config.headers["Content-Type"] = "application/json";
  return config;
};

export const handle401 = (error) => {
  return getToken().then((response) => {
    error.config.headers.Authorization = `Bearer ${response.data.access_token}`;
    store.dispatch(authenticationSuccess(response));
    return axios.request(error.config);
  });
};
