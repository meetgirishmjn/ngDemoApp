import History from "history";

interface IParameterSelectionProps {
  HorizonServices?: any;
  history?: History;
  getSelectedParams: (selectedParams: IPipeline) => void;
  userId?: string;
  userPreferences: IPipeline;
  getUserPreferences: (horizonServices: any) => void;
  saveUserPreferences: (
    selectedParams: IPipeline,
    horizonServices: any
  ) => void;
}

export default IParameterSelectionProps;
