import { IModelVersion } from "../../../../actions/criteria/models";

export default interface ISaveToAdvProps {
    selectedRunId?: number;
    selectedVersion: IModelVersion;
    showModalDialog: boolean;
    horizonServices: any;
    onModalHide: () => void;
}