import initialState from "../store/initialState";
import types from "../actions/ActionTypes";

export default (state = initialState.userPreferences, action) => {
  switch (action.type) {
    case types.LOADING_USER_PREFERENCES:
      return { ...state, userPreferences: null, loadingUserPreferences: true };
    case types.GET_USER_PREFERENCES_SUCCESS:
      return {
        ...state,
        userPreferences: action.payload,
        loadingUserPreferences: false,
      };
    case types.GET_USER_PREFERENCES_ERROR:
      return { ...state, userPreferences: {}, loadingUserPreferences: false };
    default:
      return state;
  }
};
