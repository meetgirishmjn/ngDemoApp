import { IConfigurationTemplate } from "../../../../actions/criteria/models";
import { IAnalysisSubType } from "../../../../models/IAnalyticModel";

export default interface IEngineConfigTabState {
  template: IConfigurationTemplate;
  analysisSubTypes: IAnalysisSubType[];
  isAnalysisSubTypesLoading: boolean;
  criteriaValueId: number;
}
