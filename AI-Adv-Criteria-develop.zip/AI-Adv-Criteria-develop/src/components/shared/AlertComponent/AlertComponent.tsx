import React, { Component } from "react";
import _ from "lodash";
import IProps, { IAlertType, IAlert } from "./IAlertComponentProps";
import Error from "@material-ui/icons/Error";
import Warning from "@material-ui/icons/Warning";
import { Button, Typography, Paper } from "@material-ui/core";
import "./_alertComponent.scss";

interface IState {
  alert: IAlert;
  isOpen: boolean;
}

export class Alert extends Component<IProps, IState> {
  public static getDerivedStateFromProps(nextProps: IProps, prevState: IState) {
    if (nextProps.alert !== prevState.alert) {
      return { alert: nextProps.alert, isOpen: true }; // <- this is setState equivalent
    }
    return null;
  }

  constructor(props: IProps) {
    super(props);
    this.state = {
      alert: props.alert,
      isOpen: props.alert.isOpen ? props.alert.isOpen : true,
    };
  }

  public dismiss = () => {
    this.setState({
      isOpen: false,
    });
    this.props.onDismissClick();
  };

  public getClassNames = (type: IAlertType, divType) => {
    switch (type) {
      case IAlertType.Error:
        return divType ? `errors-${divType}` : "errors";
      case IAlertType.Info:
        return divType ? `info-${divType}` : "info";
      case IAlertType.Warning:
        return divType ? `warning-${divType}` : "warning";
      default:
        return "errors";
    }
  };

  public getIcon = (type) => {
    switch (type) {
      case "error":
        return <Error />;
      case "info":
        return <Error />;
      case "warning":
        return <Warning />;
      default:
        return <Error />;
    }
  };

  public render() {
    const { alert, isOpen } = this.state;
    return (
      <div>
        {isOpen && (
          <div className="errors-div mx-24 mt-24">
            <Paper className={this.getClassNames(alert.type, null)}>
              <Typography className={this.getClassNames(alert.type, "message")}>
                {this.getIcon(alert.type)}
                <span className="error-label ml-12 horizon-alert-message txt14">
                  {alert.type}: {alert.message}
                </span>
              </Typography>
              <div style={{ display: "flex" }}>
                <Button className="btn btn-tertiary" onClick={this.dismiss}>
                  <span>DISMISS</span>
                </Button>
                {alert.askBreeding && (
                  <Button className="btn btn-tertiary dismiss-button">
                    <span>
                      <a href="mailto:support@askbreeding.freshdesk.com">
                        ASK BREEDING
                      </a>
                    </span>
                  </Button>
                )}
                {alert.enableRefresh && (
                  <Button
                    className="btn btn-tertiary "
                    onClick={() => window.location.reload()}
                  >
                    <span>REFRESH</span>
                  </Button>
                )}
              </div>
            </Paper>
          </div>
        )}
      </div>
    );
  }
}

export default Alert;
