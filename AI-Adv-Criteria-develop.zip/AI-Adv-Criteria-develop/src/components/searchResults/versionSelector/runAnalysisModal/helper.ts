import { each, find, isEmpty } from "lodash";
import {
    IEvaRunModel,
    IRunRuleOrConstraint,
    IComparable,
    IConfigurationEvaRunModel,
    IRunAnalysisResult
} from "../../../../models/Eva-models";
import {
    IConfigSection,
    IConfigFieldRow,
    IConfigField,
    IConfigurationTemplate,
    IModelVersion,
} from "../../../../actions/criteria/models";
import { getRules, createTaskStatus, createRun, createRunTask, createEvaAnalysis, executeAirflow, finalizeRun } from "../../../../actions/pac/pacActions";
import {
    ISavedRules,
    IRule,
    IDecisionRule,
} from "../../../../models/ISavedRules";
import _ from "lodash";
import IRunAnalysisProps from "./IRunAnalysisProps";

const ADVANCEMENT_TARGETS = "Advancement_Targets";
const TARGETS = "Targets";


export const parseOperator = (operatorName: string) => {
    const operator = operatorName.toLowerCase();
    let parsedOperator = "";
    switch (operator) {
        case "equal":
            parsedOperator = "equal_to";
            break;
        default:
            parsedOperator = operator.replace(/\s/g, "_");
            break;
    };
    return parsedOperator;
}

export const getCheckType = (valueType: string, checkType: string) => {
    let defaultCheckType = checkType;
    const valueTypeParsed = valueType.toLowerCase();
    switch (valueTypeParsed) {
        case "compare against check":
            defaultCheckType = checkType;
            break;
        case "compare against line":
            defaultCheckType = "LINE";
            break;
        default:
            break;
    }
    return defaultCheckType;
}

export const getModelName = (productStage: string) => {
    let modelName: string = "";
    // Product Stage: SC1, SC2, PS1 and PS2 use: INBRED EVA
    //Product Stage: PS2.5, P3 and P4 use: PLAYBOOK
    switch (productStage) {
        case 'ps1':
        case 'ps2':
        case 'sc1':
        case 'sc2':
            modelName = "Inbred EVA";
            break;
        case 'ps2.5':
        case 'p3':
        case 'p4':
            modelName = "Playbook";
            break;
        default:
            break;
    }
    return modelName;
}
export const parseFieldRows = (fieldRows: IConfigFieldRow[], configurations: IConfigurationEvaRunModel) => {
    each(fieldRows, (fieldRow: IConfigFieldRow) => {
        const fieldRowKey = fieldRow.title.replace(/\s/g, "_");
        configurations[fieldRowKey] = {};
        each(fieldRow.fields, (field: IConfigField) => {
            const fieldKey = field.name;
            configurations[fieldRowKey][fieldKey] = field.value;
        });
        parseFieldRows(fieldRow.childRows, configurations[fieldRowKey]);
    });
    return configurations;
}

/*
This functions parses the Advancement Targets object of objects into
targets array of objects and truncates the _{decimal} in the end of every string
for example sub_market_1 to sub_market
*/
export const parseAdvTargets = (configurations: IConfigurationEvaRunModel) => {
    if(configurations.Required && configurations.Required[ADVANCEMENT_TARGETS]) {
        configurations.Required[TARGETS] = [];
        const keys = Object.keys(configurations.Required[ADVANCEMENT_TARGETS]);
        keys.forEach(key => {
            const targetKeys = Object.keys(configurations.Required[ADVANCEMENT_TARGETS][key]);
            const newObject = {};
            targetKeys.forEach(targetKey => {
                const newKey = targetKey.replace(/_[0-9]/g, '');
                newObject[newKey] = configurations.Required[ADVANCEMENT_TARGETS][key][targetKey];
            })
            newObject && configurations.Required[TARGETS].push(newObject);
        });
        delete configurations.Required[ADVANCEMENT_TARGETS];
    }
    return configurations;
}

export const createRunJsonModal = async (props: IRunAnalysisProps, modificationComments): Promise<IEvaRunModel> => {
    const { selectedParams, template } = props;
    try {
        let crop = selectedParams.Crop.key === "SYBN" ? "Soy" : selectedParams.Crop.value;
        let subMarket = selectedParams.SubMarket.id <= 0 ? "All-subMarket" : selectedParams.SubMarket.value;

        const modelName = getModelName(selectedParams.ProductStage.value.toLowerCase());

        let modelNameKey = modelName;

        //to map reportName with EVA, one of these supported modelName must be used in reportName
        //Supported models are: 
        //    OriginEVA
        //    InbredEVA
        //    Playbook
        //    ProductAdvancement
        if (modelName === "Inbred EVA") {
            modelNameKey = "InbredEVA";
        }

        let reportName = `AdvProd_${modelNameKey}_${crop}_${selectedParams.Region.value}_${selectedParams.Market.value}_${selectedParams.ProductStage.value}_${selectedParams.Year}_${selectedParams.HarvestType.value}_${subMarket}`;
        //replace space - and dash with _
        reportName = reportName.replace(/ |-/g, "_");

        const data: IEvaRunModel = {
            reportName: reportName,
            id: "",
            description: "",
            modifiedUser: props.userId,
            modifiedDttm: new Date().getTime(),
            configurations: {
                model: modelName,
                crop: selectedParams.Crop.value,
                region: selectedParams.Region.value,
                market: selectedParams.Market.value,
                deliveryType: selectedParams.ProductStage.value,
                year: selectedParams.Year,
                harvestType: selectedParams.HarvestType.value,
                subMarket: subMarket,
                Required: {}
            },
        };
        each(template.sections, (section: IConfigSection) => {
            const sectionKey: string = section.title;
            data.configurations[sectionKey] = {};
            each(section.fields, (field: IConfigField) => {
                const key = field.name;
                data.configurations[sectionKey][key] = field.value;
            });
            data.configurations[sectionKey] = parseFieldRows(section.fieldRows, data.configurations[sectionKey]);
        });
        // parse data.configurations["Required"][ADVANCEMENT_TARGETS] into targets
        data.configurations = parseAdvTargets(data.configurations);
        // add rules, constraints and comparables
        const response: ISavedRules = await getRules(
            props.selectedVersion.analyseId,
            props.selectedVersion.version
        );
        if (response) {
            data.configurations.Required = !isEmpty(data.configurations.Required) ? data.configurations.Required : {};
            data.configurations.Required.rules = {};
            data.configurations.Required.constraints = [];
            data.configurations.Required.comparables = [];
            each(response.analysis.rules, (decisionRule: IDecisionRule) => {
                each(decisionRule.rules, (rule: IRule) => {
                    const ruleOrConstraint: IRunRuleOrConstraint = {
                        category: rule.category || "",
                        criteria: rule.distribution ? parseOperator(rule.distribution) : "",
                        percentage: rule.distroPerc ? rule.distroPerc.toString() : "",
                        distributionNotation: rule.distributionNotation || "",
                        trait: rule.traitOrAttributeDisplayName || "",
                        operatorNotation: rule.operatorNotation || "",
                        operator: rule.operator ? parseOperator(rule.operator) : "",
                        value: rule.value ? rule.value.toString() : "",
                        value_type_UI: rule.valueType || "",
                        gender: rule.gender === "All Genders" ? "All" : rule.gender,
                        rule_group: decisionRule.name || "",
                        decision: decisionRule.decision || "",
                        against: rule.checkType ? getCheckType(rule.valueType, rule.checkType) : "SCORE",
                        displayValue: rule.displayValue
                            ? rule.displayValue.toString()
                            : "",
                        traitOrAttributeDataType: rule.traitOrAttributeDataType || "",
                        ruleLevel: rule.ruleLevel,
                        value_type:
                            rule.valueType && rule.valueType === "Compare Against Cohort"
                                ? "percentile"
                                : rule.traitOrAttributeDataType || "",
                        sub_market: rule.subMarketName || ""
                    };
                    if (rule.distribution) {
                        data.configurations.Required.constraints.push(ruleOrConstraint);
                    } else {
                        let requiredRules = data.configurations.Required.rules;
                        const decision = decisionRule.decision.toLowerCase();
                        if(!requiredRules[decision])
                            requiredRules[decision] = [];
                        requiredRules[decision].push(ruleOrConstraint);
                    }
                    if (rule.checkType || rule.lineName) {
                        const lookupName = rule.checkType ? getCheckType(rule.valueType, rule.checkType) : "";
                        const filteredComparable = find(data.configurations.Required.comparables, (comparable: IComparable) => {
                            return comparable.comparable_lookup === lookupName && comparable.comparable_name === rule.lineName;
                        });
                        if(!filteredComparable) {
                            data.configurations.Required.comparables.push({
                                comparable_lookup: rule.checkType ? getCheckType(rule.valueType, rule.checkType) : "" ,
                                comparable_name: rule.lineName,
                                rule_groups: [decisionRule.name || ""],
                            });
                        } else {
                            filteredComparable.rule_groups.push(decisionRule.name);
                        }
                    }
                });
            });
        }
        console.log(data);
        return data;
    } catch (err) {
        console.log(err);
    }
    return null;
};

export const runAnalysisModel = async (selectedParams: IPipeline, selectedVersion: IModelVersion, template: IConfigurationTemplate, userId: string, modificationComments: string = null): Promise<IRunAnalysisResult> => {
    try {

        const CROP_LINE_TYPE = getCropAndLineType(selectedParams);
        if (!CROP_LINE_TYPE) {
            throw 'Selected crop and product-stage not supported by Airflow job-run';
        }

        const runJsonPayload: IRunAnalysisProps = {
            selectedParams: selectedParams,
            selectedVersion: selectedVersion,
            template: template,
            userId: userId
        }

        const evaRunModel = await createRunJsonModal(runJsonPayload, "");

        if (!evaRunModel) {
            throw "EVA run model is not defined.";
        }

        const analyseId = +selectedVersion.analyseId;
        const analyseVersion = selectedVersion.version;

        //step 1 and //step 2 
        const results = await Promise.all([
            createRun(analyseId, analyseVersion, ""),
            createEvaAnalysis(evaRunModel)
        ]);
        const runResponse = results[0];
        const evaResponse = results[1];

        console.log('evaRunModel reportName', evaRunModel.reportName);

        if (runResponse.hasError) {
            throw runResponse.errorMessage;
        }

        if (evaResponse.hasError) {
            throw evaResponse.errorMessage;
        }

        console.log("Eva reportName:", evaResponse.data.reportName);
        console.log("Eva reportVersion:", evaResponse.data.version);
        console.log("Pac RunId", runResponse.data.run.id);

        //step 3 
        const runId = runResponse.data.run.id;
        const taskResponse = await createRunTask(runId, "Eva Analysis", "", evaResponse.data.id.toString());

        if (taskResponse.hasError) {
            throw taskResponse.errorMessage;
        }

        //step 4 
        const taskId = taskResponse.data.runTask.id;
        const taskStatusResponse = await createTaskStatus(taskId, "SUCCESS");
        if (taskStatusResponse.hasError) {
            await createTaskStatus(taskId, "FAILED");
            throw taskStatusResponse.errorMessage;
        }

        //step 5
        //not needed, step 5 is covered by eva-analysis response 

        //step 6
        const externalTaskId = `{\\\"evaReportName\\\":\\\"${evaResponse.data.reportName}\\\",\\\"evaReportVersion\\\":${evaResponse.data.version}}`;
        const airflowTaskRes = await createRunTask(runId, "Create Airflow Job", "", externalTaskId);

        if (airflowTaskRes.hasError) {
            throw airflowTaskRes.errorMessage;
        }

        //step 7
        const executeAirflowRes = await executeAirflow(evaRunModel.reportName, evaResponse.data.version, CROP_LINE_TYPE, runId);
        if (executeAirflowRes.hasError) {
            //IF executeAirflow FAILS then you will need to mark it FAILS and finalize the run:
            await createTaskStatus(airflowTaskRes.data.runTask.id, "FAILURE");
            await finalizeRun(airflowTaskRes.data.runTask.id);
            throw executeAirflowRes.errorMessage;
        }
        //step 8
        const airFlowTaskRes = await createTaskStatus(airflowTaskRes.data.runTask.id, "SUCCESS");

        return {
            reportName: evaResponse.data.reportName,
            reportVersion: evaResponse.data.version,
            pacRunId: runResponse.data.run.id
        };

    } catch (ex) {
        console.log(ex);
        if (_.isString(ex))
            throw ex;
        else
            throw "Failed to run analysis version";
    }
}

const getCropAndLineType = (selectedParams: IPipeline) => {
    const { Crop, ProductStage } = selectedParams;

    let resultType: string = null;

    const crop = Crop.key.toUpperCase();
    const psName = ProductStage.value.toUpperCase();

    if (crop === "CORN") {
        if (["SC1", "SC2", "PS1", "PS2"].includes(psName)) {
            resultType = "CORN_LINE";
        } else if (["PS2.5", "PS3", "PS4"].includes(psName)) {
            resultType = "CORN_HYBRID";
        }
    } else if (crop === "SYBN") {
        if (["SC1", "SC2", "PS1", "PS2"].includes(psName)) {
            resultType = "SOY_LINE";
        }
    }

    return resultType;
};
