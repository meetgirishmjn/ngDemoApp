export interface IEvaRunModel {
  reportName: string;
  id: any;
  description: string;
  modifiedUser: string;
  modifiedDttm: number;
  configurations: IConfigurationEvaRunModel;
}

export interface IConfigurationEvaRunModel {
    model: string;
    crop: string;
    region: string;
    market: string;
    deliveryType: string;
    year: string;
    harvestType: string;
    subMarket: string;
    Required?: IRequired;
}

export interface IRequired {
  [key: string]: any;
  rules?: IRunRuleByDecision;
  constraints?: IRunRuleOrConstraint[];
  comparables?: IComparable[];
}

export interface IRunRuleByDecision {
  [decision: string]: IRunRuleOrConstraint[]
}

export interface IComparable {
  comparable_lookup: string,
  comparable_name: string,
  rule_groups: string[],
}

export interface IRunRuleOrConstraint {
  category: string;
  criteria: string;
  percentage: string;
  distributionNotation: string;
  trait: string;
  operatorNotation: string;
  operator: string;
  value: string;
  value_type_UI: string;
  gender: string;
  rule_group: string;
  decision: string;
  against: string;
  displayValue: string;
  traitOrAttributeDataType: string;
  ruleLevel: string;
  value_type: string;
  sub_market: string;
}

export interface IRunAnalysisResult {
    reportName: string;
    reportVersion: number;
    pacRunId: number
}