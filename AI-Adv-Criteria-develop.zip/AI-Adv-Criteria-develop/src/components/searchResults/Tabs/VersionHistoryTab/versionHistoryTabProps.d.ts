import { VersionHistoryInfo, IModelVersion } from "../../../../actions/criteria/models";

export interface IVersionHistoryTabProps {
  analysesId: string;
  selectedVersion: IModelVersion;
  onCellValueChanged?: (item: VersionHistoryInfo, newValue: string) => void;
  horizonServices?: any;
  hasEntitlements: boolean;
}
