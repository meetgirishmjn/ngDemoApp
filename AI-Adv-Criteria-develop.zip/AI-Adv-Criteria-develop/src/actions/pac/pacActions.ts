import axios from "axios";
import { Dispatch } from "redux";
import pacApi, { pacDevApi } from "../../api/pacApi";
import { IAnalyses, IAnalysisSubType as ISubType } from "../../models/ISearchAnalyses";
import {
  IAnalyticModelVersion,
  IAnalysisSubType,
} from "../../models/IAnalyticModel";
import { ICreateRunResponse, IPacApiBaseRes, ICreateEvaAnalysisResponse, ICreateRunTaskResponse, ICreateTaskStatusResponse, IFinalizeRunResponse, IExecuteAirflowOutput, IUpdateRunResponse, IQueryRunResponse } from "./pac-models";
import { IListItem, IResultData } from "../../models/IResults";
import { ISavedRules } from "src/models/ISavedRules";
import { IEvaRunModel } from "../../models/Eva-models";
import evaApi from "../../api/evaApi";
import types from "../ActionTypes";
import { IModelVersion } from "../criteria/models";
import { IDataset } from "../../models/IGraphTab";
import { ITraitAndSubType } from "../../components/searchResults/Tabs/GraphsTab";

export const getSearchAnalyses = async (
  crop: string,
  year: number,
  region: string,
  harvestType: string,
  market: string
): Promise<IAnalyses[]> => {
  let analyses: IAnalyses[] = [];
  const graphQuery = {
    query: `query searchAnalyses {
            analyses(
                allVersions: true,
                mustHaveSuccessfulRun: false,
                parameterQuery: "{ \\"CROP\\": [\\"${crop}\\"], \\"REGION\\": [\\"${region}\\"], \\"HARVEST_TYPE\\": [\\"${harvestType}\\"], \\"MARKET\\": [\\"${market}\\"], \\"HARVEST_YEAR\\" : [\\"${year}\\"]}" analysisSubTypes: ["PRESC_INB"]
                ) {
                id
                version
                lastSuccessfulRun {
                    id
                    isFinished
                    currentStatus
                    finalizedStatus
                }
                lastRun{
                      id
                      isFinished
                      currentStatus
                      finalizedStatus
                }
                name
                description
                analyticModelVersionId
                analysisSubType {
                    id
                    name
                }
                runs{
                      id
                      isFinished
                        currentStatus
                      finalizedStatus
                    }
            }
        }`,
  };
  await pacApi
    .post("/graphql", graphQuery)
    .then((response) => {
      analyses = response.data && (response.data.data.analyses as IAnalyses[]);
    })
    .catch((error) => console.log(error));
  return analyses;
};

export const getAnalyticModelVersion = async (
  ids: string[]
): Promise<IAnalyticModelVersion[]> => {
  const analyticModelData: IAnalyticModelVersion[] = [];
  const allRequests: any[] = [];
  ids.forEach((id) => {
    allRequests.push(createAnalyticModelVersionRequest(id));
  });
  try {
    const responses = await axios.all(allRequests);
    responses.forEach((response) => {
      analyticModelData.push(
        response.data &&
        (response.data.data.analyticModelVersion as IAnalyticModelVersion)
      );
    });
  } catch (err) {
    console.log(err);
  }
  return analyticModelData;
};

export const createAnalyticModelVersionRequest = async (id: string) => {
  const graphQuery = {
    query: `query{analyticModelVersion(id: ${id}) {
            id
            isDecisionEngine
            analyticModel{name
              isActive
             versions {
                  id
                  releaseUrl
                  isActive
                }
              analysisType {
                id
                name
              }
            }
            }
          }`,
  };
  return pacApi.post("/graphql", graphQuery);
};

export const getAnalyseSubTypes = async (
  crop: string,
  year: number,
  region: string,
  harvestType: string,
  market: string = null
): Promise<IAnalysisSubType[]> => {
  const results: IAnalysisSubType[] = [];

  let marketParamStr = "";
  if (market !== null) {
    marketParamStr = `\\"MARKET\\": [\\"${market}\\"],`;
  }

  const graphQuery = {
    query: `query searchAnalyses {
            analyses(
                allVersions: true,
                mustHaveSuccessfulRun: false,
                parameterQuery: "{ \\"CROP\\": [\\"${crop}\\"], \\"REGION\\": [\\"${region}\\"], \\"HARVEST_TYPE\\": [\\"${harvestType}\\"], ${marketParamStr} \\"HARVEST_YEAR\\" : [\\"${year}\\"]}"
                ) {
                name
                id
                description
                columnGroupId
                isActive
                analysisSubType {
                  id
                  name
                  isActive
                }
            analyticModelVersion{
                    analyticModel{
                    analysisType{
                        id
                        name
                    }
                    }
                }
            }
        }`,
  };
  await pacApi
    .post("/graphql", graphQuery)
    .then((response) => {
      if (response.data && response.data.data.analyses) {
        response.data.data.analyses.forEach((o) => {
          if (o.isActive === true && o.analysisSubType) {
            results.push({
              uid: `${o.id}_${o.columnGroupId}_${o.analysisSubType.id}`,
              analysisId: o.id,
              analysisName: o.name,
              analysisDescription: o.description,
              analysisSubTypeId: o.analysisSubType.id,
              analysisSubTypeName: o.analysisSubType.name,
              analyticModelType:
                o.analyticModelVersion.analyticModel.analysisType.name,
            });
          }
        });
      }
    })
    .catch((error) => console.log(error));
  return results;
};

export const getAnalyseSubTypesForPrescSources = async (
  crop: string,
  year: number,
  region: string,
  harvestType: string,
  market: string
): Promise<IAnalysisSubType[]> => {

  //call with and without market parameter
  const results = await Promise.all([
    getAnalyseSubTypes(
      crop,
      year,
      region,
      harvestType,
      market
    ),
    getAnalyseSubTypes(
      crop,
      year,
      region,
      harvestType
    )]);

  let analysisSubTypes: IAnalysisSubType[] = [...results[0]];

  //take from result of without market parameter
  (results[1] || []).forEach(item => {

    //only take if not already exist in analysisSubTypes
    if (!analysisSubTypes.find(o => {
      return o.uid === item.uid && o.analysisName === item.analysisName
    })) {
      analysisSubTypes.push(item);
    }
  });

  return analysisSubTypes;
}

export const GetRunAnalysisReasons = async (): Promise<IListItem[]> => {
  const results: IListItem[] = [];
  results.push({
    id: "adjustedAllocation",
    name: "Adjusted Allocation"
  });
  results.push({
    id: "adjustedRules",
    name: "Adjusted Rules"
  });
  results.push({
    id: "adjustedTargets",
    name: "Adjusted Targets"
  });
  results.push({
    id: "adjustedWeights",
    name: "Adjusted Weights"
  });
  results.push({
    id: "dayOfAdvancements",
    name: "Day of Advancements"
  });
  results.push({
    id: "runAfterMigration",
    name: "Run After Migration"
  });
  results.push({
    id: "other",
    name: "Other"
  });
  return results;
}

export const createRun = async (
  analysisId: number,
  analysisVersion: number,
  runUrl: string
): Promise<IPacApiBaseRes<ICreateRunResponse>> => {

  let response: IPacApiBaseRes<ICreateRunResponse> = {
    hasError: false
  };

  const graphQuery = {
    query: `mutation createRun {
                 createRun(input: {
                     analysisId: ${analysisId},
                     analysisVersion:  ${analysisVersion},
                     runUrl: "${runUrl}"
                 }){
                     uploadUrl 
                     run{
                     id
                     }
                }
             }`,
  };
  try {
    const apiRes = await pacApi.post("/graphql", graphQuery);
    if (apiRes.data.data.createRun) {
      response.hasError = false;
      response.data = apiRes.data.data.createRun as ICreateRunResponse;
    } else {
      response.hasError = true;
      response.errorMessage = (apiRes.data.errors || []).join();
    }
  } catch (ex) {
    response.hasError = true;
    response.errorMessage = "Unkonwn error occured";
    console.log(ex)
  }
  return response;
};

export const createEvaAnalysis = async (
  runModel: IEvaRunModel
): Promise<IPacApiBaseRes<ICreateEvaAnalysisResponse>> => {

  let response: IPacApiBaseRes<ICreateEvaAnalysisResponse> = {
    hasError: false
  };

  try {
    const apiRes = await evaApi.post("/analysis/create", runModel);
    if (apiRes.data) {
      response.hasError = false;
      response.data = apiRes.data as ICreateEvaAnalysisResponse;
    } else {
      response.hasError = true;
      response.errorMessage = "Unkonwn error occured";
    }
  } catch (ex) {
    response.hasError = true;
    let msg = "Unkonwn error occured";
    if (ex.message) {
      msg = ex.message;
    }
    response.errorMessage = msg;
    console.log(ex)
  }
  return response;
};

export const createRunTask = async (
  runId: number,
  name: string,
  description: string,
  externalTaskId: string
): Promise<IPacApiBaseRes<ICreateRunTaskResponse>> => {

  let response: IPacApiBaseRes<ICreateRunTaskResponse> = {
    hasError: false
  };

  const graphQuery = {
    query: `mutation createRunTask  {
                 createRunTask (input: {
                     runId: ${runId},
                     name:  "${name}",
                     description:  "${description}",
                     externalTaskId:  "${externalTaskId}"
                 }){
                     runTask{
                     id
                     }
                }
             }`,
  };
  try {
    const apiRes = await pacApi.post("/graphql", graphQuery);
    if (apiRes.data.data.createRunTask) {
      response.hasError = false;
      response.data = apiRes.data.data.createRunTask as ICreateRunTaskResponse;
    } else {
      response.hasError = true;
      response.errorMessage = (apiRes.data.errors || []).join();
    }
  } catch (ex) {
    response.hasError = true;
    response.errorMessage = "Unkonwn error occured";
    console.log(ex)
  }
  return response;
};

export const createTaskStatus = async (
  taskId: number,
  statusMessage: string
): Promise<IPacApiBaseRes<ICreateTaskStatusResponse>> => {

  let response: IPacApiBaseRes<ICreateTaskStatusResponse> = {
    hasError: false
  };

  const graphQuery = {
    query: `mutation createTaskStatus {
                 createTaskStatus(input: {
                         taskId: ${taskId},
                         statusMessage: "${statusMessage}"
                         }){
                             taskStatus{
                                id
                             }
                         }
                 }`,
  };
  try {
    const apiRes = await pacApi.post("/graphql", graphQuery);
    if (apiRes.data.data.createTaskStatus) {
      response.hasError = false;
      response.data = apiRes.data.data.createTaskStatus as ICreateTaskStatusResponse;
    } else {
      response.hasError = true;
      console.log(apiRes);
      response.errorMessage = (apiRes.data.errors || []).join();
    }
  } catch (ex) {
    response.hasError = true;
    response.errorMessage = "Unkonwn error occured";
    console.log(ex)
  }
  return response;
};

export const finalizeRun = async (
  taskId: number
): Promise<IPacApiBaseRes<IFinalizeRunResponse>> => {

  let response: IPacApiBaseRes<IFinalizeRunResponse> = {
    hasError: false
  };

  const graphQuery = {
    query: `mutation finalizeRun {
                 finalizeRun(input: {
                         id: ${taskId}
                         }){
                             run{
                              id
                            }
                         }
                 }`,
  };
  try {
    const apiRes = await pacApi.post("/graphql", graphQuery);
    if (apiRes.data.data.finalizeRun) {
      response.hasError = false;
      response.data = apiRes.data.data.finalizeRun as IFinalizeRunResponse;
    } else {
      response.hasError = true;
      response.errorMessage = "Unkonwn error occured";
    }
  } catch (ex) {
    response.hasError = true;
    response.errorMessage = "Unkonwn error occured";
    console.log(ex)
  }
  return response;
};

export const executeAirflow = async (
  reportName: string,
  reportVersion: number,
    cropAndLineType: string,
    runId:number
): Promise<IPacApiBaseRes<IExecuteAirflowOutput>> => {

  let response: IPacApiBaseRes<IExecuteAirflowOutput> = {
    hasError: false
  };

  const graphQuery = {
    query: `mutation executeAirflow {
                 executeAirflow(evaAirflowInput: {
                        runId: ${runId},
                        blob: "{}",
                        reportName: "${reportName}",
                        reportVersion: ${reportVersion}
                        cropAndLineType:${cropAndLineType}
                        }){
                            output
                        }
                 }`,
  };
  try {
    let apiPromise = null;

    if (isDevEnt()) {
      apiPromise = pacDevApi.post("/graphql", graphQuery);
    } else {
      apiPromise = pacApi.post("/graphql", graphQuery);
    }

    const apiRes = await apiPromise;
    if (apiRes.data.data.executeAirflow) {
      response.hasError = false;
      response.data = apiRes.data.data.executeAirflow.output as IExecuteAirflowOutput;
    } else {
      response.hasError = true;
      response.errorMessage = "Unkonwn error occured";
    }
  } catch (ex) {
    response.hasError = true;
    response.errorMessage = "Unkonwn error occured";
    console.log(ex)
  }
  return response;
};

export const getRules = async (analysisId: string, version: number) => {
  // 11241 hardcoded as of now since it has rules
  let response: ISavedRules = null;
  const graphQuery = {
    query: `query GE_Analysis {
      analysis(id: ${analysisId}, version: ${version}) {
        id
        version
        rules
        analyticModelVersionId
        analysisSubTypeId
      }
    }`
  }
  try {
    const res = await pacApi.post("/graphql", graphQuery);
    response = res.data && res.data.data;
  } catch (ex) {
    console.log(ex);
  }
  return response;
}
/*
  saves the traits from define data for a selected pipeline
*/
export const saveGraphsData = (traits: ITraitAndSubType[], pipelineName: string, prescData: IResultData, selectedVersion: IModelVersion) => {
  return (dispatch: Dispatch) => {
    dispatch({
      type: types.SAVE_GRAPH_DATA,
      payload: {
        traitsForSelectedPipeline: {
          [pipelineName]: traits
        },
        prescForSelectedAnalyses: {
          [`${pipelineName}_${selectedVersion.analyseId}_${selectedVersion.version}`]: prescData
        }
      },
    });
  };
};

export const saveBlupsData = (key: string, dataSet: IDataset) => {
  return (dispatch: Dispatch) => {
    dispatch({
      type: types.SAVE_BLUPS,
      payload: {
        key,
        dataSet
      }
    })
  }
}

export const deleteBlupsData = () => {
  return (dispatch: Dispatch) => {
    dispatch({
      type: types.DELETE_BLUPS
    })
  }
}

export const getAllAnalysisSubTypes = async () => {
  let response: ISubType[] = [];
  const graphQuery = {
    query: `query {
      analysisSubTypes {
        id
        name
      }
    }`
  }
  try {
    const res = await pacApi.post("/graphql", graphQuery);
    response = res.data && res.data.data && res.data.data.analysisSubTypes as ISubType[] ;
  } catch (ex) {
    console.log(ex);
  }
  return response;
}

const isDevEnt = () => {
  //if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
  //  return true;
  //} else {
  //  return false;
  //}
    return false;
}

export const queryRun = async (runId: number) => {
    let response: IPacApiBaseRes<IQueryRunResponse> = {
        hasError: false
    };
    const graphQuery = {
        query: `query run {
              run(id: ${runId}){
                id
                isFinished
                isUsedForAdvancements
                finalizedStatus
            }
            }`
    };

    try {
        const apiRes = await pacApi.post("/graphql", graphQuery);
        if (apiRes.data.data.run) {
            response.hasError = false;
            response.data = apiRes.data.data.run as IQueryRunResponse;
        } else {
            response.hasError = true;
            response.errorMessage = (apiRes.data.errors || []).join();
        }
    } catch (ex) {
        response.hasError = true;
        response.errorMessage = "Unkonwn error occured";
        console.log(ex)
    }
    return response;
}

export const updateRun = async (runId: number, isUsedForAdvancements: boolean, usedForAdvancementsReason:string) => {
    let response: IPacApiBaseRes<IUpdateRunResponse> = {
        hasError: false
    };
    const graphQuery = {
        query: `mutation updateRun {
                  updateRun(input: {
                    id: ${runId}
                    isUsedForAdvancements:  ${isUsedForAdvancements}
                    usedForAdvancementsReason: " ${usedForAdvancementsReason}"
                  }) {
                    run {
                      id
                      isUsedForAdvancements
                      usedForAdvancementsReason
                    }
                  }
                }`
    };

    try {
        const apiRes = await pacApi.post("/graphql", graphQuery);
        if (apiRes.data.data.updateRun) {
            response.hasError = false;
            response.data = apiRes.data.data.updateRun as IUpdateRunResponse;
        } else {
            response.hasError = true;
            response.errorMessage = (apiRes.data.errors || []).join();
        }
    } catch (ex) {
        response.hasError = true;
        response.errorMessage = "Unkonwn error occured";
        console.log(ex)
    }
    return response;
}