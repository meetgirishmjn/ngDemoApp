import * as React from "react";
import { connect } from "react-redux";
import PipelineSharedComponent from "../PipelineSharedComponent/PipelineSharedComponent";
import IProps from "./IParameterSelectionProps";
import IState from "./IParameterSelectionState";
import { PipelineSelect } from "@monsantoit/ui-react-pipeline-select";
import IRootStore from "src/store/IRootStore";
import RouterConstants from "../../../common/router-constants";
import _ from "lodash";
import { withRouter } from "react-router-dom";
import { DropDown } from "@monsantoit/ui-react-base-controls";
import Logger from "../../../common/logger";
import {
  getUserPreferences,
  saveUserPreferences,
} from "../../../actions/userPreferences/userPreferencesActions";

export class ParameterSelection extends React.Component<IProps, IState> {
  public PipelineSharedComponentRef = React.createRef<PipelineSelect>();
  public deDropdownRef = React.createRef<DropDown>();

  constructor(props) {
    super(props);
    this.state = {
      Pipeline: null,
      userPreferences: null,
    };
  }

  public componentDidMount() {
    const { getUserPreferences, HorizonServices } = this.props;
    getUserPreferences(HorizonServices);
  }

  public render() {
    return this.MainRenderer();
  }

  private isSubmitDisabled = () => {
    return (
      this.state.Pipeline &&
      this.state.Pipeline.Crop &&
      this.state.Pipeline.Year &&
      this.state.Pipeline.Region &&
      this.state.Pipeline.HarvestType &&
      this.state.Pipeline.Market &&
      this.state.Pipeline.SubMarket &&
      this.state.Pipeline.StageType &&
      this.state.Pipeline.ProductStage &&
      this.state.Pipeline.Trait &&
      this.state.Pipeline.DecisionEngine
    );
  };

  private submit = () => {
    const { history, userId } = this.props;
    Logger.logInfo("Parameter-Selections submitted", userId);
    this.props.saveUserPreferences(
      this.state.Pipeline,
      this.props.HorizonServices
    );
    history.push(RouterConstants.RESULTS);
  };

  private clearAll = () => {
    if (this.PipelineSharedComponentRef) {
      this.PipelineSharedComponentRef.current.ClearAll();
    }
    this.deDropdownRef && this.deDropdownRef.current.updateSelections([], true);
  };

  private handleSelectionChanged = (Pipeline: IPipeline) => {
    this.setState({ Pipeline });
  };

  private MainRenderer = (): JSX.Element => {
    return (
      <div className="m-24 ">
        {this.props.userPreferences && (
          <div className="card p-24">
            <h2 className="card-title mb-24">Select Parameters</h2>
            <div>
              <PipelineSharedComponent
                setSelectorRef={this.PipelineSharedComponentRef}
                onSelectionChanged={this.handleSelectionChanged}
                HorizonServices={this.props.HorizonServices}
                deSelectorRef={this.deDropdownRef}
                Pipeline={this.props.userPreferences}
              />
            </div>
            <div className="mt-48">
              <label className="txt14 color-status-red">
                All selections required.
              </label>
              <div style={{ float: "right" }}>
                <button
                  className="btn-local btn-tertiary color-primary"
                  onClick={this.clearAll}
                >
                  CLEAR ALL
                </button>
                <button
                  className={
                    this.isSubmitDisabled()
                      ? "btn-local btn-tertiary color-primary"
                      : "btn-local btn-tertiary"
                  }
                  id="pipeline-submit-btn"
                  onClick={this.submit}
                  disabled={!this.isSubmitDisabled()}
                >
                  SUBMIT
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };
}

const stateToProps = (state: IRootStore) => {
  return {
    userId: state.auth.user_id,
    userPreferences: state.userPreferences.userPreferences,
  };
};

export default connect(stateToProps, {
  getUserPreferences,
  saveUserPreferences,
})(withRouter(ParameterSelection));
