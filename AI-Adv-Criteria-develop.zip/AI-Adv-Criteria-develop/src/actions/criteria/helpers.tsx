import {
  IConfigField,
  FieldTypes,
  IValidationResult,
  IGraphqlBaseRes,
  GraphqlApiErrorCodes,
  IModelVersion,
} from "./models";
import { IAnalyses } from "../../models/ISearchAnalyses";

export const validateField = (
  field: IConfigField,
  value: string
): IValidationResult => {
  const result: IValidationResult = { isValid: true, message: "" };
  const validator = JSON.parse(field.validators);
  if (field.isReadOnly) {
    return result;
  }
  const isEmpty = (value || "").length === 0;

  if (field.isRequired && isEmpty) {
    result.isValid = false;
    result.message = "Value must not be empty";
    return result;
  }

  if (!isEmpty) {
    if (
      field.dataType === FieldTypes.Integer ||
      field.dataType === FieldTypes.PositiveInteger ||
      field.dataType === FieldTypes.Number
    ) {
      const intValue = parseInt(value, 10);

      // check if entered value is not an integer
      if (intValue.toString() !== value) {
        result.isValid = false;
        result.message = "Value must be a whole number";
        return result;
      }

      if (field.dataType === FieldTypes.PositiveInteger && intValue <= 0) {
        result.isValid = false;
        result.message = "Value must be a positive whole number";
        return result;
      }
    }

    if (validator) {
      if (validator.type === "range") {
        let minValue = validator.arguments.lower_bound;
        let maxValue = validator.arguments.upper_bound;

        if (field.dataType === FieldTypes.Percentage) {
          minValue = minValue || 0;
          maxValue = maxValue || 100;
        }

        if (value < minValue) {
          result.isValid = false;
          result.message = `Value must not be smaller than ${minValue}`;
          return result;
        }
        if (value > maxValue) {
          result.isValid = false;
          result.message = `Value must not be greater than ${maxValue}`;
          return result;
        }
      }
    } else {
      if (field.minLength && value.length < field.minLength) {
        result.isValid = false;
        result.message = `Value must have minimum ${field.minLength} character${field.minLength > 1 ? "s" : ""
          }`;
        return result;
      }
      if (field.maxLength && value.length > field.maxLength) {
        result.isValid = false;
        result.message = `Value must have maximum ${field.maxLength} character${field.maxLength > 1 ? "s" : ""
          }`;
        return result;
      }
    }
    if (field.dataType === FieldTypes.Email) {
      const EMAIL_REG_EXP = new RegExp(
        /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
      );
      if (!EMAIL_REG_EXP.test(value)) {
        result.isValid = false;
        result.message = "Value must be a valid email";
        return result;
      }
    }
  }

  return result;
};

export const calculateFieldValue = (value: string, operation: string) => {
  let calculatedValue = "";
  switch (operation) {
    case "REST_OF_PERCENTAGE":
      calculatedValue =
        value && parseInt(value, 10) <= 100
          ? (100 - parseInt(value, 10)).toString()
          : "";
      break;
    default:
      break;
  }
  return calculatedValue;
};

export function parseGraphqlApiResponse<T>(data: any): IGraphqlBaseRes<T> {
  const result: IGraphqlBaseRes<T> = {
    hasError: true,
    errorMessage: "",
    errorCode: GraphqlApiErrorCodes.UNKNOWN,
    data: null,
  };
  try {
    if (!data) {
      return result;
    }

    if (data.errors && data.errors.length) {
      // has error, take first error
      result.errorMessage = data.errors[0].message;
      result.errorCode = data.errors[0].extensions
        ? data.errors[0].extensions.code
        : GraphqlApiErrorCodes.UNKNOWN;
    } else {
      // no error
      if (data.data) {
        result.data = data.data;
        if (result.data) {
          result.hasError = false;
        }
      }
    }
  } catch (err) {
    result.errorMessage = "Failed to parse api response";
  }

  return result;
}

export const convertToAnalysisModel = (
    analysisRes: IAnalyses
): IModelVersion => {
    let isLocked = false;
    let isInProgress = false;
    if (analysisRes.lastSuccessfulRun) {
        if (analysisRes.lastSuccessfulRun.finalizedStatus === "SUCCESS") {
            isLocked = true;
        } else if (analysisRes.lastSuccessfulRun.finalizedStatus !== "FAILURE") {
            // if not success or failure then analyse status must be running or queuing etc
            isInProgress = true;
        }
    }

    //if lastSuccessfulRun will not be available if lastRun is not finished/is in RUNNING Or Queued
    if (analysisRes.lastRun && !analysisRes.lastRun.isFinished) {
        isInProgress = true;
    }

    const result: IModelVersion = {
        uid: `${analysisRes.id}_${analysisRes.name}_${analysisRes.version}`,
        analyseId: analysisRes.id.toString(),
        name: analysisRes.name,
        version: +analysisRes.version,
        versionDesc: `${analysisRes.name}_v${analysisRes.version}`,
        isLocked,
        isInProgress,
        runs: analysisRes.runs
    };

    return result;
};