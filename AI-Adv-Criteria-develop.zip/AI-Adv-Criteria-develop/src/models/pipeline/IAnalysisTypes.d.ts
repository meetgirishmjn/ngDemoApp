interface IAnalysisType {
  name: string;
}
