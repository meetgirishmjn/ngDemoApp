import IRootStore from "./IRootStore";

const defaultState: IRootStore = {
  auth: {
    isAuthenticated: null,
    access_token: null,
    user_id: null,
  },
  userPreferences: {
    userPreferences: null,
    loadingUserPreferences: false,
  },
  criteria: {
      saveClick: "",
      analysisInRun: null,
      isRunButtonValid: true
  },
  graphData: {
    traitsForSelectedPipeline: {},
    prescForSelectedAnalyses: {},
    blupsDataForSelectedVersion: {}
  }
};

export default defaultState;
