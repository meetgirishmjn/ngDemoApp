import React, { Component } from "react";
import { connect } from "react-redux";
import { DropDown } from "@monsantoit/ui-react-base-controls";
import IVersionSelectorProps from "./VersionSelectorProps";
import IVersionSelectorState from "./VersionSelectorState";
import {
  IModelVersion
} from "../../../actions/criteria/models";
import Modal from "react-bootstrap4-modal";
import "./versionSelector.scss";
import {
  onSaveButtonClick,
  createAnalysisVersionFromSource,
} from "../../../actions/criteria/criteriaActions";
import { isEqual } from "lodash";
import { IListItem } from "../../../models/IGraphTab";
import RunAnalysisModal from "./runAnalysisModal";
import IRootStore from "../../../store/IRootStore";
import { ViewTypes } from "../SearchResultsState";
import SaveToAdvModal from "./saveToAdvModal";
import _ from "lodash";
import { runAnalysisModel } from "./runAnalysisModal/helper";

class VersionSelector extends Component<
  IVersionSelectorProps,
  IVersionSelectorState
> {
  public versionRef: any;
  public isModalDialogVisible: boolean = false;
    constructor(props: IVersionSelectorProps) {
        super(props);
        this.state = {
            viewType: props.viewType || ViewTypes.Default,
            selectedVersion: null,
            modelVersions: [],
            isVersionDataLoading: this.props.isVersionDataLoading,
            showMenu: false,
            isCreateVersionInProgress: false,
            isVersionDialogVisible: false,
            isRunAnalysisModalVisible: false,
            isSaveToAdvModalVisible:false,
            createVerDialogKey: new Date().toString(),
            createVersionFromSource: null,
            selectedRunId:props.selectedRunId,
            isRefreshinProgress: false
        };
    }

  public componentWillMount() {
    document.addEventListener("click", this.handleOutsideClick, false);
  }

  public componentWillUnmount() {
    document.removeEventListener("click", this.handleOutsideClick, false);
  }

  public componentWillReceiveProps(nextProps: IVersionSelectorProps) {
      if (
          nextProps.isVersionDataLoading !== this.state.isVersionDataLoading ||
          !isEqual(nextProps.versions, this.state.modelVersions) ||
          nextProps.selectedVersion !== this.state.selectedVersion
      ) {
          this.setState({
              isVersionDataLoading: nextProps.isVersionDataLoading,
              modelVersions: nextProps.versions,
              selectedVersion: nextProps.selectedVersion,
          });
      }

      if (nextProps.viewType !== this.state.viewType) {
          this.setState({ viewType: nextProps.viewType });
      }

      if (nextProps.selectedRunId !== this.state.selectedRunId) {
          this.setState({ selectedRunId: nextProps.selectedRunId });
      }
  }

  public handleOutsideClick = (event) => {
    if (this.versionRef && !this.versionRef.contains(event.target)) {
      this.setState({ showMenu: false });
    }
  };

  public onVersionSelectionChanged = (version: IModelVersion) => {
    this.setState({ selectedVersion: version, showMenu: false });
    if (this.props.onVersionSelectionChanged) {
      this.props.onVersionSelectionChanged(version);
    }
  };

  public showMenu = () => {
    this.setState({ showMenu: !this.state.showMenu });
  };

  public openCreateVersionDialog = async () => {
      this.setState({
          isVersionDialogVisible: true,
          createVersionFromSource:this.state.selectedVersion,
          createVerDialogKey: new Date().toString()
      });
  };

  public openDecEngineDialog = () => {

      if (!this.state.selectedVersion)
          return;

      if (this.state.selectedVersion.isInProgress) {
          this.props.horizonServices.toast.warning('Analysis is already running. Please wait till it finishes.');
          return;
      }

      this.setState({ isRunAnalysisModalVisible: true });
  };

  openRefreshDialog = () => {
    this.isModalDialogVisible = true;
    this.onRefreshAnalysisClick();
  }

  private hideModalDialog = () => {
    this.isModalDialogVisible = false;
  }

  private onRefreshAnaLysisOkClick = async () => {
    try {
      this.setState({ isRefreshinProgress: true });
      await runAnalysisModel(this.props.selectedParams, this.state.selectedVersion, this.props.template, this.props.userId, "");
      this.hideModalDialog();
      this.props.horizonServices.toast.success("Analysis refresh successful");      
      this.setState({ isRefreshinProgress: false });
    } catch (ex) {
      // this.hideModalDialog();
      this.setState({ isRefreshinProgress: false });
      this.props.horizonServices.toast.error(ex);
    }
  }

  private onRefreshAnalysisClick = () => {
    if (!this.state.selectedVersion)
      return;
    else {
      return(
        <Modal
          className="ui-react-confirmation-dlg refresh-analysis-modal"
          visible={this.isModalDialogVisible}
        >
          <div className="modal-body">
            <button
              type="button"
              className="close"
              onClick={() => this.hideModalDialog()}
              aria-label="Close"
            >
              <i
                id="close-button-icon"
                aria-hidden="true"
                className="material-icons"
              >
                clear
              </i>
            </button>
            <div className="text-center confirmation-dlg-message-area">
              <div className="confirmation-dlg-title">
                <h1>Refresh Analysis</h1>
              </div>
              <div className="confirmation-dlg-sub-text">
                <p>Are you sure you want to Refresh Analysis?</p>
              </div>
            </div>
          </div>
          <div className="dlg-footer d-flex justify-content-center">
            <button
              type="button"
              onClick={() => this.hideModalDialog()}
              className="btn confirmation-dlg-btn-cancel"
            >
              Cancel
            </button>
            {!this.state.isRefreshinProgress && (
              <button
                type="button"
                className="btn bg-color-primary hover-background-medium confirmation-dlg-btn-primary-default"
                onClick={() => this.onRefreshAnaLysisOkClick() }
              >
                Run
              </button>
            )}
            {this.state.isRefreshinProgress && (
              <button
                className="btn bg-color-primary confirmation-dlg-btn-primary-default"
                type="button"
                disabled={true}
              >
                <span className="spinner-grow spinner-grow-sm" />
                Please wait...
              </button>
            )}
          </div>
        </Modal>
      )
    }    
  } 

  public onCreateVersionOkClick = async () => {
    this.setState({ isCreateVersionInProgress: true });
    try {

      const sourceAnalysis = this.state.createVersionFromSource;

      if (!sourceAnalysis) {
        return;
      }

      const result = await createAnalysisVersionFromSource(
        +sourceAnalysis.analyseId,
        sourceAnalysis.version
      );

      if (result.hasError) {
        this.props.horizonServices.toast.error(result.errorMessage);
      } else {
        this.props.horizonServices.toast.success("Analysis version created");
        const newVersion = result.data;
        this.setState({
          isVersionDialogVisible: false,
        });
        this.props.onVersionCreated(newVersion);
      }
    } catch (ex) {
      this.props.horizonServices.toast.error(
        "Failed to create analysis version"
      );
    } finally {
      this.setState({ isCreateVersionInProgress: false });
    }
  };

    public openSaveToAdvDialog = () => {

        if (!this.state.selectedVersion)
            return;

        this.setState({ isSaveToAdvModalVisible: true });
    };

    public convertRunIdsToList = (version: IModelVersion): IListItem[] => {
        if (!version)
            return [];

        let runs = (version.runs || []).filter(o => o.currentStatus === "SUCCESS");
        runs = _.orderBy(runs, (o) => o.id, "desc");
        return runs.map((o, index) => {
            return {
                id: o.id.toString(),
                text: `${o.id}${index === 0 ? ' (latest run)' : ''}`
            } as IListItem
        });
    }

  public renderVerDropdown = () => {
    const { showMenu } = this.state;
    return (
      <div
        className="ui-react-dropdown ml-2"
        ref={(node) => (this.versionRef = node)}
      >
        <div className="dropdown">
          <button
            className={`btn btn-default dropdown-toggle d-flex ${
              this.state.isVersionDataLoading ? "disabled" : ""
            }`}
            type="button"
            onClick={this.showMenu}
          >
            {this.state.isVersionDataLoading && (
              <span className="ui-react-dropdown-ellipsis-span">
                <span className="ui-react-dropdown-spinner">Loading</span>
              </span>
            )}
            {!this.state.isVersionDataLoading &&
              (!this.state.selectedVersion ? (
                <>
                  <span className="selectedText">
                    {this.state.modelVersions.length
                      ? "Select..."
                      : "No Selections"}
                  </span>
                </>
              ) : (
                <>
                  <i className="material-icons">
                    {this.state.selectedVersion.isLocked ? "lock" : "lock_open"}
                  </i>{" "}
                  <span className="selectedText">
                    {this.state.selectedVersion.versionDesc}
                  </span>
                </>
              ))}
          </button>
          <div className={`dropdown-menu ${showMenu ? "show" : "hide"}`}>
            {this.state.modelVersions.map((o) => (
              <div
                key={o.uid}
                onClick={() => this.onVersionSelectionChanged(o)}
                className="d-flex dropdown-item dropdown-item ui-react-dropdown-item hover-background-primary"
              >
                <i className="material-icons">
                  {o.isLocked ? "lock" : "lock_open"}
                </i>{" "}
                <span className="selectedText">{o.versionDesc}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

    public renderRunIdDropdown = () => {
        let selectedRunId = this.state.selectedRunId
        const runIdList = this.convertRunIdsToList(this.state.selectedVersion);

        if (!selectedRunId && runIdList.length) {
            selectedRunId = +runIdList[0].id;
        }

        return (
            <div className="runIdsDrowdown">
                <DropDown
                    name={"RunID"}
                    isMultiselect={false}
                    sorted={false}
                    placeholder={"Select"}
                    data={runIdList}
                    textProperty={"text"}
                    hasAllCheckbox={false}
                    selectedItem={runIdList.find(o => +o.id === +selectedRunId)}
                    onSelectionChanged={(name: string, item: IListItem) => {
                        this.setState({ selectedRunId: +item.id });
                        this.props?.onRunIdSelectionChanged(this.state.selectedVersion, +item.id);
                    }}
                />
            </div>
        );
    };

  public onViewResultsClick = () => {
    this.props.onViewResultsClick();
  };
 
  public save = () => {
    this.props.onSaveButtonClick();
  };

  public renderActionButtons(): JSX.Element {
    const iconRun = `${process.env.BASE_PATH}/assets/icon-run.png`;
    const iconSave = `${process.env.BASE_PATH}/assets/icon-save.png`;
    const iconViewResults = `${process.env.BASE_PATH}/assets/icon-viewresults.png`;
    const iconRefresh = `${process.env.BASE_PATH}/assets/icon-refresh.png`;
    const { hasEntitlements } = this.props;

    const isLocked = this.state.selectedVersion
      ? this.state.selectedVersion.isLocked
      : false;

    if (isLocked) {
        return (
          <>
            <div className="d-flex justify-content-end bd-highlight mb-3">
              <div className={hasEntitlements ? "action-col" : "action-col pointer-events"}>
                <a onClick={this.openRefreshDialog} href="#" className="refresh-link" title="Click to refresh">
                  <img src={iconRefresh} />
                  <span className={hasEntitlements ? "action-col-span" : "action-col-span-disabled"}>Refresh Analysis</span>
                </a>
              </div>
              <div className="action-col">
                {this.state.viewType === ViewTypes.Default && <a
                  href="#"
                  className="results-link"
                  title="Click to view"
                  onClick={this.onViewResultsClick}
                >
                  <img src={iconViewResults} />
                  <span className="action-col-span">View Results</span>
                </a>}
                {this.state.viewType === ViewTypes.ViewResults && <a
                  href="#"
                  className="results-link"
                  title="Click to save"
                  onClick={this.openSaveToAdvDialog}
                >
                  <img src={iconSave} />
                  <span className="action-col-span">Save for Adv</span>
                </a>}
              </div>
            </div>
          </>
      );
    }

    return (
      <div className="d-flex justify-content-end bd-highlight mb-3">
        <div
          className={
            hasEntitlements ? this.props.enableRunButton ? "action-col" : "action-col pointer-events" : "action-col pointer-events"
          }
        >
          <a href="#" title="Click to run" onClick={this.openDecEngineDialog}>
            <img src={iconRun} />
            <span
              className={
                hasEntitlements ? this.props.enableRunButton ? "action-col-span" : "action-col-span-disabled" :   "action-col-span-disabled"
              }
            >
              Run
            </span>
          </a>
        </div>
        <div
          className={
            hasEntitlements ? "action-col" : "action-col pointer-events"
          }
        >
          <a href="#" title="Click to save" onClick={this.save}>
            <img src={iconSave} />
            <span
              className={
                hasEntitlements ? "action-col-span" : "action-col-span-disabled"
              }
            >
              Save
            </span>
          </a>
        </div>
      </div>
    );
  }

    public renderNewVersionModalDialog = () => {
        if (!this.state.selectedVersion) {
            return <></>;
        }
        return (
            <Modal key={this.state.createVerDialogKey}
                visible={this.state.isVersionDialogVisible}
                className="ui-react-confirmation-dlg"
            >
                <div className="modal-body">
                    <button
                        type="button"
                        className="close"
                        onClick={() => this.setState({ isVersionDialogVisible: false })}
                        aria-label="Close"
                    >
                        <i
                            id="close-button-icon"
                            aria-hidden="true"
                            className="material-icons"
                        >
                            clear
            </i>
                    </button>
                    <div className="text-center confirmation-dlg-message-area">
                        <div className="confirmation-dlg-title">
                            <h1>Create New Version</h1>
                        </div>
                        <div className="confirmation-dlg-sub-text">
                            <p>
                                Select the version you would like to duplicate to create a new
                                version.
              </p>
                        </div>
                        <div className="create-new-version-dropdown-container">
                            <DropDown
                                name={"createNewVersion"}
                                isMultiselect={false}
                                sorted={false}
                                data={this.state.modelVersions}
                                textProperty={"versionDesc"}
                                selectedItem={this.state.createVersionFromSource}
                                onSelectionChanged={(name: string, item: IModelVersion) => {
                                    this.setState({ createVersionFromSource: item });
                                }}
                                hasAllCheckbox={false}
                            />
                        </div>
                    </div>
                </div>
                <div className="dlg-footer d-flex justify-content-center">
                    <button
                        type="button"
                        onClick={() => this.setState({ isVersionDialogVisible: false })}
                        disabled={this.state.isCreateVersionInProgress}
                        className="btn confirmation-dlg-btn-cancel"
                    >
                        Cancel
          </button>
                    {!this.state.isCreateVersionInProgress && (
                        <button
                            type="button"
                            onClick={this.onCreateVersionOkClick}
                            className="btn bg-color-primary hover-background-medium confirmation-dlg-btn-primary-default"
                        >
                            Continue
                        </button>
                    )}
                    {this.state.isCreateVersionInProgress && (
                        <button
                            className="btn bg-color-primary confirmation-dlg-btn-primary-default"
                            type="button"
                            disabled={true}
                        >
                            <span className="spinner-grow spinner-grow-sm" />
              Creating...
                        </button>
                    )}
                </div>
            </Modal>
        );
    };

    public render() {
        const showCreateButton: boolean = this.state.modelVersions.length > 0;
        const { hasEntitlements, template, userId } = this.props;

        return (
          <div className="cards version-card  m-24">
            <div className="container-fluid">
              <div className="row card-header card-grey">
                <div className="col-6 pl-24 version-panel">
                  <div className="d-flex justify-content-start label-ver-col align-items-center">
                    <label
                      className="label-ver col-form-label"
                      htmlFor="inlineFormCustomSelectPref"
                    >
                      Version
                    </label>
                    {this.renderVerDropdown()}
                    {this.onRefreshAnalysisClick()}
                    {this.state.viewType === ViewTypes.ViewResults && this.state.selectedVersion && this.renderRunIdDropdown()}
                    <div className="new-ver">
                      {!!showCreateButton && (
                        <button
                          onClick={this.openCreateVersionDialog}
                          className={
                            hasEntitlements
                              ? "btn btn-tertiary"
                              : "btn btn-disabled"
                          }
                          disabled={hasEntitlements ? false : true}
                        >
                          CREATE NEW VERSION
                        </button>
                      )}
                    </div>
                  </div>
                </div>
                <div className="col-6  pr-0">{this.renderActionButtons()}</div>
              </div>
              <div className="create-new-version-container">
                {this.renderNewVersionModalDialog()}
              </div>
              <div className="dec-engine-modal-container">
                <RunAnalysisModal showModalDialog={this.state.isRunAnalysisModalVisible} onModalHide={() => this.setState({ isRunAnalysisModalVisible: false })} horizonServices={this.props.horizonServices} selectedParams={this.props.selectedParams} selectedVersion={this.state.selectedVersion} template={template} userId={userId} />
              </div>
              {this.state.viewType === ViewTypes.ViewResults && <div className="saveToAdv-modal-container">
                <SaveToAdvModal showModalDialog={this.state.isSaveToAdvModalVisible} selectedVersion={this.state.selectedVersion} onModalHide={() => this.setState({ isSaveToAdvModalVisible: false })} horizonServices={this.props.horizonServices} />
              </div>}
            </div>
          </div>
        );
    }

  public onDecEngineModalDropdownChanged = (name: string, value: IListItem) => {
    if (value) {
      // this.isDecEngineHaveData = true;
    }
  };
}

const mapStateToProps = (state: IRootStore) => {
  return {
    enableRunButton: state.criteria.isRunButtonValid,
  };
};

export default connect(mapStateToProps, {
  onSaveButtonClick,
})(VersionSelector);
