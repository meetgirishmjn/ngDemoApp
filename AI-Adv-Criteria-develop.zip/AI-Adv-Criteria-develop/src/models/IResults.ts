export interface IKey {
  name: string;
  value: string;
}

export interface IValue {
  column: string;
  numvalue: number;
  strvalue: string;
  uom: string;
}

export interface IRunKey {
  key: IKey[];
  values: IValue[];
}

export interface IRun {
  keys: IRunKey[];
}

export interface IColumnData {
  run: IRun;
}

export interface IResultData {
  data: IColumnData;
  errors?: any[];
}

export interface ITabData {
  decision: string;
  // ruleGroup: string; // Not required for MVP, remove comment when required.
  lineName: string;
  [key: string]: any;
}

export interface ILastSuccessfulRun {
  id: string;
  isFinished: boolean;
}

export interface IAnalyses {
  id: string;
  lastSuccessfulRun: ILastSuccessfulRun;
}

export interface IAnalysisData {
  analysis: IAnalyses;
}

export interface IListItem {
    id: string;
    name: string;
    description?: string;
}