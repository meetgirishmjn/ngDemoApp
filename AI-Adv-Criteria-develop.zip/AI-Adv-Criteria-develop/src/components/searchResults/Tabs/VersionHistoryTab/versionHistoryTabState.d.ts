import { VersionHistoryInfo, IModelVersion } from "../../../../actions/criteria/models";

export interface IVersionHistoryTabState {
  isDataLoading: boolean;
    analysesId: string;
    selectedVersion: IModelVersion;
  data: VersionHistoryInfo[];
}
