import React from "react";
import { DropDown } from "@monsantoit/ui-react-base-controls";
import ISelection from "@monsantoit/ui-react-pipeline-select/dist/PipelineSelect/interfaces/ISelection";

const buildDropdownComponent = (
  data?: ISelection[],
  label?: string,
  onSelectionChanged?: (name: string, item: ISelection | ISelection[]) => void,
  ref?: React.RefObject<any>,
  selectedValue?: ISelection | ISelection[] | undefined,
  sorted: boolean = true,
  isMultiselect: boolean = false,
  isLoading: boolean = false,
  isDisabled: boolean = false
) => {
  return (
    <div className="col col-12 col-md-2 mb-12" key={label}>
      <DropDown
        name={label}
        label={label}
        data={data}
        textProperty={"value"}
        selectedItem={isDisabled ? undefined : selectedValue}
        onSelectionChanged={onSelectionChanged}
        isMultiselect={isMultiselect}
        hasAllCheckbox={true}
        sorted={sorted}
        isDisabled={isDisabled}
        ref={ref}
        placeholder={data.length === 0 ? "No Selections" : undefined}
        isLoading={isLoading}
      />
    </div>
  );
};

export default buildDropdownComponent;
