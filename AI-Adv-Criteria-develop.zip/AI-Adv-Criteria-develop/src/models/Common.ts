export interface IDictionary<T> {
    [Key: string]: T;
}