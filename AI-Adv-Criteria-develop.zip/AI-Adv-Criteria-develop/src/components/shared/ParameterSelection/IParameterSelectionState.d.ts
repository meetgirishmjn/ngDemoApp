interface IParameterSelectionState {
  Pipeline: IPipeline | undefined;
  userPreferences: IPipeline;
}

export default IParameterSelectionState;
