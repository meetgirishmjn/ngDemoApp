import * as React from "react";
import { Provider } from "react-redux";
import { shallow, mount } from "enzyme";
import ConnectedParameterSelection, {
  ParameterSelection,
} from "./ParameterSelection";
import configureMockStore from "redux-mock-store";
import thunk from "redux-thunk";
import { BrowserRouter } from "react-router-dom";

const mockStore = configureMockStore([thunk]);

describe("<ParameterSelection />", () => {
  test("renders parameter selection card", () => {
    const store = mockStore({
      auth: {
        user_id: "test_user",
      },
      userPreferences: {
        userPreferences: {},
      },
    });
    const wrapper = mount(
      <BrowserRouter>
        <Provider store={store}>
          <ConnectedParameterSelection
            HorizonServices={{}}
            userPreferences={{}}
            store={store}
          />
        </Provider>
      </BrowserRouter>
    );
    expect(wrapper.find("h2.card-title")).toHaveLength(1);
    expect(wrapper.find("h2.card-title").text()).toBe("Select Parameters");
    expect(wrapper.find("PipelineSharedComponent")).toHaveLength(1);
    expect(wrapper.find("label.txt14").text()).toBe("All selections required.");
    expect(wrapper.find(".btn-clear")).toBeTruthy();
    expect(wrapper.find(".btn-submit")).toBeTruthy();
  });
});
