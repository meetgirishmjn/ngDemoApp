import React from "react";
import { connect } from "react-redux";
import _ from "lodash";
import PipelineSharedComponent from "../PipelineSharedComponent/PipelineSharedComponent";
import {
  PipelineDisplay,
  PipelineSelect,
} from "@monsantoit/ui-react-pipeline-select";
import { FormModal } from "@monsantoit/ui-react-modal-dialog";
import {
  saveUserPreferences,
  getUserPreferences,
} from "../../../actions/userPreferences/userPreferencesActions";
import { DropDown } from "@monsantoit/ui-react-base-controls";
import "./PipelineEditedSubHeader.scss";
import IRootStore from "../../../store/IRootStore";

interface IProps {
  selectedParams: IPipeline;
  horizonServices: any;
  onChangeParams?: (selectedParams: IPipeline) => void;
  saveUserPreferences?: (
    userPreferences: IPipeline,
    horizonServices: any
  ) => void;
  getUserPreferences?: () => void;
  onEditCriteria?: () => void;
  showEditCriteria?: boolean;
}

interface IState {
  pipeline: IPipeline;
  userPreferences: IPipeline;
  isAllParamsSelected: boolean;
}

export class PipelineEditedSubHeader extends React.Component<IProps, IState> {
  public FormModalInstance = null;
  public PipelineSharedComponentRef = React.createRef<PipelineSelect>();
  public pipelineDisplayRef = React.createRef<PipelineDisplay>();
  public deDropdownRef = React.createRef<DropDown>();

  constructor(props: IProps) {
    super(props);
    this.state = {
      pipeline: props.selectedParams ? props.selectedParams : null,
      userPreferences: props.selectedParams ? props.selectedParams : null,
      isAllParamsSelected: false,
    };
  }

  public componentWillReceiveProps = (nextProps: IProps) => {
    if (
      !this.state.pipeline ||
      (_.isEqual(this.state.pipeline, nextProps.selectedParams) &&
        this.isAllParamsSelected(nextProps.selectedParams))
    ) {
      this.setState({ userPreferences: nextProps.selectedParams });
    }
  };

  public pipelineEdited = (isAllParamsSelected: boolean) => {
    const { horizonServices } = this.props;
    const { userPreferences } = this.state;
    if (this.FormModalInstance) {
      const myForm = () => (
        <PipelineSharedComponent
          setSelectorRef={this.PipelineSharedComponentRef}
          onSelectionChanged={this.handleSelectionChanged}
          Pipeline={userPreferences}
          HorizonServices={horizonServices}
          deSelectorRef={this.deDropdownRef}
        />
      );
      const options: any = {
        content: myForm(),
        okButtonText: "SUBMIT",
        okButtonClass: isAllParamsSelected
          ? "btn btn-tertiary submit-btn"
          : "btn btn-tertiary button-tertiary-disabled color-dark-grey submit-button",
        onOkClick: (event: any) => {
          if (this.FormModalInstance) {
            this.onSubmit();
            this.FormModalInstance.hide();
          }
        },
        submitWarningMessage: "All selections required.",
        submitWarningVisible: true,
        title: "Edit Parameters",
      };
      this.FormModalInstance.show(options);
    }
  };

  public render() {
    const { selectedParams } = this.props;
    const { isAllParamsSelected } = this.state;
    const displayValues: IPipelineSelections = {
      Crop: {
        value:
          selectedParams && selectedParams.Crop && selectedParams.Crop.value,
      },
      Year: {
        value: selectedParams && selectedParams.Year,
      },
      Region: {
        value:
          selectedParams &&
          selectedParams.Region &&
          selectedParams.Region.value,
      },
      HarvestType: {
        value:
          selectedParams &&
          selectedParams.HarvestType &&
          selectedParams.HarvestType.value,
      },
      Market: {
        value:
          selectedParams &&
          selectedParams.Market &&
          selectedParams.Market.value,
      },
      SubMarket: {
        value:
          selectedParams &&
          selectedParams.SubMarket &&
          selectedParams.SubMarket.value,
      },
      ProductStage: {
        value:
          selectedParams &&
          selectedParams.ProductStage &&
          selectedParams.ProductStage.value,
      },
      Trait: {
        value:
          selectedParams && selectedParams.Trait && selectedParams.Trait.value,
      },
      // This is as  decision Engine Value, Since we dont have decision engine prop in pipeline display component
      // we are rendering it as Cycle label
      Cycle: {
        value:
          selectedParams &&
          selectedParams.DecisionEngine &&
          selectedParams.DecisionEngine.value,
      },
    };

    return (
      <>
        {selectedParams && (
          <>
            <div>
              <PipelineDisplay
                displayValues={displayValues}
                onEdit={this.pipelineEdited.bind(this, isAllParamsSelected)}
                ref={this.pipelineDisplayRef}
              />
              <FormModal
                ref={(instance) => {
                  this.FormModalInstance = instance;
                }}
              />
            </div>
            <div className="edit-criteria">
              {this.props.showEditCriteria === true && (
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={this.props.onEditCriteria}
                >
                  Edit Criteria
                </button>
              )}
            </div>
          </>
        )}
      </>
    );
  }

  private handleSelectionChanged = async (pipeline: IPipeline) => {
    await this.setState({ pipeline });
    const checkAllParamsSelection = !_.isNil(this.isAllParamsSelected());
    if (this.state.isAllParamsSelected !== checkAllParamsSelection) {
      await this.setState({
        isAllParamsSelected: !_.isNil(this.isAllParamsSelected()),
      });
      this.pipelineEdited(this.state.isAllParamsSelected);
    }
  };

  private isAllParamsSelected = (pipelineToValidate?: IPipeline) => {
    const pipeline = pipelineToValidate
      ? pipelineToValidate
      : this.state.pipeline;
    return (
      pipeline &&
      pipeline.Crop &&
      pipeline.Year &&
      pipeline.Region &&
      pipeline.HarvestType &&
      pipeline.Market &&
      pipeline.SubMarket &&
      pipeline.StageType &&
      pipeline.ProductStage &&
      pipeline.Trait &&
      pipeline.DecisionEngine
    );
  };

  private onSubmit = () => {
    const { saveUserPreferences, onChangeParams, selectedParams } = this.props;
    const { pipeline } = this.state;
    if (this.isAllParamsSelected()) {
      saveUserPreferences(pipeline, this.props.horizonServices);
      if (onChangeParams && !_.isEqual(selectedParams, pipeline)) {
        onChangeParams(pipeline);
      }
    }
  };
}

const mapStateToProps = (state: IRootStore) => {
  return {
    selectedParams: state.userPreferences.userPreferences,
  };
};

export default connect(mapStateToProps, {
  saveUserPreferences,
  getUserPreferences,
})(PipelineEditedSubHeader);
