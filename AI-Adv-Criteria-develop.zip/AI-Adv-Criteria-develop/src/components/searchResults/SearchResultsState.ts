import {
  IConfigurationTemplate,
  IVersionHistoryInfo,
  IModelVersion,
} from "../../actions/criteria/models";
import { IRuleGroup, ICurrentState } from "@monsantoit/ui-react-ap-rules/dist/CriteriaCreation/ICriteriaCreationProps";
import { IDictionary } from "../../models/Common";

interface ISearchResultsState {
    selectedTab: string;
    selectedTabModelType?: IStringKvp;
    isTemplateLoading: boolean;
    configTemplateError: string;
    configTemplate: IConfigurationTemplate;
    selectedParams: IPipeline;
    VersionHistoryData: IVersionHistoryInfo[];
    isVersionHistoryLoading: boolean;
    selectedAnalyseId?: string;
    ruleGroups: IRuleGroup[];
    ViewType: ViewTypes;
    isVersionDataLoading: boolean;
    selectedVersion: IModelVersion;
    modelVersions: IModelVersion[];
    HasEntitlements: boolean;
    analysisInRun?: IModelVersion;
    ruleGroupsComponentState?: ICurrentState;
    selectedRunId?: number;
}

export interface ISearchResultsCache {
    selectedVersion: string;
    selectedTab: string;
    selectedRunIdHash: IDictionary<number>;
}

export enum ViewTypes {
  Default = 0,
  ViewResults = 1,
}

export interface IGraphTabCache {
    histogramSelectionHash: IDictionary<string>;
    scatterSelectionHash: IDictionary<string[]>;
}

export default ISearchResultsState;
