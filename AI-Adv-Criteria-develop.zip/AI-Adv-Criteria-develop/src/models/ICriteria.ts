import { IModelVersion } from "../actions/criteria/models";

export default interface ICriteria {
    saveClick: string;
    analysisInRun: IModelVersion;
    isRunButtonValid: boolean;
}
