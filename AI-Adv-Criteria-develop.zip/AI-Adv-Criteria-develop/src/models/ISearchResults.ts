export interface ICropRegionResponse {
  pipelineId: number;
  pipelineStatusId: number;
  pipelineStatus: string;
  testingYear: string;
  harvestTypeId: number;
  harvestTypeCode: string;
  harvestTypeDesc: string;
  traitId: number;
  traitName: string;
  traitType: string;
  productStageType: string;
  productStageId: number;
  productStageName: string;
  regionId: number;
  regionName: string;
  regionRefCd: string;
  cropId: number;
  cropName: string;
  marketId: number;
  marketName: string;
  subMarketId: number;
  subMarketName: string;
  testingFootprintId: number;
  testingFootprintName: string;
  cycle: string;
  cycleDisplay: string;
  cycleId: number;
  allocation: number;
  allocationTypeId: number;
  refActive: boolean;
}

export interface ISubMarket {
  id: number;
  name: string;
}
