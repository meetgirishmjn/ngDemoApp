import {
  configTemplateJsonParser,
  ICriteriaValueRes,
} from "./configTemplateJsonParser";
import { getModelVersions, getConfigTemplate } from "./criteriaActions";

describe("criteria actions", () => {
  it("should parse using configTemplateJsonParser", async () => {
    const json: ICriteriaValueRes = {
      analysis: null,
    };
    const template = configTemplateJsonParser(json);

    expect(template.sections.length).toBe(1);
  });

  it("should get ModelVersions", async () => {
    const versions = await getModelVersions("Corn", 2019, "NA", "G", "RM100");
    expect(versions.length).toBeGreaterThan(0);
  });

  it("should get Config template", async () => {
    const temaplate = await getConfigTemplate("1", 1);

    expect(temaplate).toBeTruthy();
  });
});
