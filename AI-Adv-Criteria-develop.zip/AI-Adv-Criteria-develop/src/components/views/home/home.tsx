import * as React from "react";
import ParameterSelection from "../../shared/ParameterSelection/ParameterSelection";
import "./home.scss";

interface IState {}

interface IProps {
  services: any;
}

class Home extends React.Component<IProps, IState> {
  public render() {
    const { services } = this.props;
    return <ParameterSelection HorizonServices={services} />;
  }
}

export default Home;
