import React from "react";
import { shallow } from "enzyme";
import MockAdapter from "axios-mock-adapter";
import pacApi from "../../../../api/pacApi";
import VersionHistoryTab from ".";
import { IModelVersion } from "../../../../actions/criteria/models";

const mockVersion: IModelVersion =
{
    uid: "1",
    analyseId: "7179",
    name: "test-1",
    version: 1,
    versionDesc: "Version 1",
    isLocked: false,
    isInProgress: false,
    runs: []
};

describe("VersionHistoryTab", () => {
  it("should render VersionHistoryTab with default props", () => {
      const wrapper = shallow(<VersionHistoryTab analysesId={mockVersion.analyseId} hasEntitlements={true} selectedVersion={mockVersion}/>);
    expect(wrapper.find("div.version-history-container").length).toBe(1);
  });

  it("should render grid on VersionHistoryTab", async () => {
    const mock = new MockAdapter(pacApi);
    mock.onPost("/graphql").reply(200, {
      data: {
        analyses: [
          {
            id: "7169",
            name: "CA20S_0001",
            version: "1",
            createUser: "GKOHT",
            modifiedDate: "2020-05-18T21:27:44.453179",
            modifiedUser: "GKOHT",
            description:
              "CORN-SAF-20_00-PRESCRIPTION-White--PS1----------PRESC_INB-GRAIN",
            runs: [
              {
                id: "12916",
                currentStatus: "SUCCESS",
                createdOn: "2020-08-31T15:46:44.998287",
                finalizedDate: "2020-08-31T15:50:38.680877",
                analysisVersion: 1,
              },
              {
                id: "12915",
                currentStatus: "SUCCESS",
                createdOn: "2020-08-31T15:28:04.161753",
                finalizedDate: "2020-08-31T15:41:35.432488",
                analysisVersion: 1,
              },
              {
                id: "13558",
                currentStatus: "FAILURE",
                createdOn: "2020-09-09T15:54:27.429194",
                finalizedDate: "2020-09-09T21:35:27.537974",
                analysisVersion: 1,
              },
              {
                id: "13701",
                currentStatus: "SUCCESS",
                createdOn: "2020-09-09T22:13:54.736691",
                finalizedDate: "2020-09-09T22:27:43.238729",
                analysisVersion: 1,
              },
            ],
          },
        ],
      },
    });
      const wrapper = shallow(<VersionHistoryTab analysesId={mockVersion.analyseId} hasEntitlements={true} selectedVersion={mockVersion}/>);
    expect(wrapper.find("div.loading-div").length).toBe(1);
  });
});
