import IAuth from "../models/IAuth";
import IUserPreferences from "../models/IUserPreferences";
import ICriteria from "../models/ICriteria";
import { IGraphData } from "src/models/IGraphTab";


export default interface IRootStore {
  readonly auth: IAuth;
  readonly userPreferences: IUserPreferences;
  readonly criteria: ICriteria;
  readonly graphData: IGraphData
}
