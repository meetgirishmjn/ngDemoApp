export const defaultUserPreferences: IPipeline = {
  Crop: undefined,
  Year: undefined,
  Region: undefined,
  HarvestType: undefined,
  Market: undefined,
  SubMarket: undefined,
  StageType: undefined,
  ProductStage: undefined,
  Trait: undefined,
  DecisionEngine: undefined,
};

export default interface IUserPref {
  userPreferences: IPipeline;
  loadingUserPreferences: boolean;
}
