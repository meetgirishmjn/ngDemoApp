import types from "../ActionTypes";
import IAuth from "../../models/IAuth";
import IEntitlementGroups from "../../models/IEntitlementGroups";

export type LoginAction =
  | { type: types.AUTHENTICATION_SUCCESS; payload: IAuth }
  | { type: types.AUTHENTICATION_FAILED; payload: IAuth }
  | { type: types.SAVE_ENTITLEMENTS; payload: IEntitlementGroups };
