import React, { useState } from "react";
import { connect } from "react-redux";
import Modal from "react-bootstrap4-modal";
import IRunAnalysisProps from "./IRunAnalysisProps";
import { DropDown } from "@monsantoit/ui-react-base-controls";
import {
  GetRunAnalysisReasons
} from "../../../../actions/pac/pacActions";
import { IListItem } from "../../../../models/IResults";
import { createRunJsonModal, runAnalysisModel } from "./helper";
import "./runAnalysis.scss";
import { onAnalysisRunSuccess } from "../../../../actions/criteria/criteriaActions";

const RunAnalysisModal: React.FC<IRunAnalysisProps> = (props) => {
  const [isModalDialogVisible, setModalDialogVisible] = useState(
    props.showModalDialog
  );
  const [isRunInProgress, setRunInProgress] = useState(false);
  const [runAnalysisReasons, setRunAnalysisReasons] = useState(
    [] as IListItem[]
  );
  const [selectedRunReasons, setSelectedRunReasons] = useState(
    [] as IListItem[]
  );
  const [modificationComments, setModificationComments] = useState("");

  React.useEffect(() => {
    (async () => {
      const reasonList = await GetRunAnalysisReasons();
      setRunAnalysisReasons(reasonList);
    })();
  }, []);

  React.useEffect(() => {
    setModalDialogVisible(props.showModalDialog);
  }, [props.showModalDialog, props.selectedVersion]);

  const hideModalDialog = () => {
    setSelectedRunReasons([]);
    setModificationComments("");
    setModalDialogVisible(false);
    props.onModalHide();
  };

    const onRunConfirmClick = async () => {

        //#region "Validations"
        if (isRunInProgress || !props.selectedVersion) {
            return;
        }

        if (!selectedRunReasons.length) {
            props.horizonServices.toast.error("Please select Run Reason(s)");
            return;
        }
        if (selectedRunReasons.find(o => o.id === "other") && !modificationComments.trim().length) {
            props.horizonServices.toast.error('Please enter modification comments for "Other" reason');
            return;
        }
        //#endregion "Validations"

        try {
            setRunInProgress(true);
            await runAnalysisModel(props.selectedParams, props.selectedVersion, props.template, props.userId, modificationComments);
            setRunInProgress(false);
            props.horizonServices.toast.success("Analysis-Run job queued successfully");
            props.onAnalysisRunSuccess(props.selectedVersion);
            hideModalDialog();
        } catch (ex) {
            setRunInProgress(false);
            props.horizonServices.toast.error(ex);
        }
    };

  const reasonSelectionChanged = (name: string, values: IListItem[]) => {
    setSelectedRunReasons(values);
  };

  return (
    <Modal
      visible={isModalDialogVisible}
      className="ui-react-confirmation-dlg run-analysis-modal"
    >
      <div className="modal-body">
        <button
          type="button"
          className="close"
          onClick={() => hideModalDialog()}
          aria-label="Close"
        >
          <i
            id="close-button-icon"
            aria-hidden="true"
            className="material-icons"
          >
            clear
          </i>
        </button>
        <div className="text-center confirmation-dlg-message-area">
          <div className="confirmation-dlg-title">
            <h1>Run Decision Engine</h1>
          </div>
          <div className="confirmation-dlg-sub-text">
            <p>This process may take upto 30 minutes.</p>
            <p className="second-para">
              Check the "Version History" Tab to see status of the Run.
            </p>
          </div>
          <div className="run-reasons-dropdown-container">
            <div className="run-reasons-container">
              <div className="run-reasons-dropdown">
                <DropDown
                  name={"Run Reason"}
                  isMultiselect={true}
                  sorted={false}
                  placeholder={"Select Run Reasons"}
                  data={runAnalysisReasons}
                  textProperty={"name"}
                  hasAllCheckbox={false}
                  selectedItem={selectedRunReasons}
                  onSelectionChanged={reasonSelectionChanged}
                  key={"id"}
                />
              </div>
              <div className="run-reasons-comment-box">
                <textarea
                  onChange={(e) => setModificationComments(e.target.value)}
                  className="run-reasons-textarea"
                  value={modificationComments}
                  placeholder="Modification Comments..."
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="dlg-footer d-flex justify-content-center">
        <button
          type="button"
          onClick={() => hideModalDialog()}
          className="btn confirmation-dlg-btn-cancel"
        >
          Cancel
        </button>
        {!isRunInProgress && (
          <button
            type="button"
            className="btn bg-color-primary hover-background-medium confirmation-dlg-btn-primary-default"
            onClick={() => onRunConfirmClick()}
          >
            Run
          </button>
        )}
        {isRunInProgress && (
          <button
            className="btn bg-color-primary confirmation-dlg-btn-primary-default"
            type="button"
            disabled={true}
          >
            <span className="spinner-grow spinner-grow-sm" />
            Please wait...
          </button>
        )}
      </div>
    </Modal>
  );
};

export default connect(null, {
    onAnalysisRunSuccess
})(RunAnalysisModal);
