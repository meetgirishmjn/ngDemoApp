import React from "react";
import { shallow, mount } from "enzyme";
import { GraphsTab } from ".";
import ScatterPlotGraph from "./scatterplot/scatterplotGraph";
import HistogramGraph from "./histogram/histogramGraph";

const selectedParams = {
    Crop: {id: 65601536, key: "CORN", value: "Corn", cropId: 65601536},
    DecisionEngine: {key: "EVA-0.1.23", value: "EVA-0.1.23"},
    HarvestType: {id: 81985536, key: "G", value: "Grain"},
    Market: {id: 32530, key: "RM110", value: "RM110"},
    ProductStage: {key: "10003", value: "PS1"},
    Region: {id: 100001, key: "NA", value: "NA"},
    StageType: {key: "PCM", value: "PCM"},
    SubMarket: {id: -1, key: "", value: "All Sub Markets"},
    Trait: {key: "-1", value: " All Traits"},
    Year: "2020"
}
const selectedVersion = {
    analyseId: "10028",
    isInProgress: false,
    isLocked: true,
    name: "eva-na-test2",
    uid: "10028_eva-na-test2_2",
    version: 2,
    versionDesc: "eva-na-test2_v2",
    runs:[]
}


describe("GraphsTab View", () => {
    it('test render graphs tab', async () => {
        const wrapper = await shallow(<GraphsTab
            userId={"testUser1"}
            selectedParams={selectedParams}
            selectedVersion={selectedVersion}
            horizonServices={{
                alert: {
                    error: (message: string) => { }
                }
            }}
            blupsDataForSelectedVersion={{}}
            saveBlupsData={() => { }}
            saveGraphsData={() => { }}
            velocityCache={null}
        />);
        expect(wrapper.find('.loading-div')).toHaveLength(1);
        expect(wrapper.find('.check-dropdown')).toHaveLength(1);
        expect(wrapper.find('.gender-dropdown')).toHaveLength(1);
    });

    /* it('render HistogramGraph with selectedTrait', async () => {
        const wrapper = await mount(<HistogramGraph
            selectedTrait={"trait4"}
            dataSet={{}}
            prescData={{} as any}
            traits={["trait1", "trait2", "trait3", "trait4"]}
            onChangeOfTrait={() => { }}
            onChangeOfDataSet={() => { }}
            keyTrait={"trait1"}
        />);
        expect(wrapper.find('div.ui-react-dropdown').find('.dropdown-toggle').filterWhere((o)=>o.prop('title')==='trait4')).toHaveLength(1);
    }); */
})