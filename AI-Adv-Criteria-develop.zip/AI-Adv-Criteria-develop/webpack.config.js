const webpack = require("webpack");
const ExtractTextPlugin = require("extract-text-webpack-plugin");
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyWebpackPlugin = require("copy-webpack-plugin");
const dotenv = require("dotenv");
 

module.exports = env => {
  const webpackEnv = env ? env : {};
  const NODE_ENV = webpackEnv.NODE_ENV ? webpackEnv.NODE_ENV : "development";
  const envBasePath = __dirname + "/environments/.env";
  const envPath = envBasePath + "." + NODE_ENV;

  const fileEnv = dotenv.config({
    path: envPath
  }).parsed;

  const envKeys = Object.keys(fileEnv).reduce((prev, next) => {
    prev[`process.env.${next}`] = JSON.stringify(fileEnv[next]);
    return prev;
  }, {});

  // No NODE_ENV = Local environment serving from "/"
  const publicPath = webpackEnv.NODE_ENV ? `${process.env.BASE_PATH}` : "/";
  const basePath = `${process.env.BASE_PATH}`;
  const openPage = basePath.slice(1);
  // only webpack dev server should serve from basePath/assets
  const assetsPath = publicPath !== "/" ? 'assets' : `${openPage}/assets`;
  return {
    entry: './src/index.tsx',
    resolve: {
      extensions: ['.ts', '.tsx', '.js']
    },
    output: {
      path: __dirname + `/dist${process.env.BASE_PATH}`,
      filename: 'bundle.min.js',
      publicPath: publicPath,
    },
    devtool: '',
    devServer: {
      contentBase: `/dist${process.env.BASE_PATH}`,
      openPage: openPage,
      port: 3000
    },
    module: {
      rules: [{
          test: /\.tsx?$/,
          loader: 'awesome-typescript-loader'
        },
        {
          test: /\.css$/,
          use: ExtractTextPlugin.extract({
            fallback: "style-loader",
            use: "css-loader!sass-loader"
          })
        },
        {
          test: /\.scss$/,
          use: ExtractTextPlugin.extract({
            fallback: "style-loader",
            use: "css-loader!sass-loader"
          })
        },
        {
          test: /\.woff(2)?(\?v=[0-9]\.[0-9]\.[0-9])?$/,
          loader: "url-loader?limit=10000&mimetype=application/font-woff"
        },
        {
          test: /\.(ttf|eot|svg)(\?v=[0-9]\.[0-9]\.[0-9])?$/,
          loader: "file-loader"
        },
        {
          test: /\.(png|svg|jpg|gif)$/,
          use: [
            'file-loader',
          ],
        },
      ]
    },
    plugins: [
      new ExtractTextPlugin("style.css"),
      new CopyWebpackPlugin({
        patterns: [
          { from: "./public/assets", to: assetsPath }
        ],
      }),
      new HtmlWebpackPlugin({
        template: "./public/index.html",
        filename: "./index.html",
        env: {
          cloudFrontEP: process.env.REACT_APP_CLOUDFRONT_URL
        }
      }),
      new webpack.DefinePlugin(envKeys)
    ],
  }
}