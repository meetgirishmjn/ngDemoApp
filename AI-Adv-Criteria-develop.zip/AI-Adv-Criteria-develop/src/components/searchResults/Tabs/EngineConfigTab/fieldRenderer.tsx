import React, { Component } from "react";
import { connect } from "react-redux";
import { isEqual } from "lodash";
import {
  IConfigField,
  FieldTypes,
  IValidationResult,
} from "../../../../actions/criteria/models";
import { Tooltip } from "@material-ui/core";
import { validateField } from "../../../../actions/criteria/helpers";
import IRootStore from "../../../../store/IRootStore";
import "./engineConfigTab.scss";
import { DropDown } from "@monsantoit/ui-react-base-controls";
import { enableRunButton } from "../../../../actions/criteria/criteriaActions";

export interface IFieldRendererProps {
  section?: string;
  row?: string;
  field: IConfigField;
  customTooltipCss: any;
  onFieldChange?: (field: IConfigField, section: string, row: string, isValid: boolean) => void;
  onBlurField?: (field: IConfigField) => void;
  saveClickedTime: string;
  isDisabled?: boolean;
  enableRunButton: (isValid: boolean) => void;
}

interface IFieldRendererState {
  isValid: boolean;
  isDirty: boolean;
  validationMessage: string;
  field: IConfigField;
}

class FieldRenderer extends Component<
  IFieldRendererProps,
  IFieldRendererState
> {
  public inputRef: React.RefObject<HTMLInputElement>;

  constructor(props: IFieldRendererProps) {
    super(props);
    this.state = {
      isValid: true,
      isDirty: false,
      validationMessage: "",
      field: props.field
    };
  }

  public componentWillReceiveProps = (nextProps: IFieldRendererProps) => {
    if (this.props.saveClickedTime !== nextProps.saveClickedTime) {
      this.onInputKeyPress();
    }
    if (!isEqual(this.props.field, nextProps.field)) {
      this.setState({ field: nextProps.field });
    }
  };

  public getIcon(): JSX.Element {
    // default number
    let icon: JSX.Element = <>#</>;
    switch (this.state.field.dataType) {
      case FieldTypes.Percentage:
        icon = <>%</>;
        break;
      case FieldTypes.Text:
        icon = <i className="fa fa-text-width" aria-hidden="true" />;
        break;
    }

    return icon;
  }

  public validate(field: IConfigField, value: string): IValidationResult {
    return validateField(field, value);
  }

  public onInputKeyPress = () => {
    const valResult = this.validate(this.state.field, this.state.field.value);
    this.setState({
      isDirty: true,
      isValid: valResult.isValid,
      validationMessage: valResult.message,
    });
  };

  public handleInputGroupChange = (
    evt: React.ChangeEvent<HTMLInputElement> | string
  ) => {
    let val;
    typeof(evt) === 'object' ? val = evt.currentTarget.value : val = evt;
    const valResult = this.validate(this.props.field, val);
    const fieldToUpdate: IConfigField = this.state.field;
    fieldToUpdate.value = val;
    this.setState(
      {
        field: fieldToUpdate,
        isValid: valResult.isValid,
        validationMessage: valResult.message,
      },
      () => {
        this.props.onFieldChange(
          fieldToUpdate,
          this.props.section,
          this.props.row,
          valResult.isValid
        );
        this.props.enableRunButton(valResult.isValid);
      }
    );
  };

  public onBlur = (event: React.ChangeEvent<HTMLInputElement>) => {
    const fieldToUpdate: IConfigField = this.state.field;
    this.setState({ field: fieldToUpdate }, () =>
      this.props.onBlurField(fieldToUpdate)
    );
  };

  private dropDownListData = (data): IDropDownData[] => {
    let arr: IDropDownData[] = [];

    data.forEach(element => {
      arr.push({id: element, value: element})
    });
    return arr;
  };

    private renderDropDown = (field: IConfigField) => {
        const validator = JSON.parse(field.validators);
        const dropDownData = validator.arguments;

        return (
            <DropDown
                name="selectedTrait"
                isMultiselect={false}
                isDisabled={this.props.isDisabled}
                sorted={true}
                data={this.dropDownListData(dropDownData)}
                selectedItem={{value: field.value}}
                textProperty="value"
                hasAllCheckbox={false}
                onSelectionChanged={(e, item) => {
                  this.handleInputGroupChange(item.value);
                }}
            />
    );
  }

  private renderInputField(field: IConfigField) {
    const inputAttr = {
      required: field.isRequired,
      readOnly: field.isReadOnly,
      type: field.isNumeric ? "number" : "text",
      disabled: this.props.isDisabled,
    };

    const showIcon = field.hideIcon === true ? false : true;
    return (
      <div className={"input-group ui-react-input-group input-group-sm"}>
        <input
          name={field.key}
          key={field.key}
          {...inputAttr}
          value={this.state.field.value}
          ref={this.inputRef}
          onKeyDown={this.onInputKeyPress}
          onChange={this.handleInputGroupChange}
          placeholder=""
          className={`form-control ui-react-input ${this.state.isValid === false ? "is-invalid" : ""
          }`}
          formNoValidate={true}
          onBlur={this.onBlur}
        />
        {showIcon && (
          <div className="input-group-append">
            <span className="input-group-text ui-react-input-suffix">
              {this.getIcon()}
            </span>
          </div>
        )}
        {this.state.isDirty && !this.state.isValid && (
          <div className="invalid-feedback">{this.state.validationMessage}</div>
        )}
      </div>
    );
  }

  public renderInputGroup(field: IConfigField) {
    if (field.validators) {
      const validator = JSON.parse(field.validators);
      // console.log(validator);
      if (validator.type === "str_list") {
        return this.renderDropDown(field);
      }
      if (validator.type === "range") {
        return this.renderInputField(field);
      }
    } else {
      return this.renderInputField(field);
    }
  }  

  public render = () => {
    const { field } = this.state;

    return (
      <div className={`form-group ${field.tooltip ? "has-tooltip" : ""}`}>
        <label className={`txt16 ${field.isRequired ? "l-requird" : ""}`}>
          {field.display}
        </label>
        {field.tooltip && (
          <Tooltip
            placement="right-start"
            title={<span dangerouslySetInnerHTML={{ __html: field.tooltip }} />}
            classes={{ tooltip: this.props.customTooltipCss }}
          >
            <i className="info material-icons color-status-blue">info</i>
          </Tooltip>
        )}
        <div className="input-group-div">{this.renderInputGroup(field)}</div>
      </div>
    );
  };
}

interface IDropDownData {
  id: string;
  value: string
}

const mapStateToProps = (state: IRootStore) => {
  return {
    saveClickedTime: state.criteria.saveClick,
  };
};

export default connect(mapStateToProps, {
  enableRunButton
})(FieldRenderer);
