export interface IAnalysisVersion {
  id: number;
  name: string;
  version: number;
  createUser: string;
  modifiedDate: string;
  modifiedUser: string;
  description: string;
  runs: IRun[];
}

export interface IRun {
  id: number;
  currentStatus: string;
  createdOn: string;
  finalizedDate: string;
  analysisVersion: number;
  isUsedForAdvancements: boolean;
}
