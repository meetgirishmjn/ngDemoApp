import React, { useState } from "react";
import Modal from "react-bootstrap4-modal";
import ISaveToAdvProps from "./ISaveToAdvProps";
import { DropDown } from "@monsantoit/ui-react-base-controls";
import "./saveToAdv.scss";
import { IListItem } from "../../../../models/IResults";
import _ from "lodash";
import { updateRun, queryRun } from "../../../../actions/pac/pacActions";

const SaveToAdvModal: React.FC<ISaveToAdvProps> = (props) => {

   const [isModalDialogVisible, setModalDialogVisible] = useState(props.showModalDialog);
    const [isSaveInProgress, setSaveInProgress] = useState(false);
    const [selectedVersion, setSelectedVersion] = useState(props.selectedVersion);
    const [selectedRunId, setSelectedRunId] = useState(props.selectedRunId);

    React.useEffect(() => {

    }, []);

    React.useEffect(() => {
        setSelectedRunId(props.selectedRunId);
        setModalDialogVisible(props.showModalDialog);
        setSelectedVersion(props.selectedVersion);
    }, [props.showModalDialog, props.selectedRunId, props.selectedVersion]);

    const hideModalDialog = () => {
        setSelectedRunId(null);
        setSaveInProgress(false);
        setModalDialogVisible(false);
        props.onModalHide();
    };

    
    const onSubmitClick = async () => {

        try {
            if (!selectedRunId) {
                props.horizonServices.toast.error("Please select Run Id");
                return;
            }
            setSaveInProgress(true);

            //validate
            const queryRes = await queryRun(selectedRunId);
            if (queryRes.hasError) {
                props.horizonServices.toast.error(queryRes.errorMessage);
                return;
            }

            if (queryRes.data.isFinished && queryRes.data.finalizedStatus !== "SUCCESS") {
                props.horizonServices.toast.warning("Run is not inalized or successful. Run Id can not be saved.");
                return;
            }

            const res = await updateRun(selectedRunId, true, "Test");
            if (res.hasError) {
                props.horizonServices.toast.error(res.errorMessage);
            } else {
                props.horizonServices.toast.success("Run Id saved for advancements");
                props.onModalHide();
            }
          
        } catch (ex) {
            props.horizonServices.toast.error("Failed to save for Adv.");
        } finally {
            setSaveInProgress(false);
        }
    };

    const runIdSelectionChanged = (name: string, value: IListItem) => {
        setSelectedRunId(+value.id);
    };

    const convertRunIdsToList = (): IListItem[] => {
        let runs = (selectedVersion.runs || []).filter(o => o.isFinished && o.currentStatus === "SUCCESS");
        runs = _.orderBy(runs, (o) => o.id, "desc");
        return runs.map((o, index) => {
            return {
                id: o.id.toString(),
                name: `${o.id}${index === 0 ? ' (latest run)' : ''}`
            } as IListItem
        });
    }

    return (
        <Modal
            visible={isModalDialogVisible}
            className="ui-react-confirmation-dlg saveToAdv-modal"
        >
            <div className="modal-body">
                <div className="confirmation-dlg-message-area dlg-message-area-override">
                    <div className="confirmation-dlg-title">
                        <h1>Save {selectedVersion.versionDesc} for Advancements</h1>
                    </div>
                    <div className="form-group">
                        <label>Run ID</label>
                        <div className="run-id-dropdown">
                            <DropDown
                                name={"RunID"}
                                isMultiselect={false}
                                sorted={false}
                                placeholder={"Select"}
                                data={convertRunIdsToList()}
                                textProperty={"name"}
                                hasAllCheckbox={false}
                                selectedItem={convertRunIdsToList().find(o => +o.id === selectedRunId)}
                                onSelectionChanged={runIdSelectionChanged}
                            />
                        </div>
                    </div>
                </div>
            </div>
            <div className="dlg-footer d-flex justify-content-end dlg-footer-override">
                <button
                    type="button"
                    onClick={() => hideModalDialog()}
                    className="btn btn-tertiary cancel"
                >
                    CANCEL
        </button>
                {!isSaveInProgress && (
                    <button
                        type="button"
                        className="btn btn-tertiary submit"
                        onClick={() => onSubmitClick()}
                    >
                        SUBMIT
                    </button>
                )}
                {isSaveInProgress && (
                    <button
                        className="btn btn-tertiary"
                        type="button"
                        disabled={true}
                    >
                        <span className="spinner-grow spinner-grow-sm" />
            Please wait...
                    </button>
                )}
            </div>
        </Modal>
    );
};

export default SaveToAdvModal;
