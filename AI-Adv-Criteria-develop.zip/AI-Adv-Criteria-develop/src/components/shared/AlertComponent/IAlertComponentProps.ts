interface IProps {
  alert: IAlert;
  onDismissClick?: () => void;
}

export interface IAlert {
  message: string;
  type: IAlertType;
  askBreeding?: boolean;
  isOpen?: boolean;
  enableRefresh?: boolean;
}

export enum IAlertType {
  Error = "Error",
  Warning = "Warning",
  Info = "Info",
}

export default IProps;
