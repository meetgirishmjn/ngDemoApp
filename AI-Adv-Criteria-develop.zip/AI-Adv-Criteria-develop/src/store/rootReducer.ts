import { combineReducers } from "redux";
import authReducer from "../reducers/authReducer";
import userPreferencesReducer from "../reducers/userPreferencesReducer";
import criteriaReducer from "../reducers/criteriaReducer";
import graphReducer from "../reducers/graphReducer";

const rootReducer = combineReducers({
  auth: authReducer,
  userPreferences: userPreferencesReducer,
  criteria: criteriaReducer,
  graphData: graphReducer
});

export default rootReducer;
