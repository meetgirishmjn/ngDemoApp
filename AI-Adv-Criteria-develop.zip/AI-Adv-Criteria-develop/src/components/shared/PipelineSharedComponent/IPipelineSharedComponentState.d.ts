import ISelection from "@monsantoit/ui-react-pipeline-select/dist/PipelineSelect/interfaces/ISelection";

interface IPipelineSharedComponentState {
  pipelineSelections: Partial<IPipeline>;
  psRefs: IPsRef[];
  // state variables to handle DE dropdown
  loadDEDropdown: boolean;
  enableDEDropdown: boolean;
  decisionEngineData: ISelection[];
  selectedDE: ISelection;
  setDefaultDE: boolean;
}

export default IPipelineSharedComponentState;
