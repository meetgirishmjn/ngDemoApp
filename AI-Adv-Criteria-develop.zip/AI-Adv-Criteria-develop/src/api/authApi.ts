import axios from "axios";

const authApi = axios.create({
  baseURL: process.env.TOKEN_URL,
});

authApi.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    // update error message here
    return Promise.reject(error);
  }
);

export default authApi;
