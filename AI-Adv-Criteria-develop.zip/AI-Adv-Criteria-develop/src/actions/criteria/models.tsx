import { IAnalyseRun } from "../../models/ISearchAnalyses";

export interface IModelVersion {
    uid: string;
    analyseId: string;
    name: string;
    version: number;
    versionDesc: string;
    isLocked: boolean;
    isInProgress: boolean;
    runs: IAnalyseRun[];
}

export interface IConfigurationTemplate {
  sections: IConfigSection[];
}
export interface IConfigSection {
  key: string;
  title: string;
  tooltip?: string;
  hasRequiredField: boolean;
  fields: IConfigField[];
  fieldRows: IConfigFieldRow[];
}

export interface IConfigField {
  key: string;
  value: string;
  name:string;
  display: string;
  tooltip: string;
  isReadOnly: boolean;
  isRequired: boolean;
  criteriaValueId: number;
  criteriaDefinitionId: number;
  criteriaDefaultValueId: number;
  hideIcon?: boolean;
  dataType: FieldTypes;
  isNumeric: boolean;
  minValue?: number;
  maxValue?: number;
  minLength?: number;
  maxLength?: number;
  onChangeArguments?: IOnChangeArgs;
  validators?: string;
}

export enum FieldTypes {
  Number = 1,
  PositiveNumber = 2,
  Percentage = 3,
  Text = 4,
  Integer = 5,
  PositiveInteger = 6,
  Email = 7,
  Pattern = 8,
  NumberRange = 9,
}

export interface IConfigFieldRow {
  key: string;
  title: string;
  label: string;
  tooltip?: string;
  fields: IConfigField[];
  childRows: IConfigFieldRow[];
  hasRequiredField: boolean;
}

export interface IVersionHistoryInfo {
  index: number;
  status?: string;
  reportName: string;
  version: number;
  dateModified: string;
  dateLastRun?: string;
  userName: string;
  comments?: string;
  runId?: number;
  savedForAdv?: boolean;
}

export interface IValidationResult {
  isValid: boolean;
  message: string;
}

export interface IArgs {
  derivedFieldName: string;
}

export interface IOnChangeArgs {
  operation: string;
  arguments: IArgs;
}

export interface IGraphqlBaseRes<T> {
  hasError: boolean;
  errorMessage: string;
  errorCode: GraphqlApiErrorCodes;
  data: T;
}

export enum GraphqlApiErrorCodes {
  UNKNOWN = "UNKNOWN",
}
