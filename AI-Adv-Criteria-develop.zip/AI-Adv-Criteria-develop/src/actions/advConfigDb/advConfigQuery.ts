import advConfigApi from "../../api/advConfigApi";
import { ParseConfigApiResponse, IConfigApiBaseRes } from "./models";
import { IQueryAdvConfigResponse } from "../../models/IAdvConfig";

export const advConfigQuery = async (
  crop: string,
  region: string,
  harvestType: string,
  year: string,
  market: string,
  pipelineTrait: string = "",
  submarket: string = ""
): Promise<IConfigApiBaseRes<IQueryAdvConfigResponse>> => {
  let parsedRes = ParseConfigApiResponse<IQueryAdvConfigResponse>(null);
  const graphReq = {
    query: makeQuery(crop, region, harvestType, year, market),
  };
  await advConfigApi
    .post("/graphql", graphReq)
    .then((response) => {
      parsedRes = ParseConfigApiResponse<IQueryAdvConfigResponse>(
        response.data
      );
      if (!parsedRes.hasError) {
        return parsedRes.data;
      }
    })
    .catch((err) => {
      console.log(err);
      parsedRes.errorMessage = "failed to load advConfig";
      // Logger.logError('Failed to get advConfigQuery', getUserId(), getErrorMessage(err, process.env.ADV_CONFIG_API, '/graphql'));
    });
  return parsedRes;
};

export const createFullfilment = async (configDataRequisitionId: number, productStageGroupMemberId: number, analysisID:string) => {
  const graphQuery = {
    query: `mutation createFulfillments {
      createFulfillment(input: {
        configDataRequisitionId: ${configDataRequisitionId}
        productStageGroupMemberId: ${productStageGroupMemberId}
        externalId: ${analysisID}
        externalVersion: 1
        modifiedReason: "create fulfillment"
      }) {
        fulfillment {
          id
          externalId
          externalVersion
          configDataRequisitionId
          productStageGroupMemberId
        }
      }
    }`,
  };
  const response = await getFulfillmentResponse(graphQuery);
  return response;
}

export const deleteFullfilment = async (fulfillmentId: number, reason: string) => {
  const graphQuery = {
    query: `mutation deleteFulfillemnt {
      deleteFulfillment(fulfillmentId: ${fulfillmentId} modifiedReason: "deleting record"){
        fulfillment {
          id
          refActive
        }
      }
    }`,
  };
  const response = await getFulfillmentResponse(graphQuery);
  return response;
}

export const updateFullfilment = async (fulfillmentId: number, analysisID: string, reason: string) => {
  const graphQuery = {
    query: `mutation updateFulfillment {
      updateFulfillment(input: {
        id: ${fulfillmentId}
        externalId: ${analysisID}
        modifiedReason: "${reason}"
        reactivate: true
      }){
        fulfillment {
          id
          externalId
          externalVersion
          modifiedReason
        }
      }
    }`,
  };
  const response = await getFulfillmentResponse(graphQuery);
  return response;
}

const getFulfillmentResponse = async (graphQuery: any) => {
  let response: any = {
    hasError: false
  };
  try {
    const apiRes = await advConfigApi.post("/graphql", graphQuery);
    response = apiRes;
  } catch (ex) {
    response.hasError = true;
    response.errorMessage = "Unkonwn error occured";
    console.log(ex)
  }
  return response;
}


/* const makeQuery = (
  crop: string,
  region: string,
  harvestType: string,
  year: string,
  market: string,
  pipelineTrait: string,
  submarket: string
) => {
  return `query {
  advConfig (input: {
                   crop:  "${crop}"
                    harvestType: "${harvestType}"
                    market: "${market}"
                    region: "${region}"
                    year: ${year}
                    pipelineTrait:${pipelineTrait}
                    submarket:${submarket}
  }
)
     {
        advConfig {
      id
      crop
      year
      region
      harvestType
      market
    }
    configDataRequisitions {
      advConfigSubset{
        id
      }
      requistions {
        configDataRequisitionId
        dataProviderName
        dataProvider{
          id
        }
        fulfillmentId
        requisitionItems {
          configDataRequisitionItemId
          dataProviderAttributeName
          value
          refActive
        }
      }
    }
  }
}`;
}; */

const makeQuery = (
  crop: string,
  region: string,
  harvestType: string,
  year: string,
  market: string
) => {
  return `query {
advConfig (input: {
                 crop:  "${crop}"
                  harvestType: "${harvestType}"
                  market: "${market}"
                  region: "${region}"
                  year: ${year}
}
)
   {
      advConfig {
    id
    crop
    year
    region
    harvestType
    market
    advConfigSubsets {
      id
      pipelineTrait
      subMarket
      productStageGroup {
        id
        productStageGroupName
        productStageGroupMembers {
          id
          productStage
        }
      }
    }
  }
  configDataRequisitions {
    advConfigSubset{
      id
        pipelineTrait
            subMarket
            productStageGroup {
              id
              productStageGroupName
              productStageGroupMembers {
                id
                productStage
              }
            }
    }
    requistions {
      configDataRequisitionId
      dataProviderName
      dataProvider{
        id
      }
      fulfillments {
        id
        productStageGroupMemberId
        externalId
        externalVersion
        modifiedReason
        refActive
      }
      requisitionItems {
        configDataRequisitionItemId
        dataProviderAttributeName
        value
        refActive
      }
    }
  }
}
}`;
};
