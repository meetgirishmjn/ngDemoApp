import React, { Component } from "react";
import { connect } from "react-redux";
import HorizonNav, { Environment } from "@monsantoit/new-horizon-ui";
import IHorizonNavProps from "@monsantoit/new-horizon-ui/dist/horizonFramework/IHorizonNavProps";
import { ModalDialog } from "@monsantoit/ui-react-modal-dialog";
import _ from "lodash";
import Spinner from "./common/spinner";
import {
  authenticate,
  getEntitlements,
} from "../src/actions/authentication/authActions";
import Routes from "./Routes";
import "./App.scss";
import { IEntitlements } from "./models/IEntitlementGroups";
import Constants from "./shared/constants";
import Alert from "./components/shared/AlertComponent/AlertComponent";
import {
  IAlert,
  IAlertType,
} from "./components/shared/AlertComponent/IAlertComponentProps";
import Help from "./components/shared/HelpComponent";

interface IAppProps {
  auth_token: string;
  auth_status: boolean;
  getEntitlements: any;
}

interface IAppState {
  pedigreeAccess: boolean;
  services: any;
  showBadge: boolean;
}

const AUTH_ERROR_ALERT: IAlert = {
  message:
    "System not responding. Please try refreshing your browser or contact Ask Breeding.",
  type: IAlertType.Error,
  askBreeding: true,
};

export class App extends Component<IAppProps, IAppState> {
  public state = {
    pedigreeAccess: false,
    services: undefined,
    showBadge: false,
  };
  public modalDialogInstance = null;

  public constructor(props: any) {
    super(props);
    props.authenticate();
  }

  public checkEntitlements = (ref: any) => {
    const { Groups } = ref.Services().userInfo;

    const pedigreeGroup = _.find(Groups, (group) => {
      return group.name === "View Pedigree";
    });

    // let entitlementGroup = Constants.entitlementGroups.filter(o => Groups.some(({id}) => o.groupId.toLowerCase() === id.toLowerCase()));

    const result = Groups.map((a) => a.entitlements);

    let entitlementGroups: IEntitlements[] = [];

    result.forEach((element) => {
      element.forEach((el) => {
        if (
          el.name
            .toLowerCase()
            .replace(/\s/g, "")
            .includes(Constants.ADVANCE_PRODUCTS_SUBSTRING)
        ) {
          entitlementGroups = [...entitlementGroups, el];
        }
      });
    });

    this.props.getEntitlements(entitlementGroups);

    if (!pedigreeGroup) {
      this.openEntitlementsDialog();
    } else {
      this.setState({ pedigreeAccess: true });
    }
  };

  public openEntitlementsDialog = () => {
    if (this.modalDialogInstance) {
      const options = {
        allowClose: true,
        autoClose: true,
        message: "Advancement Criteria requires View Pedigree Access.",
        okButtonStyle: { width: "auto" },
        okButtonText: "Request Access",
        onOkClick: () => {
          if (this.modalDialogInstance) {
            window.open(process.env.PEDIGREE_ACCESS_URL);
          }
        },
        title: "Unauthorized Access",
        onClose: () => {
          this.modalDialogInstance.hide();
        },
      };
      this.modalDialogInstance.show(options);
    }
  };

  public handleHorizonLoad = (framework: any) => {
    this.setState({
      services: framework.Services(),
      showBadge: process.env.ENVIRONMENT === Environment.prod ? false : true,
    });
    this.checkEntitlements(framework);
  };

  public render() {
    const { auth_status } = this.props;
    const { pedigreeAccess, services, showBadge } = this.state;
    const menuContent = (
      <div className="d-flex justify-content-between align-items-center h-100">
        <div className="flex-grow-1">
          <h1 className="display-name">
            Advance Products: Advancement Criteria
          </h1>
        </div>
        <Help />
      </div>
    );
    const envBadge =
      process.env.ENVIRONMENT === Environment.np
        ? "non-prod"
        : process.env.ENVIRONMENT;
    const horizonNavProps: IHorizonNavProps = {
      staticOpen: false,
      Appid: process.env.APP_ID,
      environment:
        process.env.ENVIRONMENT === "prod" ? Environment.prod : Environment.np,
      Hidden: false,
      onLoaded: this.handleHorizonLoad,
      menuContent,
      tokenUrl: `${process.env.TOKEN_URL}/auth-token-info`,
    };
    if (auth_status === null) {
      return <Spinner />;
    }
    if (!auth_status) {
      return <Alert alert={AUTH_ERROR_ALERT} />;
    }
    return (
      <div className="App">
        {(!auth_status || !services) && <Spinner />}
        {showBadge && <div className="env-badge">{envBadge}</div>}
        <HorizonNav {...horizonNavProps}>
          {auth_status && pedigreeAccess && <Routes services={services} />}
          <ModalDialog
            ref={(instance) => {
              this.modalDialogInstance = instance;
            }}
          />
        </HorizonNav>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  auth_status: state.auth.isAuthenticated,
  auth_token: state.auth.access_token,
});

export default connect(mapStateToProps, {
  authenticate,
  getEntitlements,
})(App);
