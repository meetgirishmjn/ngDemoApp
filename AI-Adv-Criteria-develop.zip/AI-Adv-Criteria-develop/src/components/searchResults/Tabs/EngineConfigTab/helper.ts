import {
  IQueryAdvConfigResponse,
  IRequisition,
  IAdvConfigSubset,
  IConfigDataRequistion,
  IProductStageGroupMembers,
} from "../../../../models/IAdvConfig";
import { IAnalysisSubType } from "../../../../models/IAnalyticModel";
import Constants from "../../../../shared/constants";

export const parseTraitParam = (trait: IStringKvp): IStringKvp => {
  if (trait.key === "-1") {
    return { key: trait.key, value: "" };
  }

  return trait;
};

export const findAdvRequistions = (
    response: IQueryAdvConfigResponse,
    subMarket: string,
    trait: string,
    productStage: string
): IRequisition[] => {
    let results: IRequisition[] = [];
    const matches = response.configDataRequisitions.filter(
        (o) =>
            o.advConfigSubset.pipelineTrait === trait &&
            o.advConfigSubset.subMarket === subMarket &&
            o.advConfigSubset.productStageGroup.productStageGroupMembers.find(
                (ps) => ps.productStage === productStage
            )
    );
    matches.forEach(match => {
        results = [...results, ...match.requistions];
    });
    return results;
};

export const parseJsonValue = (value: any): any => {
  let result = null;
  if (value) {
    try {
      result = JSON.parse(value);
    } catch {}
  }
  return result;
};

export interface IPsAndReqId {
  productStageGroupMemberId: number;
  configDataRequisitionId: number;
  fulfillmentID: number;
}

export const findAdvRequistionsToStoreFulfillmentId = async (
  response: IQueryAdvConfigResponse,
  item: IAnalysisSubType,
  selectedParams: IPipeline,
  horizonServices: any
) => {
  let filteredSubsets: IAdvConfigSubset[] = [];
  let filteredPsAndReqId: IPsAndReqId = null;
  filteredSubsets = filterSubsetsUsingPipeline(response, selectedParams, horizonServices);
  // find configDataRequisitions by the advConfigSubset Id's
  const filteredConfigDataReq: IConfigDataRequistion[] = response.configDataRequisitions.filter(
    (dataRequistion: IConfigDataRequistion) => {
      return filteredSubsets.find(
        ({ id }) => id === dataRequistion.advConfigSubset.id
      );
    }
  ) as IConfigDataRequistion[];
  // filter requisitions in configDataRequisitions by dataProviderName PAC
  filteredConfigDataReq.forEach((configDataReq: IConfigDataRequistion) => {
    const psGroupMember: IProductStageGroupMembers = configDataReq.advConfigSubset.productStageGroup.productStageGroupMembers.find(
      ({ productStage }) => productStage === selectedParams.ProductStage.value
    );
    let requisition: IRequisition;
    requisition = configDataReq.requistions.find(
      (requisition: IRequisition) => {
        const analysisTypeNameFound = requisition.requisitionItems.some(
          ({ dataProviderAttributeName, value }) => {
            let dataProviderValue = parseJsonValue(value);
            dataProviderValue = typeof dataProviderValue === 'string' && dataProviderValue.toLowerCase();
            return (
              dataProviderAttributeName === "analysisTypeName" &&
              (dataProviderValue === "blup" ||
                dataProviderValue === "prediction")
            );
          }
        );
        const analysisSubTypeFound = requisition.requisitionItems.some(
          ({ dataProviderAttributeName, value }) =>
            dataProviderAttributeName === "analysisSubTypeId" &&
            value === item.analysisSubTypeId
        );
        return (
          requisition.dataProviderName === "PAC" &&
          analysisSubTypeFound &&
          analysisTypeNameFound
        );
      }
    );
    if(requisition) {
      filteredPsAndReqId = {
        productStageGroupMemberId: psGroupMember.id,
        configDataRequisitionId: requisition.configDataRequisitionId,
        fulfillmentID: requisition.fulfillments.length > 0 ? requisition.fulfillments[0].id : null
      }
    }
  });
  return filteredPsAndReqId;
};

export const filterSubsetsUsingPipeline = (response: IQueryAdvConfigResponse, selectedParams: IPipeline, horizonServices?: any) => {
  let filteredSubsets: IAdvConfigSubset[] = [];
  // filter by product stage
  filteredSubsets = response.advConfig.advConfigSubsets.filter(
    (subSet: IAdvConfigSubset) => {
      return subSet.productStageGroup.productStageGroupMembers.find(
        ({ productStage }) => productStage === selectedParams.ProductStage.value
      );
    }
  ) as IAdvConfigSubset[];
  // filter by traits
  if (selectedParams.Trait.value === Constants.ALL_TRAIT_VALUE) {
    let filteredByTrait: IAdvConfigSubset[] = [];
    filteredByTrait = filteredSubsets.filter((subSet: IAdvConfigSubset) => {
      return subSet.pipelineTrait === "";
    });
    filteredSubsets =
      filteredByTrait.length > 0 ? filteredByTrait : filteredSubsets;
  } else {
    filteredSubsets = filteredSubsets.filter((subSet: IAdvConfigSubset) => {
      return subSet.pipelineTrait === selectedParams.Trait.value;
    });
  }
  filteredSubsets.length === 0 && horizonServices.toast.error("No trait specific BLUPs/Predictions defined  in Define Data");
  // filter by SubMarkets
  if (selectedParams.SubMarket.value === Constants.ALL_SUBMARKETS) {
    let filteredBySubMarket: IAdvConfigSubset[] = [];
    filteredBySubMarket = filteredSubsets.filter((subSet: IAdvConfigSubset) => {
      return subSet.subMarket === "";
    });
    filteredSubsets =
      filteredBySubMarket.length > 0 ? filteredBySubMarket : filteredSubsets;
  } else {
    filteredSubsets = filteredSubsets.filter((subSet: IAdvConfigSubset) => {
      return subSet.subMarket === selectedParams.SubMarket.value;
    });
  }
  filteredSubsets.length === 0 && horizonServices.toast.error("No submarket specific BLUPs/Predictions defined  in Define Data");
  return filteredSubsets;
}
