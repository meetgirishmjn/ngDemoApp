import { PipelineSelect } from "@monsantoit/ui-react-pipeline-select";
import { DropDown } from "@monsantoit/ui-react-base-controls";

interface IPipelineSharedComponentProps {
  HorizonServices?: any;
  onSelectionChanged: (pipeline: IPipeline) => void;
  Pipeline?: IPipeline;
  setSelectorRef?: React.RefObject<PipelineSelect>;
  access_token?: string;
  getUserPreferences?: () => Promise<any>;
  deSelectorRef: React.RefObject<DropDown>;
}

export default IPipelineSharedComponentProps;
