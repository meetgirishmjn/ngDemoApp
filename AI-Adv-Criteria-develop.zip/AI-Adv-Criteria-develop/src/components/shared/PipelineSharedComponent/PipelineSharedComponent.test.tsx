import * as React from "react";
import { shallow } from "enzyme";
import { PipelineSharedComponent } from "./PipelineSharedComponent";
import { PipelineSelect } from "@monsantoit/ui-react-pipeline-select";
import { DropDown } from "@monsantoit/ui-react-base-controls";

const pipeline: IPipeline = {
  Crop: {
    id: 65601536,
    key: "CORN",
    value: "Corn",
    cropId: 65601536,
  },
  Year: "2019",
  Region: {
    id: 100001,
    key: "NA",
    value: "NA",
  },
  HarvestType: {
    id: 81985536,
    key: "G",
    value: "Grain",
  },
  Market: {
    id: 32524,
    key: "RM080",
    value: "RM080",
  },
  SubMarket: {
    id: 51283,
    key: "BRACHYTIC",
    value: "BRACHYTIC",
  },
  StageType: {
    key: "SCREENING",
    value: "SCREENING",
  },
  ProductStage: {
    key: "10061",
    value: "SC2",
  },
  Trait: {
    key: "100000",
    value: "CONV",
  },
  DecisionEngine: {
    key: "EVA",
    value: "EVA",
  },
};

const getWrapper = () => {
  const onSelectionChanged = jest.fn();
  const PipelineSharedComponentRef = React.createRef<PipelineSelect>();
  const deDropdownRef = React.createRef<DropDown>();
  return shallow(
    <PipelineSharedComponent
      setSelectorRef={PipelineSharedComponentRef}
      onSelectionChanged={onSelectionChanged}
      HorizonServices={{}}
      deSelectorRef={deDropdownRef}
      Pipeline={pipeline}
    />
  );
};

const getComponent = () => {
  const onSelectionChanged = jest.fn();
  const PipelineSharedComponentRef = React.createRef<PipelineSelect>();
  const deDropdownRef = React.createRef<DropDown>();
  return new PipelineSharedComponent({
    setSelectorRef: PipelineSharedComponentRef,
    onSelectionChanged,
    HorizonServices: {},
    deSelectorRef: deDropdownRef,
  });
};

describe("<Home />", () => {
  test("renders parameter selection card", () => {
    const wrapper = getWrapper();
    expect(wrapper.find("PipelineSelect")).toHaveLength(1);
  });

  test("test empty parameters method", async () => {
    const component = getComponent();
    const emptyParams = await component.emptyParameters.items();
    expect(emptyParams).toHaveLength(1);
    expect(emptyParams[0].key).toBe("DEFAULT");
  });
});
