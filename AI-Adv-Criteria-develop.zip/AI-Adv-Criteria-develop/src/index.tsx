import React from "react";
import ReactDOM from "react-dom";
import { Provider } from "react-redux";
import App from "./App";
import configureStore from "./store/configureStore";
import "./index.scss";
import { LicenseManager } from "ag-grid-enterprise";

const configuredStore = configureStore();
const app = (
  <Provider store={configuredStore}>
    <App />
  </Provider>
);
const AG_GRID_LICENSE =
  "Monsanto_PopCast_5Devs20_April_2018__MTUyNDE3ODgwMDAwMA==6cbcc0a4bc16738d057622ec566adaaa";
LicenseManager.setLicenseKey(AG_GRID_LICENSE);

ReactDOM.render(app, document.getElementById("root"));
