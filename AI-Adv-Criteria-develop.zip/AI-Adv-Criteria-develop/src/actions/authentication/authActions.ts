import { Dispatch } from "redux";
import authApi from "../../api/authApi";
import types from "../ActionTypes";
import { LoginAction } from "./LoginAction";
import { IEntitlements } from "../../models/IEntitlementGroups";

export function authenticate(): (
  dispatch: Dispatch<LoginAction>
) => Promise<void> {
  return async (dispatch: Dispatch<LoginAction>) => {
    await getToken()
      .then((response) => {
        dispatch(authenticationSuccess(response));
      })
      .catch(() => {
        dispatch(authenticationFailed());
      });
  };
}

export const getToken = () => {
  return authApi.get("/auth-token-info", {
    withCredentials: true,
  });
};

export function authenticationSuccess(response): LoginAction {
  return {
    type: types.AUTHENTICATION_SUCCESS,
    payload: {
      isAuthenticated: true,
      access_token: response.data.access_token,
      user_id: response.data["user-id"],
    },
  };
}

export function authenticationFailed(): LoginAction {
  return {
    type: types.AUTHENTICATION_FAILED,
    payload: {
      isAuthenticated: false,
      access_token: null,
      user_id: null,
    },
  };
}

export const getEntitlements = (entitlementGroup: IEntitlements) => {
  return (dispatch: Dispatch) => {
    dispatch({
      type: types.SAVE_ENTITLEMENTS,
      payload: {
        entitlements: entitlementGroup,
      },
    });
  };
};
