import React from "react";
import { shallow } from "enzyme";
import { App } from "./App";
import Spinner from "./common/spinner";
import HorizonNav from "@monsantoit/new-horizon-ui";
import { ModalDialog } from "@monsantoit/ui-react-modal-dialog";
import Routes from "./Routes";
import { getEntitlements } from "../src/actions/authentication/authActions";

const [authenticate] = Array(1).fill(jest.fn());

function shallowSetup(authStatus: boolean) {
  // Sample props to pass to our shallow render
  const props = {
    auth_token: "x-token-123",
    auth_status: authStatus,
    authenticate,
    getEntitlements,
  };
  // wrapper instance around rendered output
  const enzymeWrapper = shallow(<App {...props} />);
  return {
    props,
    enzymeWrapper,
  };
}

describe("Shallow rendered app component", () => {
  it("should render app component with spinner", () => {
    // Setup wrapper and assign props.
    const { enzymeWrapper } = shallowSetup(null);
    expect(enzymeWrapper.containsMatchingElement(<Spinner />)).toBe(true);
  });

  it("should render app component with out spinner, pedigreeAccess, tests child components", () => {
    const horizonServices = () => {
      return {
        userInfo: { Groups: [{ name: "View Pedigree", entitlements: [] }] },
      };
    };
    // Setup wrapper and assign props.
    const { enzymeWrapper } = shallowSetup(true);
    const horizonNav = enzymeWrapper.find(HorizonNav);
    // home page is not loaded
    let home = enzymeWrapper.find(Routes);
    expect(home).toHaveLength(0);
    horizonNav.prop("onLoaded")({
      Services: horizonServices,
    });
    expect(enzymeWrapper.containsMatchingElement(<Spinner />)).toBe(false);
    // home page is loaded after setting servicesun
    home = enzymeWrapper.find(Routes);
    expect(home).toHaveLength(1);
  });

  it("should render modal if there is no pedigree access to user", () => {
    const horizonServices = () => {
      return {
        userInfo: { Groups: [{ name: "No Pedigree", entitlements: [] }] },
      };
    };
    // Setup wrapper and assign props.
    const { enzymeWrapper } = shallowSetup(true);
    const horizonNav = enzymeWrapper.find(HorizonNav);
    horizonNav.prop("onLoaded")({
      Services: horizonServices,
    });
    const modal = enzymeWrapper.find(ModalDialog);
    expect(enzymeWrapper.state("pedigreeAccess")).toBe(false);
    expect(modal).toHaveLength(1);
  });
});
