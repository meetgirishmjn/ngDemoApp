import React, { Component } from "react";
import { isEqual } from "lodash";
import { Histogram } from "@monsantoit/ui-react-visualizations";
import { DropDown } from "@monsantoit/ui-react-base-controls";
import { IResultData, ITabData } from "../../../../../models/IResults";
import { IDataset } from "../../../../../models/IGraphTab";
import {
  filterDataByPrescs,
  filterDataByBlups,
} from "../../../ResultsView/helper";
import "./histogram.scss";
import { ITraitAndSubType } from "..";

export interface IHistogramGraphProps {
  selectedTrait: ITraitAndSubType;
  dataSet: IDataset;
  traitsAndSubType: ITraitAndSubType[];
  prescData: IResultData;
  onChangeOfDataSet: (dataset: IDataset, selectedTrait: string) => void;
  onChangeOfTrait: (keyTrait: string, selectedTrait: string) => void;
  keyTrait: string;
}
export interface IHistogramGraphState {
  dataSet: IDataset;
  isDataLoading: boolean;
  selectedTrait: ITraitAndSubType;
}

export default class HistogramGraph extends Component<
  IHistogramGraphProps,
  IHistogramGraphState
> {
  constructor(props: IHistogramGraphProps) {
    super(props);
    this.state = {
      dataSet: props.dataSet,
      selectedTrait: props.selectedTrait,
      isDataLoading: !props.dataSet,
    };
  }

  componentDidMount = () => {
    !this.props.dataSet && this.loadData(this.props.selectedTrait);
  };

  public componentWillReceiveProps(nextProps: IHistogramGraphProps) {
    if (!isEqual(nextProps.selectedTrait, this.state.selectedTrait)) {
      this.setState({ selectedTrait: nextProps.selectedTrait });
      this.loadData(nextProps.selectedTrait);
    }
  }

  loadData = async (traitAndSubType: ITraitAndSubType) => {
    let dataByPrescsAndBlups = {
      advanceData: [],
      dropData: [],
      noMatchData: [],
    };
    const traitName = traitAndSubType.traitName;
    dataByPrescsAndBlups = filterDataByPrescs(
      this.props.prescData,
      dataByPrescsAndBlups
    );
    if(traitAndSubType.fulfillments[0] && traitAndSubType.fulfillments[0].externalId) {
      dataByPrescsAndBlups = await filterDataByBlups(
        [traitAndSubType.traitName],
        dataByPrescsAndBlups,
        traitAndSubType.fulfillments[0].externalId
      );
    }
    const { advanceData, dropData, noMatchData } = dataByPrescsAndBlups;
    let advanceValues: number[] = [];
    let dropValues: number[] = [];
    let noMatchValues: number[] = [];
    let dataSet: IDataset = null;
    advanceData.map((a: ITabData) =>
      a[traitName] ? advanceValues.push(parseFloat(a[traitName])) : null
    );
    dropData.map((a: ITabData) =>
      a[traitName] ? dropValues.push(parseFloat(a[traitName])) : null
    );
    noMatchData.map((a: ITabData) =>
      a[traitName] ? noMatchValues.push(parseFloat(a[traitName])) : null
    );
    if (advanceValues.length || dropValues.length || noMatchValues.length) {
      dataSet = {
        advance: advanceValues,
        drop: dropValues,
        noMatch: noMatchValues,
      };
    }
    this.setState(
      {
        dataSet,
        isDataLoading: false,
      },
      () => {
        this.props.onChangeOfDataSet(dataSet, traitName);
      }
    );
  };

  public onChangeOfTrait = async (traitAndSubType: ITraitAndSubType) => {
    await this.setState({ selectedTrait: traitAndSubType, isDataLoading: true });
    this.loadData(traitAndSubType);
    this.props.onChangeOfTrait(this.props.keyTrait, traitAndSubType.customTraitname);
  };

  public render() {
    const { traitsAndSubType } = this.props;
    const { selectedTrait, dataSet } = this.state;
    const vizLoading = (
      <div className=" card p-4">
        <div className="viz-loading">
          <div />
          <div />
          <div />
        </div>
      </div>
    );
    return (
      <>
        <div className="visualization col-md-4">
          {this.state.isDataLoading && vizLoading}
          {!this.state.isDataLoading && (
            <Histogram
              data={dataSet}
              yAxis={{ title: "Count" }}
              dataRollup={"frequency"}
              subTitle={
                <div className="mb-4">
                  <DropDown
                    name={selectedTrait.traitName}
                    data={traitsAndSubType}
                    textProperty="customTraitname"
                    selectedItem={selectedTrait}
                    onSelectionChanged={(e, item) => {
                      this.onChangeOfTrait(item);
                    }}
                  />
                </div>
              }
              legend={{ hide: false }}
            />
          )}
        </div>
      </>
    );
  }
}
