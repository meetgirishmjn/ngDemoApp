import * as React from "react";
import { shallow } from "enzyme";
import { Guid } from "guid-typescript";
import { Alert } from "./AlertComponent";
import { IAlert, IAlertType } from "./IAlertComponentProps";

const createAlert = (type: IAlertType, askBreeding: boolean) => {
  const onDismiss = jest.fn();
  const alert: IAlert = {
    message: "Message",
    type,
    askBreeding,
  };
  return <Alert alert={alert} onDismissClick={onDismiss} />;
};

describe("<Alert Component />", () => {
  test("renders ERROR alert with Dismiss option", () => {
    const wrapper = shallow(createAlert(IAlertType.Error, false));
    expect(wrapper.find(".errors-message")).toHaveLength(1);
    expect(wrapper.containsMatchingElement(<span>DISMISS</span>)).toEqual(true);
    expect(wrapper.containsMatchingElement(<span>ASK BREEDING</span>)).toEqual(
      false
    );
  });

  test("renders ERROR alert with Dismiss and askBreeding option", () => {
    const wrapper = shallow(createAlert(IAlertType.Error, true));
    expect(wrapper.find(".errors-message")).toHaveLength(1);
    expect(
      wrapper.containsMatchingElement(
        <a href="mailto:support@askbreeding.freshdesk.com">ASK BREEDING</a>
      )
    ).toEqual(true);
  });

  test("renders Warning alert", () => {
    const wrapper = shallow(createAlert(IAlertType.Warning, true));
    expect(wrapper.find(".warning-message")).toHaveLength(1);
  });

  test("renders Info alert", () => {
    const wrapper = shallow(createAlert(IAlertType.Info, true));
    expect(wrapper.find(".info-message")).toHaveLength(1);
  });

  test("test onDismissClick", async () => {
    const onDismiss = jest.fn();
    const alert: IAlert = {
      message: "Message",
      type: IAlertType.Error,
      askBreeding: false,
    };
    const wrapper = shallow(<Alert alert={alert} onDismissClick={onDismiss} />);
    expect(wrapper.state()["isOpen"]).toBeTruthy();
    wrapper.find(".btn-tertiary").simulate("click");
    expect(wrapper.state()["isOpen"]).toBeFalsy();
  });

  test("test icons as per alert type", () => {
    const alert: IAlert = {
      message: "Message",
      type: IAlertType.Error,
      askBreeding: false,
    };
    const component = new Alert({
      alert,
      onDismissClick: jest.fn(),
    });
    expect(component.getIcon("error").type.displayName).toBe("ErrorIcon");
    expect(component.getIcon("info").type.displayName).toBe("ErrorIcon");
    expect(component.getIcon("warning").type.displayName).toBe("WarningIcon");
    expect(component.getIcon("default").type.displayName).toBe("ErrorIcon");
  });
});
