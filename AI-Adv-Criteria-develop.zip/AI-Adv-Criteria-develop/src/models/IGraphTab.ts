import { IResultData } from "./IResults";

export interface IListItem {
  id: string;
  text: string;
  isSelected: boolean;
}

export interface IDataset {
  [key: string]: number[];
}

export interface IGraphData {
  traitsForSelectedPipeline: ITraitsForSelectedPipeline;
  prescForSelectedAnalyses: IPrescForSelectedAnalyses;
  blupsDataForSelectedVersion: IBlupsDataForSelectedVersion;
}

export interface ITraitsForSelectedPipeline {
  [type: string] : string[]
}

export interface IPrescForSelectedAnalyses {
  [type: string] : IResultData
}

export interface IBlupsDataForSelectedVersion {
  [type: string] : IDataset
}
