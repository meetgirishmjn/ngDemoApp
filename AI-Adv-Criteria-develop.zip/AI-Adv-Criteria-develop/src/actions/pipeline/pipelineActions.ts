import _ from "lodash";
import gptApi from "../../api/gptApi";
import genApi from "../../api/genApi";
import {
  ICropRegionResponse,
  ISubMarket,
} from "../../../src/models/ISearchResults";

/*
  loads regions, harvestTypes and Markets
*/
export const loadTraits = async (
  crop: string,
  year: string,
  region: string,
  harvestType: string,
  market: string
): Promise<ICropRegionResponse[]> => {
  try {
    const response = await gptApi.get(
      `/pipelines/crop-region?crop=${crop}&year=${year}&region=${region}&harvestType=${harvestType}&market=${market}`
    );
    const data: ICropRegionResponse[] = response.data;
    return data;
  } catch (error) {
    // returns empty response
    return [];
  }
};

export const getSubMarkets = async (
  crop: string,
  year: string,
  region: string,
  harvestType: string,
  market: string
) => {
  try {
    // const response = await gptApi.get(`/pipelines/crop-region?crop=${crop}&year=${year}&region=${region}&harvestType=${harvestType}&market=${market}`);
    // https://api01-np.agro.services/api-gen/v1/sub-markets/crop-region-market?crop=Corn&region=NA&harvestType=G&market=RM120
    const genResponse = await genApi.get(
      `/sub-markets/crop-region-market?crop=${crop}&region=${region}&harvestType=${harvestType}&market=${market}`
    );
    const data: ICropRegionResponse[] = genResponse.data;
    const mapSubMarkets = mapSubMarket(data);
    return mapSubMarkets;
  } catch (error) {
    return null;
  }
};

export const mapSubMarket = (cropRegionResponse: any): ISubMarket[] => {
  const subMarkets = Array.isArray(cropRegionResponse)
    ? cropRegionResponse.map((row: ICropRegionResponse) => {
        return {
          id: row.subMarketId,
          name: row.subMarketName,
        };
      })
    : [];
  return _.uniqBy(subMarkets, "id");
};

export const getProductStageRefs = async () => {
  try {
    const response = await gptApi.get("/product-stage-refs");
    let data = response.data as IPsRef[];
    data = _.filter(data, (obj: IPsRef) => {
      return obj.productStageId === obj.combineProductStageId;
    });
    return data;
  } catch (error) {
    return [];
  }
};
