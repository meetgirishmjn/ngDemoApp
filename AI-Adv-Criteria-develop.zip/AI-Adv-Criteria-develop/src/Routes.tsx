import React, { Component } from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import RouterConstants from "./common/router-constants";
import Home from "./components/views/home";
import SearchResults from "./components/searchResults";

interface IProps {
  services: any;
}
class Routes extends Component<IProps, any> {
  public render() {
    const { services } = this.props;
    return (
      <BrowserRouter basename={RouterConstants.BASE_URL}>
        <div className="routes">
          <Switch>
            <Route path={RouterConstants.HOME} exact={true}>
              <Home services={services} />
            </Route>
            <Route>
              <SearchResults horizonServices={services} />
            </Route>
          </Switch>
        </div>
      </BrowserRouter>
    );
  }
}

export default Routes;
