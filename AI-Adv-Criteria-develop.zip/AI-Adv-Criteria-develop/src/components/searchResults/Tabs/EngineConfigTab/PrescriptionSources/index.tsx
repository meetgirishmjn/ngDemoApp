import React, { Component, useState } from "react";
import "./PrescriptionSources.scss";
import {
  clone,
  orderBy,
  uniq,
  difference,
  isEqual,
  isArray,
  find,
  findIndex,
} from "lodash";
import IPrescriptionSourcesProps from "./PrescriptionSourcesProps";
import IPrescriptionSourcesState from "./PrescriptionSourcesState";
import { TabsContainer, Tab } from "@monsantoit/ui-react-tabs";
import { IAnalysisSubType } from "../../../../../models/IAnalyticModel";
import {
  advConfigQuery,
  createFullfilment,
  deleteFullfilment,
  updateFullfilment
} from "../../../../../actions/advConfigDb/advConfigQuery";
import { findAdvRequistionsToStoreFulfillmentId, IPsAndReqId } from "../helper";
import { DropDown } from "@monsantoit/ui-react-base-controls";
import _ from "lodash";

const TAB1_NAME = "PREDICTION";
const TAB1_TITLE = "Prediction Sources";
const TAB2_NAME = "BLUP";
const TAB2_TITLE = "BLUP Sources";

export default class PrescriptionSources extends Component<
  IPrescriptionSourcesProps,
  IPrescriptionSourcesState
> {

  tabChangeFlag = null;

  constructor(props: IPrescriptionSourcesProps) {
    super(props);
    this.state = {
      tabHash: {
        [TAB1_NAME]: [],
        [TAB2_NAME]: [],
      },
      analysisSubTypes: props.analysisSubTypes,
      filteredData: []
    };
  }

  public componentDidMount(){
    this.tabChangeFlag = true;
  }

  static getDerivedStateFromProps(
    nextProps: IPrescriptionSourcesProps,
    prevState: IPrescriptionSourcesState
  ) {
    if (!isEqual(nextProps.analysisSubTypes, prevState.analysisSubTypes)) {
      return { analysisSubTypes: nextProps.analysisSubTypes };
    } else return null;
  }

  componentDidUpdate(prevProps, prevState) {
    if (!isEqual(prevProps.analysisSubTypes, this.props.analysisSubTypes)) {
      const tabHash = clone(this.state.tabHash);
      tabHash[TAB1_NAME] = this.updatePreSelectedUIDs(
        this.props.analysisSubTypes,
        TAB1_NAME
      );
      tabHash[TAB2_NAME] = this.updatePreSelectedUIDs(
        this.props.analysisSubTypes,
        TAB2_NAME
      );
      this.setState({ tabHash });
    }
  }

  public updatePreSelectedUIDs = (
    analysisSubTypes: IAnalysisSubType[],
    tabName: string
  ) => {
    const data: IAnalysisSubType[] = analysisSubTypes.filter(
      (subType: IAnalysisSubType) => subType.analyticModelType === tabName
    );
    const uids = this.getUIDs(data);
    return uids;
  };

  public getUIDs = (data: IAnalysisSubType[]) => {
    const predSelectedUIDs = data
      .filter(function (obj) {
        return obj.hasFulfillment;
      })
      .map(function (obj) {
        return obj.uid;
      });
    return predSelectedUIDs;
  };

  public onSelectionTabChanged = (value: string, event: any) => {
    this.setState({ filteredData: [] });
    this.tabChangeFlag = true;
  };

  public onItemSelection = async (
    tabName: string,
    items: IAnalysisSubType[] | IAnalysisSubType
  ) => {
    let { tabHash, analysisSubTypes } = this.state;
    const tabHashOriginal = {...tabHash};
    const analysisSubTypesOriginal = [...analysisSubTypes]
    const tabHashUpdate = {...tabHash};
    if (isArray(items)) {
      tabHashUpdate[tabName] = items.map((o) => o.uid);
      this.setState({ tabHash: tabHashUpdate });
    } else {
      // get previous selected index
      const prevSelectedIndex = findIndex(analysisSubTypes, {
        analysisSubTypeId: items.analysisSubTypeId,
        hasFulfillment: true,
      });
      if (analysisSubTypes[prevSelectedIndex]) {
        analysisSubTypes[prevSelectedIndex].hasFulfillment = false;
        tabHashUpdate[tabName] = this.updatePreSelectedUIDs(
          analysisSubTypes,
          tabName
        );
        this.setState({ analysisSubTypes, tabHash: tabHashUpdate });
      }
      // get current selected index
      const selected = findIndex(analysisSubTypes, { analysisId: items.analysisId });
      const checked = !tabHash[tabName].includes(items.uid);
      // store or delete fulfillmentID
      if(checked) {
        analysisSubTypes[selected].hasFulfillment = true;
        tabHashUpdate[tabName] = this.updatePreSelectedUIDs(
          analysisSubTypes,
          tabName
        );
        this.setState({ analysisSubTypes, tabHash: tabHashUpdate });
        const { response, fulfillmentID } = await this.storeFulfillmentId(analysisSubTypes[selected], this.props.selectedParams);
        if(response.hasError || (response.data.errors && response.data.errors.length > 0)) {
          this.props.horizonServices.toast.error("Failed to save/update fulfillments");
          // revert back to previous data
          this.setState({ analysisSubTypes: analysisSubTypesOriginal, tabHash: tabHashOriginal });
        } else {
          analysisSubTypes[selected].fulfillmentID = fulfillmentID;
          this.setState({ analysisSubTypes });
        }
      } else if(!checked && analysisSubTypes[selected].fulfillmentID) {
          deleteFullfilment(analysisSubTypes[selected].fulfillmentID, "delete");
      }
    }
  };

  public storeFulfillmentId = async (
    analysisSubType: IAnalysisSubType,
    selectedParams: IPipeline
  ) => {
    const advResponse = await advConfigQuery(
      selectedParams.Crop.value,
      selectedParams.Region.key,
      selectedParams.HarvestType.key,
      selectedParams.Year,
      selectedParams.Market.key
    );
    if (!advResponse.hasError) {
      const filteredPsAndReqId: IPsAndReqId = await findAdvRequistionsToStoreFulfillmentId(
        advResponse.data,
        analysisSubType,
        selectedParams,
        this.props.horizonServices
      );
      let response: any = {
        hasError: false
      }
      response.hasError = !filteredPsAndReqId;
      try {
        if(filteredPsAndReqId) {
          response = await createFullfilment(
            filteredPsAndReqId.configDataRequisitionId,
            filteredPsAndReqId.productStageGroupMemberId,
            analysisSubType.analysisId
          );
          if(!response.hasError && response.data && response.data.errors && response.data.errors.length > 0) {
            // check if errors has DUPLICATE code, if duplicate try updateFulfillment
            const duplicate = find(response.data.errors, error => error.extensions &&
              (error.extensions.code === "DUPLICATE" || error.extensions.code === "INACTIVE"));
            if(duplicate && filteredPsAndReqId.fulfillmentID) {
              response = await updateFullfilment(filteredPsAndReqId.fulfillmentID, analysisSubType.analysisId, "updating analysisID")
            }
          }
        } else {
          this.props.horizonServices.toast.error(
            "Analysis can not be marked as a a source as it has not been requested in Define Data. Please return to Define Data and request that analysis for this pipeline"
          );
        }
      } catch(error) {
        response.hasError = true
      }
      return {
        fulfillmentID: filteredPsAndReqId ? filteredPsAndReqId.fulfillmentID : null,
        response
      };
    }
  };

  private calculateTableData = async (value, tabName) => {
    const data = this.props.analysisSubTypes.filter(
      (o) => o.analyticModelType === tabName
    );
   
    const tableData = await data.filter(
      (o) => o.analysisSubTypeName === value.analysisSubTypeName
    );

    this.setState({ filteredData: tableData });
  }

  private handleDropdownChange = async (value, tabName) => {
    this.setState({ filteredData: [] });
    this.tabChangeFlag = false;
    this.calculateTableData(value, tabName);    
  }

  public renderContent = (tabName: string) => {
    const data = this.props.analysisSubTypes.filter(
      (o) => o.analyticModelType === tabName
    );
    const dropDownData = _.uniqBy(data, "analysisSubTypeName");
    const orderedDropDownData = _.orderBy(dropDownData, ["analysisSubTypeName"], ["asc", "desc"]);    
    const defaultDropDownData = orderedDropDownData[0];
    const tableData = data.filter(
      (o) => o.analysisSubTypeName === defaultDropDownData.analysisSubTypeName
    );

    return (
      <div className="analytic-modal-dropdown">
        <DropDown
          name="selectedTrait"
          isMultiselect={false}
          sorted={true}
          data={dropDownData}
          textProperty="analysisSubTypeName"
          hasAllCheckbox={false}
          selectedItem={defaultDropDownData}
          onSelectionChanged={(e, item) => {
            this.handleDropdownChange(item, tabName);
          }}
        />
        <div className="sources-panel mt-24">
          <SearchTable
            key={tabName}
            data={this.tabChangeFlag === true ? tableData : this.state.filteredData}
            preSelectedUIDs={this.state.tabHash[tabName]}
            isDataLoading={this.props.isDataLoading}
            onSelection={(items) => {
              this.onItemSelection(tabName, items);
            }}
            versionId={this.props.versionId}
            selectedParams={this.props.selectedParams}
            isEditable={this.props.isEditable}
          />
        </div>
      </div>
    );
  };

  public render() {
    let tab1Title = TAB1_TITLE;
    let selectedIds = this.state.tabHash[TAB1_NAME];
    if (selectedIds?.length > 0) {
      tab1Title += ` (${selectedIds.length})`;
    }

    let tab2Title = TAB2_TITLE;
    selectedIds = this.state.tabHash[TAB2_NAME];
    if (selectedIds?.length > 0) {
      tab2Title += ` (${selectedIds.length})`;
    }

    return (
      <TabsContainer
        defaultTab={this.props.selectedTab || "PredictionSources"}
        onSelectionTabChanged={this.onSelectionTabChanged}
      >
        <Tab key={TAB1_NAME} name={TAB1_NAME} title={tab1Title}>
          {this.renderContent(TAB1_NAME)}
        </Tab>
        <Tab key={TAB2_NAME} name={TAB2_NAME} title={tab2Title}>
          {this.renderContent(TAB2_NAME)}
        </Tab>
      </TabsContainer>
    );
  }
}

interface IFilteredData extends IAnalysisSubType {
  fulfillmentID?: number;
}

const SearchTable: React.FC<{
  data: IAnalysisSubType[];
  isDataLoading: boolean;
  preSelectedUIDs: string[];
  onSelection: (items: IAnalysisSubType[] | IAnalysisSubType) => void;
  versionId: string;
  selectedParams: IPipeline;
  allCheckbox?: boolean;
  isEditable: boolean;
}> = (props) => {
  const [searchKey, setSearchKey] = useState("");
  const [sortBy, setSortBy] = useState("analysisSubTypeName");
  const [sortOrder, setSortOrder] = useState("asc");
  const [isAllChecked, setCheckAll] = useState(false);
  const [filteredData, setFilteredData] = useState(
    props.data as IFilteredData[]
  );
  const [selectedUIDs, setSelectedUIDs] = useState(props.preSelectedUIDs);

  React.useEffect(() => {
    const data = getFilteredData(searchKey, sortBy, sortOrder);
    setFilteredData(data);
    setCheckAll(data.length === props.preSelectedUIDs.length);
    setSelectedUIDs(props.preSelectedUIDs);
  }, [props.data, props.isDataLoading, props.preSelectedUIDs]);

  const getFilteredData = (
    searchKey: string,
    sortBy: string,
    sortOrder: string
  ) => {
    let filteredData: IAnalysisSubType[] = [];
    const key = searchKey.trim();

    if (key.length > 0) {
      props.data.forEach((o) => {
        if (
          o.analysisName.toLowerCase().includes(key) ||
          o.analysisDescription.toLowerCase().includes(key) ||
          o.analysisSubTypeName.toLowerCase().includes(key)
        ) {
          filteredData.push(o);
        }
      });
    } else {
      filteredData = props.data;
    }

    // sort
    return orderBy(filteredData, sortBy, sortOrder === "asc" ? "asc" : "desc");
  };

  const toggleSort = (propName: string) => {
    if (props.isDataLoading) {
      return;
    }
    const order = sortOrder === "asc" ? "desc" : "asc";
    setSortBy(propName);
    setSortOrder(order);
    setFilteredData(getFilteredData(searchKey, propName, order));
  };

  const onSearch = (value: string) => {
    if (props.isDataLoading) {
      return;
    }
    setSearchKey(value);
    const data = getFilteredData(value, sortBy, sortOrder);
    setFilteredData(data);
    // ensure check all
    let isAllFilteredChecked = true;
    data.forEach((o) => {
      if (isAllFilteredChecked && !selectedUIDs.includes(o.uid)) {
        isAllFilteredChecked = false;
      }
    });
    setCheckAll(isAllFilteredChecked);
  };

  const onToggleCheckAll = () => {
    const isAll = !isAllChecked;
    const newUids: string[] = [];
    let resultUids: string[] = [];
    if (isAll) {
      filteredData.forEach((item) => newUids.push(item.uid));
      resultUids = uniq([...selectedUIDs, ...newUids]);
    } else {
      const removeUids = filteredData.map((o) => o.uid);
      resultUids = difference(selectedUIDs, removeUids);
    }
    setCheckAll(isAll);
    props.onSelection(props.data.filter((o) => resultUids.includes(o.uid)));
  };

  const onToggleRowCheck = (item: IAnalysisSubType) => {
    /* const checked = !selectedUIDs.includes(item.uid);
    const uids = selectedUIDs.filter((uid) => item.uid !== uid);
    if (checked) {
      uids.push(item.uid);
      storeFulfillmentId(item, props.versionId, props.selectedParams);
    } else {
      deleteFullfilment(30000003, "delete");
    }
    setSelectedUIDs(uids);
    let isAllFilteredChecked = true;
    filteredData.forEach((o) => {
      if (isAllFilteredChecked && !uids.includes(o.uid)) {
        isAllFilteredChecked = false;
      }
    });
    setCheckAll(isAllFilteredChecked); */
    props.onSelection(item);
  };

  const sortIconClass = (propName: string) => {
    if (propName === sortBy) {
      return sortOrder === "asc" ? "fa fa-sort-asc" : "fa fa-sort-desc";
    }
    return "";
  };

  const hadData = filteredData.length > 0;

  return (
    <>
      {" "}
      <div className="search-panel">
        <div className="search-div">
          <input
            onChange={(e) => onSearch(e.target.value)}
            className="form-control txt16"
            placeholder="Search..."
            type="text"
            value={searchKey}
          />
        </div>
      </div>
      <table className="table table-sm table-bordered sources-table txt14">
        <thead>
          {!props.isDataLoading && (
            <tr>
              <th className="chk-th" scope="col">
                {props.allCheckbox && (
                  <div className="chk-div">
                    <label>
                      {!hadData && (
                        <input
                          checked={false}
                          disabled={true}
                          type="checkbox"
                        />
                      )}
                      {hadData && (
                        <input
                          checked={isAllChecked}
                          onChange={() => onToggleCheckAll()}
                          type="checkbox"
                        />
                      )}
                      <span />
                    </label>
                  </div>
                )}
              </th>
              <th onClick={() => toggleSort("analysisSubTypeName")} scope="col">
                Analysis Sub-Type{" "}
                <span className={sortIconClass("analysisSubTypeName")} />
              </th>
              <th onClick={() => toggleSort("analysisName")} scope="col">
                Analysis Name <span className={sortIconClass("analysisName")} />
              </th>
              <th onClick={() => toggleSort("analysisDescription")} scope="col">
                Analysis Description{" "}
                <span className={sortIconClass("analysisDescription")} />
              </th>
            </tr>
          )}
        </thead>
        <tbody>
          {props.isDataLoading && (
            <tr className="tr-loading">
              <td colSpan={4} align="center">
                <span> Loading</span>
              </td>
            </tr>
          )}
          {!props.isDataLoading && filteredData.length === 0 && (
            <tr className="tr-no-data">
              <td colSpan={4} align="center">
                <span>No data to display</span>
              </td>
            </tr>
          )}
          {filteredData.map((item) => (
            <tr key={`${item.uid}}`}>
              <td>
                <div className="chk-div">
                  <label>
                    <input
                      checked={selectedUIDs.includes(item.uid)}
                      onChange={() => onToggleRowCheck(item)}
                      type="checkbox"
                      disabled={props.isEditable? false : true}
                    />
                    <span />
                  </label>
                </div>
              </td>
              <td>{item.analysisSubTypeName}</td>
              <td>{item.analysisName}</td>
              <td>{item.analysisDescription}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
};
