import React, { Component } from "react";
import { connect } from "react-redux";
import IEngineConfigTabProps from "./EngineConfigTabProps";
import IEngineConfigTabState from "./EngineConfigTabState";
import "./engineConfigTab.scss";
import { Tooltip } from "@material-ui/core";
import { withStyles } from "@material-ui/core/styles";
import FieldRenderer from "./fieldRenderer";
import {
  IConfigField,
  IConfigurationTemplate,
  IConfigFieldRow,
} from "src/actions/criteria/models";
import { calculateFieldValue } from "../../../../actions/criteria/helpers";
import PrescriptionSources from "./PrescriptionSources";
import IRootStore from "../../../../store/IRootStore";
import { getAnalyseSubTypes, getAnalyseSubTypesForPrescSources } from "../../../../actions/pac/pacActions";
import { IAnalysisSubType } from "../../../../models/IAnalyticModel";
import { advConfigQuery } from "../../../../actions/advConfigDb/advConfigQuery";
import {
  IQueryAdvConfigResponse,
  IFulfillment,
} from "../../../../models/IAdvConfig";
import { IConfigApiBaseRes } from "../../../../actions/advConfigDb/models";
import {
  saveCriteriaValues,
  updateCriteriaValues,
} from "../../../../actions/criteria/criteriaActions";
import { parseTraitParam, findAdvRequistions, parseJsonValue } from "./helper";
import _ from "lodash";

class EngineConfigTab extends Component<
  IEngineConfigTabProps,
  IEngineConfigTabState
> {
  public customTooltipCss = null;
  public INPUT_DEBOUNCE_DELAY = 700;

  constructor(props: IEngineConfigTabProps) {
    super(props);
    this.state = {
      template: props.template,
      analysisSubTypes: [],
      isAnalysisSubTypesLoading: true,
      criteriaValueId: null,
    };
    if ((this.props as any).classes) {
      this.customTooltipCss = (this.props as any).classes.customTooltip;
    }
  }

  public componentDidMount() {
    // this data load is low priority, wait till other api are done
    setTimeout(async () => {
      const {
        Crop,
        Region,
        Year,
        HarvestType,
        Market,
        Trait,
        SubMarket,
      } = this.props.selectedParams;
      try {
        const results = await Promise.all([
         getAnalyseSubTypesForPrescSources(
            Crop.value,
            +Year,
            Region.key,
            HarvestType.key,
            Market.key
          ),
          advConfigQuery(
            Crop.value,
            Region.key,
            HarvestType.key,
            Year,
            Market.key,
            parseTraitParam(Trait).value,
            SubMarket.key
          ),
        ]);

        const analysisSubTypes = this.filterAnalysisSubTypesFromDefinData(
          results[0],
          results[1]
        );
        this.setState({
          analysisSubTypes,
          isAnalysisSubTypesLoading: false,
        });
      } catch (ex) {
        console.log(ex);
        this.setState({
          analysisSubTypes: [],
          isAnalysisSubTypesLoading: false,
        });
      }
    }, 1500);
  }

  public filterAnalysisSubTypesFromDefinData = (
    analysisSubTypes: IAnalysisSubType[],
    defineDataRes: IConfigApiBaseRes<IQueryAdvConfigResponse>
  ): IAnalysisSubType[] => {
    let filteredAnalysisSubTypes: IAnalysisSubType[] = [];
    let fullFillments: any[] = [];
    const { ProductStage, Trait, SubMarket } = this.props.selectedParams;
    const AnalysisTypeNames = ["PREDICTION", "BLUP"];

    if (!defineDataRes.hasError) {
      // find subset for selectedParams
      const requistions = findAdvRequistions(
        defineDataRes.data,
        SubMarket.key,
        parseTraitParam(Trait).value,
        ProductStage.value
      );
      const pacRequistions = requistions.filter(
        (o) => o.dataProviderName === "PAC"
      );
      AnalysisTypeNames.forEach((typeName) => {
        const defineDataAnalysisSubTypeIds: string[] = [];
        pacRequistions.forEach((req) => {
          fullFillments = [...new Set([...fullFillments, ...req.fulfillments])];
          if (
            req.requisitionItems.find(
              (o) =>
                o.dataProviderAttributeName === "analysisTypeName" &&
                parseJsonValue(o.value) === typeName &&
                o.refActive
            )
          ) {
            const reqItem = req.requisitionItems.find(
              (o) =>
                o.dataProviderAttributeName === "analysisSubTypeId" &&
                o.value &&
                o.refActive
            );
            if (reqItem) {
              const reqItemDataUI = req.requisitionItems.find(
                (o) =>
                  o.dataProviderAttributeName === "traitsCalcsDefineDataUI" &&
                  o.value
              );
              if (
                reqItemDataUI &&
                parseJsonValue(reqItemDataUI.value).traits.length
              ) {
                defineDataAnalysisSubTypeIds.push(
                  `${parseJsonValue(reqItem.value)}`
                );
              }
            }
          }
        });
        // filter out ones not selected in Define Data
        const matchedItems = analysisSubTypes.filter(
          (o) =>
            o.analyticModelType === typeName &&
            defineDataAnalysisSubTypeIds.includes(o.analysisSubTypeId)
        );
        filteredAnalysisSubTypes = [
          ...filteredAnalysisSubTypes,
          ...matchedItems,
        ];
      });
    }
    filteredAnalysisSubTypes.forEach((analysisSubType: IAnalysisSubType) => {
      const foundFulfillment: IFulfillment = fullFillments.find(
        (fullFillment: IFulfillment) =>
          fullFillment.externalId ===
            parseInt(analysisSubType.analysisId, 10) && fullFillment.refActive
      );
      analysisSubType.hasFulfillment = foundFulfillment ? true : false;
      analysisSubType.fulfillmentID = foundFulfillment ? foundFulfillment.id : null;
    });
    filteredAnalysisSubTypes = _.uniqBy(filteredAnalysisSubTypes, 'uid');
    return filteredAnalysisSubTypes;
  };

  public saveCriteriaValuesOnchange = _.debounce(
    async (field: IConfigField, isValid: boolean) => {
      const { analysisId, analysisVersion } = this.props;
      if (isValid) {
        if (field.criteriaValueId === null) {
          const savedValue = await saveCriteriaValues(
            field.criteriaDefaultValueId,
            analysisId,
            analysisVersion,
            field.value
          );
          if (savedValue.data) {
            this.setState({ criteriaValueId: savedValue.data.id });
          }
          if (savedValue.hasError) {
            if (
              savedValue.errorMessage
                .toLowerCase()
                .replace(/\s/g, "")
                .includes("updatecriteriavalue")
            ) {
              let errorMsg = savedValue.errorMessage;
              let id = parseInt(errorMsg.replace(/\D/g, ""));
              this.setState({ criteriaValueId: id });
              this.updateCriteriaValuesOnchange(field);
            } else {
              this.props.horizonServices.toast.error(savedValue.errorMessage);
            }
          }
        } else {
          this.updateCriteriaValuesOnchange(field);
        }
      }
    },
    this.INPUT_DEBOUNCE_DELAY
  );

  public updateCriteriaValuesOnchange = async (field: IConfigField) => {
    const id =
      field.criteriaValueId === null
        ? this.state.criteriaValueId
        : field.criteriaValueId;
    const savedValue = await updateCriteriaValues(id, true, field.value);
    if (savedValue.hasError) {
      this.props.horizonServices.toast.error(savedValue.errorMessage);
    }
  };

  /*
    This is an optional method onField change
    @params
    field: updated field,
    fieldSection: to which section it belonged to
    fieldRow: to which row it belonged to
  */
  public onFieldChanged = (
    field: IConfigField,
    fieldSection: string,
    fieldRow: string,
    isValid: boolean
  ) => {
    this.saveCriteriaValuesOnchange(field, isValid);
    if (field.onChangeArguments) {
      const templateToUpdate: IConfigurationTemplate = _.cloneDeep(
        this.state.template
      );
      const sectionIndex = _.findIndex(
        templateToUpdate.sections,
        (section) => section.key === fieldSection
      );
      const rowIndex = _.findIndex(
        templateToUpdate.sections[sectionIndex].fieldRows,
        (obj) => obj.key === fieldRow
      );
      const fieldIndex = _.findIndex(
        templateToUpdate.sections[sectionIndex].fieldRows[rowIndex].fields,
        (obj) => obj.key === field.onChangeArguments.arguments.derivedFieldName
      );
      templateToUpdate.sections[sectionIndex].fieldRows[rowIndex].fields[
        fieldIndex
      ].value = calculateFieldValue(
        field.value,
        field.onChangeArguments.operation
      );
      this.setState({ template: templateToUpdate }, () => {
        console.log(templateToUpdate);
      });
    }
  };

  public onLoseFocus = (field: IConfigField) => {
    // this.saveCriteriaValuesOnchange(field);
  };

  public renderChildRow(sectionKey: string, row: IConfigFieldRow): JSX.Element {
    return (
      <>
        <div key={`${row.key}_title`} className="form-row-title has-tooltip">
          <h4>{row.label}</h4>
          {row.tooltip && (
            <Tooltip
              placement="right-start"
              title={
                <span
                  dangerouslySetInnerHTML={{
                    __html: row.tooltip,
                  }}
                />
              }
              classes={{ tooltip: this.customTooltipCss }}
            >
              <i className="info material-icons color-status-blue">info</i>
            </Tooltip>
          )}
        </div>
        <div key={row.key} className="form-row">
          {this.renderRowFields(sectionKey, row.key, row.fields)}
        </div>
        {row.childRows.map((childRow) =>
          this.renderChildRow(sectionKey, childRow)
        )}
      </>
    );
  }

  public renderRowFields(
    sectionKey: string,
    rowKey: string,
    fields: IConfigField[]
  ): JSX.Element {
    return (
      <>
        {fields.map((field) => (
          <div key={field.key} className="sec-cell">
            <FieldRenderer
              key={field.key}
              section={sectionKey}
              row={rowKey}
              field={field}
              customTooltipCss={this.customTooltipCss}
              onFieldChange={this.onFieldChanged}
              isDisabled={!this.props.isEditable}
              onBlurField={this.onLoseFocus}
            />
          </div>
        ))}
      </>
    );
  }

  public render() {
    return (
      <>
        <div className="mt-24">
          {this.state.template &&
            this.state.template.sections.map((section) => (
              <div key={section.key} className="cards card-grey">
                {section.title && (
                  <h2 className="sec-title m-24">
                    {section.title}
                    {section.tooltip && (
                      <Tooltip
                        placement="right-start"
                        title={
                          <span
                            dangerouslySetInnerHTML={{
                              __html: section.tooltip,
                            }}
                          />
                        }
                        classes={{ tooltip: this.customTooltipCss }}
                      >
                        <i className="material-icons color-status-blue">info</i>
                      </Tooltip>
                    )}
                  </h2>
                )}
                <div key={section.key} className="sec-body">
                  {this.renderRowFields(
                    section.key,
                    "section_0",
                    section.fields
                  )}
                  {section.fieldRows.map((fieldRow) =>
                    this.renderChildRow(section.key, fieldRow)
                  )}
                </div>
                {section.hasRequiredField && (
                  <div className="sec-footer">
                    <label className="txt14 color-status-red">* Required</label>
                  </div>
                )}
              </div>
            ))}
        </div>
        <div className="mt-48 mb-48">
          <PrescriptionSources
            selectedTab={null}
            analysisSubTypes={this.state.analysisSubTypes}
            isDataLoading={this.state.isAnalysisSubTypesLoading}
            versionId={this.props.analysisId}
            selectedParams={this.props.selectedParams}
            horizonServices={this.props.horizonServices}
            isEditable={this.props.isEditable}
          />
        </div>
      </>
    );
  }
}

const tooltipStyles = (theme) => ({
  customTooltip: {
    backgroundColor: "#6D6D6D",
    borderRadius: "4px",
    height: "auto",
    fontFamily: '"Helvetica Neue", Helvetica, Arial, sans-serif',
    fontWeight: 400,
    color: "#z`",
    fontSize: "12px",
  },
});

const mapStateToProps = (state: IRootStore) => {
  return {
    selectedParams: state.userPreferences.userPreferences,
  };
};

export default connect(
  mapStateToProps,
  null
)(withStyles(tooltipStyles)(EngineConfigTab));
