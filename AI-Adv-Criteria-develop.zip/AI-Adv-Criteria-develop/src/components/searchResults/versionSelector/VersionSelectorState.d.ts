import { IModelVersion } from "../../../actions/criteria/models";
import { ViewTypes } from "../SearchResultsState";

interface IVersionSelectorState {
    selectedVersion: IModelVersion;
    modelVersions: IModelVersion[];
    isVersionDataLoading: boolean;
    isCreateVersionInProgress: boolean;
    isVersionDialogVisible: boolean;
    showMenu: boolean;
    isRunAnalysisModalVisible: boolean;
    isSaveToAdvModalVisible: boolean;
    createVerDialogKey: string;
    createVersionFromSource: IModelVersion;
    viewType: ViewTypes;
    selectedRunId?: number;
    isRefreshinProgress: boolean;
}

export default IVersionSelectorState;
