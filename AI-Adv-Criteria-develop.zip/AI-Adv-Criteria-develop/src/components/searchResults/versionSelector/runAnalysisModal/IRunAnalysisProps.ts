import { IModelVersion, IConfigurationTemplate } from "../../../../actions/criteria/models";

export default interface IRunAnalysisProps {
    showModalDialog?: boolean;
    horizonServices?: any;
    selectedParams: IPipeline;
    selectedVersion: IModelVersion;
    onModalHide?: () => void;
    template: IConfigurationTemplate;
    userId: string;
    onAnalysisRunSuccess?: (analysis: IModelVersion) => void;
}