import axios from "axios";

export interface ILogModel {
  appId: string;
  message: string;
  data?: any;
  logLevel: string;
  userId: string;
}

class Logger {
  public static _createLog = (
    message: string,
    userId: string,
    logLevel: string,
    data?: any
  ) => {
    const APP_ID = "Advancement-Criteria";
    const log: ILogModel = {
      appId: `${APP_ID}-${process.env.ENVIRONMENT}`,
      message,
      logLevel,
      userId,
      data,
    };
    return { logText: JSON.stringify(log) };
  };

  public static logError = (message: string, userId: string, data?: any) => {
    const log = Logger._createLog(message, userId, "ERROR", data);
    axios.post(`${process.env.BASE_PATH}/log`, log);
  };

  public static logInfo = (message: string, userId: string, data?: any) => {
    const log = Logger._createLog(message, userId, "INFO", data);
    axios.post(`${process.env.BASE_PATH}/log`, log);
  };

  public static logWarning = (message: string, userId: string, data?: any) => {
    const log = Logger._createLog(message, userId, "WARNING", data);
    axios.post(`${process.env.BASE_PATH}/log`, log);
  };
}

export default Logger;
