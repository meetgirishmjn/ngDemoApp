import {
  IConfigurationTemplate,
  IConfigField,
  IConfigSection,
  IConfigFieldRow,
  FieldTypes,
} from "./models";
import _ from "lodash";

export function configTemplateJsonParser(
  data: ICriteriaValueRes
): IConfigurationTemplate {
  const template: IConfigurationTemplate = {
    sections: [],
  };

  if (data.analysis && data.analysis.criteria) {
    const criteriaList = data.analysis.criteria.filter(
      (o) => o.group.length > 0
    );
    const allSectionNames: string[] = [];
    const allFieldNames: Map<string, string> = new Map();
    data.analysis.criteria.forEach((o) => {
      if (o.group.length !== 0 && !allSectionNames.includes(o.group[0])) {
        allSectionNames.push(o.group[0]);
      }
      // read all groupHeaders and map it to groups
      if (o.groupHeader && o.groupHeader.length !== 0) {
        o.groupHeader.forEach((header, index) => {
          allFieldNames.set(o.group[index], header);
        })
      }
    });
    allSectionNames.forEach((sectionName) => {
      const section: IConfigSection = {
        key: `section_${template.sections.length + 1}`,
        title: sectionName,
        tooltip: "",
        hasRequiredField: false,
        fields: [],
        fieldRows: [],
      };

      const sectionCriteriaList = criteriaList.filter(
        (o) => o.group[0] === sectionName
      );
      const fieldRow = getAllChildFields(sectionCriteriaList, [sectionName], allFieldNames);
      fieldRow.key += section.fieldRows.length + 1;
      section.fields = fieldRow.fields;
      section.fieldRows = fieldRow.childRows;

      section.hasRequiredField = checkSectionHasRequiredField(section);

      template.sections.push(section);
    });
  }
  // Shifts Required object to 0th position
  if(template.sections.length > 0) {
    const requiredSection = template.sections.find((section: IConfigSection) => section.title === "Required");
    template.sections = template.sections.filter((section: IConfigSection) => section.title !== "Required");
    requiredSection && template.sections.unshift({...requiredSection});
  }
  return template;
}

const getAllChildFields = (
  fieldResList: IFieldValueRes[],
  groups: string[],
  allFieldNames: Map<string, string>
): IConfigFieldRow => {
  if (!groups && groups.length === 0) {
    return null;
  }

  const fieldRow: IConfigFieldRow = {
    title: groups[groups.length - 1],
    label: allFieldNames.get(groups[groups.length - 1]) || groups[groups.length - 1],
    key: groups.join("_"),
    tooltip: "",
    fields: [],
    childRows: [],
    hasRequiredField: false,
  };

  const matchedLevelFieldResList = fieldResList.filter(
    (o) => o.group.slice(0, groups.length).join("_") === groups.join("_")
  );

  const nextGroupNames: string[] = [];
  matchedLevelFieldResList.forEach((fieldRes) => {
    if (fieldRes.group.length > groups.length) {
      const nextGroupName = fieldRes.group[groups.length];
      if (!nextGroupNames.includes(nextGroupName)) {
        nextGroupNames.push(nextGroupName);
        const childRow = getAllChildFields(matchedLevelFieldResList, [
          ...groups,
          nextGroupName,
        ], allFieldNames);
        if (childRow !== null) {
          childRow.key += fieldRow.childRows.length + 1;
          fieldRow.childRows.push(childRow);
        }
      }
    } else {
      // it is a field
      const field = toField(fieldRes);
      field.key = `field_${fieldRow.fields.length + 1}`;
      if (field.isRequired) {
        fieldRow.hasRequiredField = true;
      }
      fieldRow.fields.push(field);
    }
  });
  // sort fields by alpha numeric display name
  fieldRow.fields = _.orderBy(fieldRow.fields, (o) => o.display);
  return fieldRow;
};

const checkSectionHasRequiredField = (section: IConfigSection): boolean => {
  let hasRequiredField = false;
  if (section.fields.find((o) => o.isRequired)) {
    hasRequiredField = true;
  } else {
    hasRequiredField = checkFieldRowRequiredField(section.fieldRows);
  }
  return hasRequiredField;
};

const checkFieldRowRequiredField = (fieldRows: IConfigFieldRow[]): boolean => {
  let hasRequiredField = false;
  if (fieldRows.find((o) => o.hasRequiredField)) {
    hasRequiredField = true;
  } else {
    fieldRows.forEach((fieldRow) => {
      if (hasRequiredField === false) {
        hasRequiredField = checkFieldRowRequiredField(fieldRow.childRows);
      }
    });
  }
  return hasRequiredField;
};

const toField = (fieldRes: IFieldValueRes): IConfigField => {
  const field: IConfigField = {
    key: "",
    value: "",
    name: fieldRes.name,
    dataType: FieldTypes.Text,
    display: fieldRes.display,
    tooltip: "",
    isReadOnly: false,
    isRequired: fieldRes.isRequired,
    isNumeric: false,
    onChangeArguments: undefined,
    criteriaValueId: fieldRes.criteriaValueId,
    criteriaDefaultValueId: fieldRes.criteriaDefaultValueId,
    criteriaDefinitionId: fieldRes.criteriaDefinitionId,
    validators: fieldRes.defaultValue.validator
  };

  if (fieldRes.defaultValue && fieldRes.defaultValue.isActive === true) {
    field.value = readValue(fieldRes.defaultValue.value);
  }

  if (fieldRes.value !== null) {
    field.value = readValue(fieldRes.value);
  }

  // console.log(field);
  switch (fieldRes.datatype.toUpperCase()) {
    case "NUMBER":
      field.dataType = FieldTypes.Number;
      field.isNumeric = true;
      break;
    case "INTEGER":
      field.dataType = FieldTypes.Integer;
      field.isNumeric = true;
      break;
    case "POSITIVE_INTEGER":
      field.dataType = FieldTypes.PositiveInteger;
      field.isNumeric = true;
      break;
    case "PERCENT":
      field.dataType = FieldTypes.Percentage;
      field.isNumeric = true;
      break;
    case "EMAIL":
      field.dataType = FieldTypes.Email;
      break;
    case "NUMBER_RANGE":
      field.dataType = FieldTypes.NumberRange;
      field.isNumeric = true;
      break;
    case "PATTERN":
      break;
  }

  if (field.dataType === FieldTypes.Text) {
    field.hideIcon = true;
  }

  return field;
};
const readValue = (value: string): string => {
  let result = "";
  if (value) {
    try {
      result = JSON.parse(value);
    } catch {}
  }
  return result;
};

export interface ICriteriaValueRes {
  analysis: ICriteriaAnalysisRes;
}

interface ICriteriaAnalysisRes {
  criteria: IFieldValueRes[];
}

interface IFieldValueRes {
  name: string;
  display: string;
  isRequired: boolean;
  datatype: string;
  group: string[];
  groupHeader: string[];
  value: string;
  criteriaDefaultValueId: number;
  criteriaDefinitionId: number;
  criteriaValueId: number;
  defaultValue: ICriteriaDefaultValue;
}
interface ICriteriaDefaultValue {
  scope: string;
  value: string;
  isActive: boolean;
  validator: string;
}
