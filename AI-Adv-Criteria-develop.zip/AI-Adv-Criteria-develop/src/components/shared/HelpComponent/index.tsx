import React, { Component } from "react";
import { version } from "../../../../package.json";

interface IProps {}
interface IState {
  showMenu: boolean;
}

class HelpMenu extends Component<IProps, IState> {
  private helpDropdownMenuRef: undefined | HTMLDivElement;
  constructor(props) {
    super(props);
    this.state = {
      showMenu: false,
    };
  }

  public setDrawerRef = (drawer) => {
    this.helpDropdownMenuRef = drawer;
    if (this.helpDropdownMenuRef) {
      // add h-100 class to parent div (col)
      this.helpDropdownMenuRef.parentElement.parentElement.className +=
        " h-100";
    }
  };

  public componentWillMount() {
    document.addEventListener("click", this.handleOutsideClick, false);
  }

  public componentWillUnmount() {
    document.removeEventListener("click", this.handleOutsideClick, false);
  }

  public handleOutsideClick = (event) => {
    if (
      this.helpDropdownMenuRef &&
      !this.helpDropdownMenuRef.contains(event.target)
    ) {
      this.setState({ showMenu: false });
    }
  };

  public showMenu = () => {
    this.setState({ showMenu: !this.state.showMenu });
  };

  public render() {
    const { showMenu } = this.state;
    return (
      <div
        ref={this.setDrawerRef}
        className="float-right nav-help-icon-bar d-inline-block h-100 breeding-nav-icon-bar"
      >
        <div className="align-items-center col d-flex p-0  h-100 w-100">
          <div className="dropdown breeding-nav-user-icon-menu h-100 w-100">
            <button
              className="btn dropdown-toggle h-100 w-100"
              type="button"
              onClick={this.showMenu}
            >
              <div className="breeding-nav-notification-icon">
                <i className="material-icons md-24 ">help</i>
              </div>
            </button>
            <div
              className={`dropdown-menu dropdown-menu-right m-0 breeding-nav-notification-menu ${
                showMenu ? "show" : "hide"
              }`}
              aria-labelledby="iconmenu-dropdownMenuButton"
            >
              <div className="d-flex dropdown-item breeding-nav-notification-dropdown-item app-version-info">
                Advancement Criteria: Version {version}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default HelpMenu;
