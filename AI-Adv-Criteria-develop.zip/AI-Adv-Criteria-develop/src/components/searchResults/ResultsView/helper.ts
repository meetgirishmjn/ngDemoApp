import {
  IQueryAdvConfigResponse,
  IConfigDataRequistion,
  IRequisition,
  IRequisitionItem,
  ITraitsData,
  ITraitAndCalc,
  IAdvConfigSubset,
  IFulfillment,
} from "../../../models/IAdvConfig";
import { each, some, find, filter } from "lodash";
import { ITabData, IResultData, IRunKey, IKey, IAnalysisData } from "../../../models/IResults";
import {
  getBlupsData,
  getRunId
} from "../../../actions/results/advanceActions";
import { ITabType } from "../Tabs/Results";
import {
  IValue
} from "../../../models/IResults";
import { filterSubsetsUsingPipeline, parseJsonValue } from "../Tabs/EngineConfigTab/helper";
import { IAnalysisSubType } from "../../../models/ISearchAnalyses";
import { advConfigQuery } from "../../../actions/advConfigDb/advConfigQuery";
import { getAllAnalysisSubTypes } from "../../../actions/pac/pacActions";

export interface IColumnsAndFulfillments {
  columnnames: string[],
  fulfillments: IFulfillment[],
  analysisSubTypeName: string
}

export interface IDataByPrescsAndBlups {
  advanceData: any[],
  dropData: any[],
  noMatchData: any[]
}

export const getColumnsAndFulfillments = async (selectedParams: IPipeline, analysisTypeNames: string[]) => {
  const response = await advConfigQuery(
    selectedParams.Crop.value,
    selectedParams.Region.key,
    selectedParams.HarvestType.key,
    selectedParams.Year,
    selectedParams.Market.key
  );
  const analysisSubTypes: IAnalysisSubType[] = await getAllAnalysisSubTypes();
  const columnsAndFulfillments: IColumnsAndFulfillments[] = parseAdvConfigData(
    response.data,
    selectedParams,
    analysisSubTypes,
    analysisTypeNames
  );
  return columnsAndFulfillments;
}

export const loadBlupsDataByFulfillments = async (columnsAndFulfillments: IColumnsAndFulfillments[], dataByPrescsAndBlups: IDataByPrescsAndBlups) => {
  columnsAndFulfillments.forEach(async (item: IColumnsAndFulfillments) => {
    if (item.fulfillments && item.fulfillments.length > 0) {
      dataByPrescsAndBlups = await filterDataByBlups(item.columnnames, dataByPrescsAndBlups, item.fulfillments[0].externalId, item.analysisSubTypeName);
    }
  });
  return dataByPrescsAndBlups;
}

export const parseAdvConfigData = (
  advConfig: IQueryAdvConfigResponse,
  selectedParams: IPipeline,
  analysisSubTypes: IAnalysisSubType[],
  analysisTypeNames: string[]
) => {
  let filteredSubsets: IAdvConfigSubset[] = [];
  let columnsAndFulfillments: IColumnsAndFulfillments[] = [];
  filteredSubsets = filterSubsetsUsingPipeline(advConfig, selectedParams);
  try {
    // find configDataRequisitions by the advConfigSubset Id's
    const filteredConfigDataReq: IConfigDataRequistion[] = advConfig.configDataRequisitions.filter(
      (dataRequistion: IConfigDataRequistion) => {
        return filteredSubsets.find(
          ({ id }) => id === dataRequistion.advConfigSubset.id
        );
      }
    ) as IConfigDataRequistion[];
    const gxeAnalysisSubType: IAnalysisSubType = find(analysisSubTypes, (subType: IAnalysisSubType) => subType.name === "GXEBLUP");
    analysisTypeNames.forEach((typeName: string) => {
      filteredConfigDataReq.forEach((configDataReq: IConfigDataRequistion) => {
        // filter requistions by blups
        const reqsFilteredByBlups = filter(configDataReq.requistions, (requisition: IRequisition) => {
          const isBlupExists = some(
            requisition.requisitionItems,
            (item: IRequisitionItem) => {
              let dataProviderValue = parseJsonValue(item.value);
              dataProviderValue = typeof dataProviderValue === 'string' && dataProviderValue.toLowerCase();
              return (
                // to find blup
                item.dataProviderAttributeName === "analysisTypeName" &&
                dataProviderValue === typeName.toLowerCase()
              );
            }
          );
          return isBlupExists;
        });
        // filter out the gxeblups using analysisSubTypeId GXEBLUP
        const reqsFilteredByOnlyBlups: IRequisition[] = gxeAnalysisSubType ? filter(reqsFilteredByBlups, (requisition: IRequisition) => {
          const isBlupExists = some(
            requisition.requisitionItems,
            (item: IRequisitionItem) => {
              let dataProviderValue = parseJsonValue(item.value);
              dataProviderValue = typeof dataProviderValue === 'string' ? dataProviderValue.toLowerCase() : dataProviderValue.toString();
              return (
                // avoid gblup
                item.dataProviderAttributeName === "analysisSubTypeId" &&
                dataProviderValue !== gxeAnalysisSubType.id.toString()
              );
            }
          );
          return isBlupExists;
        }) : reqsFilteredByBlups;
        each(reqsFilteredByOnlyBlups, (requisition: IRequisition) => {
          const analysisSubTypeItem = find(
            requisition.requisitionItems,
            (item: IRequisitionItem) =>
              item.dataProviderAttributeName === "analysisSubTypeId"
          );
          const item: IRequisitionItem = find(
            requisition.requisitionItems,
            (item: IRequisitionItem) =>
              item.dataProviderAttributeName === "traitsCalcsDefineDataUI"
          );
          const analysisSubType: IAnalysisSubType = find(analysisSubTypes, (subType: IAnalysisSubType) => subType.id === analysisSubTypeItem.value);
          const traitsCalcsDefineDataUI: ITraitsData = JSON.parse(
            item.value
          ) as ITraitsData;
          columnsAndFulfillments.push({
            fulfillments: requisition.fulfillments,
            columnnames: parseValue(traitsCalcsDefineDataUI),
            analysisSubTypeName: analysisSubType.name
          })
        })
      });
    });
  }
  catch (err) {
    console.log(err);
  }
  columnsAndFulfillments = filter(columnsAndFulfillments, (columnAndFulfillment: IColumnsAndFulfillments) => columnAndFulfillment.columnnames.length > 0)
  return columnsAndFulfillments;
};

const parseKey = (key: IKey[], type: ITabType) => {
  const data: ITabData[] = [];
  each(key, (obj: IKey) => {
    data.push({
      decision: type.toString(),
      lineName: obj.value,
      // ruleGroup: "Rule Group", // Not required for MVP, remove comment when required.
    });
  });
  return data;
};

export const filterDataByPrescs = (columnData: IResultData, dataByPrescsAndBlups: any) => {
  each(columnData.data.run.keys, (runKey: IRunKey) => {
    each(runKey.values, (value: IValue) => {
      switch ((value.strvalue && value.strvalue.toLowerCase()) || value.numvalue) {
        case 0:
        case "drop":
        case "rejected":
          dataByPrescsAndBlups.dropData = dataByPrescsAndBlups.dropData.concat(
            parseKey(runKey.key, ITabType.Drop)
          );
          break;
        case 1:
        case "recommended":
        case "auto-advance":
          dataByPrescsAndBlups.advanceData = dataByPrescsAndBlups.advanceData.concat(
            parseKey(runKey.key, ITabType.Advance)
          );
          break;
        default:
          dataByPrescsAndBlups.noMatchData = dataByPrescsAndBlups.noMatchData.concat(
            parseKey(runKey.key, ITabType.NoMatch)
          );
          break;
      }
    });
  });
  return dataByPrescsAndBlups;
}

/*
  Get advance, drop and no match data
*/
export const filterDataByBlups = async (columnNames: string[], dataByPrescsAndBlups: any, analysisId: number, analysisSubTypeName?: string) => {
  const analysisData: IAnalysisData = await getRunId(analysisId.toString(), 1);
  if (
    analysisData &&
    analysisData.analysis &&
    analysisData.analysis.lastSuccessfulRun.id &&
    analysisData.analysis.lastSuccessfulRun.isFinished
  ) {
    const runId: number = parseInt(
      analysisData.analysis.lastSuccessfulRun.id,
      10
    );
    const blupsData = await getBlupsData(runId, columnNames);
    dataByPrescsAndBlups.advanceData = parseBlupDataIntoPresc(dataByPrescsAndBlups.advanceData, blupsData, columnNames, analysisSubTypeName);
    dataByPrescsAndBlups.dropData = parseBlupDataIntoPresc(dataByPrescsAndBlups.dropData, blupsData, columnNames, analysisSubTypeName);
    dataByPrescsAndBlups.noMatchData = parseBlupDataIntoPresc(dataByPrescsAndBlups.noMatchData, blupsData, columnNames, analysisSubTypeName);
  }
  return dataByPrescsAndBlups;
};

export const parseValue = (traitsCalcsDefineDataUI: ITraitsData) => {
  const columnNames: string[] = [];
  each(traitsCalcsDefineDataUI.traits, (traitAndCalc: ITraitAndCalc) => {
    traitAndCalc.trait && traitAndCalc.calc && columnNames.push(`${traitAndCalc.trait.name}_${traitAndCalc.calc.name}`);
  });
  return columnNames;
};

export const parseBlupDataIntoPresc = (
  allPrescriptions: ITabData[],
  blupData: any,
  columnNames: string[],
  analysisSubTypeName?: string
) => {
  each(columnNames, (colName: string) => {
    each(allPrescriptions, (presc: ITabData, index: number) => {
      if (!analysisSubTypeName) {
        presc[colName] =
          blupData && blupData[colName] && getValue(presc, blupData[colName]);
      } else {
        presc[`${colName}(${analysisSubTypeName})`] = blupData && blupData[colName] && getValue(presc, blupData[colName]);
      }
    });
  });
  return allPrescriptions;
};

export const getValue = (presc: ITabData, blupData: IResultData) => {
  let value: string = "";
  each(blupData.data.run.keys, (runKey: IRunKey) => {
    const isLineName = some(
      runKey.key,
      (key: IKey) => key.name === "LINE_NAME" && key.value.includes(presc.lineName)
    );
    if (isLineName) {
      value = runKey.values[0].numvalue.toString();
      return;
    }
  });
  return value;
};


export const getPipelineName = (pipeline: IPipeline) => {
  const {
    Crop,
    Region,
    Year,
    HarvestType,
    Market,
    SubMarket,
    ProductStage,
    Trait,
  } = pipeline;
  const name = `${Crop.value}_${Year}_${Region.value}_${HarvestType.value}_${Market.value}_${SubMarket.value}_${ProductStage.value}_${Trait.value}`;
  return name.replace(/\s/g, "_");
};
