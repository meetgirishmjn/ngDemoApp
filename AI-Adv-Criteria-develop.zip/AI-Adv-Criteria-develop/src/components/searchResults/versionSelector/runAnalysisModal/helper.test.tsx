import React from "react";
import {
  getCheckType,
  parseOperator,
  getModelName,
  createRunJsonModal,
} from "./helper";
import IRunAnalysisProps from "./IRunAnalysisProps";
import MockAdapter from "axios-mock-adapter";
import pacApi from "../../../../api/pacApi";
import { IEvaRunModel } from "../../../../models/Eva-models";
import Constants from "../../../../shared/constants";

const sampleSelectedParams = {
  Crop: { id: 65601536, key: "CORN", value: "Corn", cropId: 65601536 },
  Year: "2020",
  Region: { id: 100004, key: "SAF", value: "SAF" },
  HarvestType: { id: 81985536, key: "G", value: "Grain" },
  Market: { id: 32536, key: "WHITE", value: "WHITE" },
  SubMarket: { id: -1, key: "", value: Constants.ALL_SUBMARKETS },
  StageType: { key: "PCM", value: "PCM" },
  ProductStage: { key: "10003", value: "PS1" },
  Trait: { key: "-1", value: "All Traits" },
  DecisionEngine: { key: "EVA-0.1.23", value: "EVA-0.1.23" },
};

const sampleTemplate = {
  sections: [
    {
      key: "section_2",
      title: "Required",
      tooltip: "",
      hasRequiredField: true,
      fields: [
        {
          key: "field_2",
          value: "1.2x",
          name: "bench_size",
          dataType: 4,
          display: "Bench Size",
          tooltip: "",
          isReadOnly: false,
          isRequired: true,
          isNumeric: false,
          criteriaValueId: null,
          criteriaDefaultValueId: 8,
          criteriaDefinitionId: 30,
          hideIcon: true,
          validators: ""
        },
        {
          key: "field_1",
          value: "100",
          name: "num_of_lines_to_select",
          dataType: 4,
          display: "Number of Lines",
          tooltip: "",
          isReadOnly: false,
          isRequired: true,
          isNumeric: false,
          criteriaValueId: null,
          criteriaDefaultValueId: 5,
          criteriaDefinitionId: 5,
          hideIcon: true,
        },
      ],
      fieldRows: [
        {
          title: "Gender Balance",
          key: "Required_Gender Balance1",
          tooltip: "",
          fields: [
            {
              key: "field_2",
              value: "50",
              name: "female",
              dataType: 4,
              display: "% Female",
              tooltip: "",
              isReadOnly: false,
              isRequired: true,
              isNumeric: false,
              criteriaValueId: null,
              criteriaDefaultValueId: 4,
              criteriaDefinitionId: 26,
              hideIcon: true,
            },
            {
              key: "field_1",
              value: "50",
              name: "male",
              dataType: 4,
              display: "% Male",
              tooltip: "",
              isReadOnly: false,
              isRequired: true,
              isNumeric: false,
              criteriaValueId: null,
              criteriaDefaultValueId: 3,
              criteriaDefinitionId: 17,
              hideIcon: true,
            },
          ],
          childRows: [],
          hasRequiredField: true,
        },
      ],
    },
  ],
};

describe("Test createJsonModalhelpers", () => {
  it("test operator parser", () => {
    let operator = parseOperator("equal");
    expect(operator).toBe("equal_to");
    operator = parseOperator("Greater Than");
    expect(operator).toBe("greater_than");
    operator = parseOperator("Less Than");
    expect(operator).toBe("less_than");
  });

  it("test checktype", () => {
    let checkType = getCheckType("Compare Against Check", "Performance");
    expect(checkType).toBe("Performance");
    checkType = getCheckType("compare against line", "");
    expect(checkType).toBe("LINE");
  });

  it("test generated model name", () => {
    let modelName = getModelName("ps1");
    expect(modelName.toLowerCase()).toBe("inbred eva");
    modelName = getModelName("ps2.5".toLowerCase());
    expect(modelName.toLowerCase()).toBe("playbook");
  });

  // it("test json modal", async () => {
  //     const props: IRunAnalysisProps = {
  //         showModalDialog: true,
  //         horizonServices: {},
  //         onModalHide: () => { },
  //         selectedParams: sampleSelectedParams,
  //         selectedVersion: {
  //             uid: "11241_UAT-Test-2020-CORN_WHITE_3",
  //             analyseId: "11241",
  //             name: "UAT-Test-2020-CORN_WHITE",
  //             version: 3,
  //             versionDesc: "UAT-Test-2020-CORN_WHITE_v3",
  //             isLocked: false,
  //             isInProgress: false,
  //             runs:[]
  //         },
  //         template: sampleTemplate,
  //         userId: "eslank",
  //         onAnalysisRunSuccess: () => { }
  //     };
  //   const mock = new MockAdapter(pacApi);
  //   mock.onPost("/graphql").reply(200, {
  //     data: {
  //       analysis: {
  //         id: "11111",
  //         version: "1",
  //         rules: [
  //           {
  //             name: "auto advance",
  //             rules: [
  //               {
  //                 value: 90,
  //                 gender: "Female",
  //                 ruleId: 2,
  //                 category: "BLUP",
  //                 dataType: "",
  //                 lineName: "",
  //                 maxValue: "",
  //                 minValue: "",
  //                 operator: "equal",
  //                 checkType: "",
  //                 ruleLevel: "Strict",
  //                 valueType: "Absolute Value",
  //                 categoryType: "BLUP_GCA",
  //                 displayValue: 90,
  //                 distribution: "",
  //                 operatorNotation: "=",
  //                 traitOrAttribute: "AGSPP",
  //                 distributionNotation: "",
  //                 traitOrAttributeDataType: "float",
  //                 traitOrAttributeDisplayName: "AGSPP",
  //               },
  //               {
  //                 value: 30,
  //                 gender: "Male",
  //                 ruleId: 3,
  //                 category: "BLUP",
  //                 dataType: "",
  //                 lineName: "",
  //                 maxValue: "",
  //                 minValue: "",
  //                 operator: "equal",
  //                 checkType: "",
  //                 ruleLevel: "Strict",
  //                 valueType: "Compare Against Cohort",
  //                 categoryType: "GBLUP",
  //                 displayValue: 30,
  //                 distribution: "",
  //                 operatorNotation: "=",
  //                 traitOrAttribute: "MST_BE",
  //                 distributionNotation: "",
  //                 traitOrAttributeDataType: "float",
  //                 traitOrAttributeDisplayName: "MST_BE",
  //               },
  //             ],
  //             decision: "Advance",
  //             ruleGroupId: 2,
  //           },
  //           {
  //             name: "auto drop",
  //             rules: [
  //               {
  //                 value: 110,
  //                 gender: "All Genders",
  //                 ruleId: 4,
  //                 category: "Portfolio",
  //                 dataType: "BLUP",
  //                 lineName: "HINI403+LOQA046",
  //                 maxValue: "",
  //                 minValue: "",
  //                 operator: "equal",
  //                 checkType: "",
  //                 ruleLevel: "Strict",
  //                 valueType: "Compare Against Line",
  //                 distroPerc: 30,
  //                 categoryType: "HBLUP",
  //                 displayValue: 110,
  //                 distribution: "Greater Than",
  //                 operatorNotation: "=",
  //                 traitOrAttribute: "AGSPP",
  //                 distributionNotation: ">",
  //                 traitOrAttributeDataType: "float",
  //                 traitOrAttributeDisplayName: "AGSPP",
  //               },
  //             ],
  //             decision: "Drop",
  //             ruleGroupId: 3,
  //           },
  //           {
  //             name: "maybe drop",
  //             rules: [
  //               {
  //                 value: "D",
  //                 gender: "All Genders",
  //                 ruleId: 1,
  //                 category: "Attributes",
  //                 dataType: "",
  //                 lineName: "",
  //                 maxValue: "",
  //                 minValue: "",
  //                 operator: "equal",
  //                 checkType: "",
  //                 ruleLevel: "Strict",
  //                 valueType: "",
  //                 categoryType: "ATTRIBUTE NAME",
  //                 displayValue: "D",
  //                 distribution: "",
  //                 operatorNotation: "=",
  //                 traitOrAttribute: 2087,
  //                 distributionNotation: "",
  //                 traitOrAttributeDataType: "string",
  //                 traitOrAttributeDisplayName: "COGS RANKING",
  //               },
  //             ],
  //             decision: "Drop",
  //             ruleGroupId: 4,
  //           },
  //           {
  //             name: "Adv Again",
  //             rules: [
  //               {
  //                 value: 10,
  //                 gender: "All Genders",
  //                 ruleId: 5,
  //                 category: "PREDICTION",
  //                 dataType: "",
  //                 lineName: "HINI403+LOQA046",
  //                 maxValue: "",
  //                 minValue: "",
  //                 operator: "equal",
  //                 checkType: "",
  //                 ruleLevel: "Strict",
  //                 valueType: "Compare Against Line",
  //                 categoryType: "STGLSS_PRED",
  //                 displayValue: 10,
  //                 distribution: "",
  //                 operatorNotation: "=",
  //                 traitOrAttribute: "BIN",
  //                 distributionNotation: "",
  //                 traitOrAttributeDataType: "float",
  //                 traitOrAttributeDisplayName: "BIN",
  //               },
  //             ],
  //             decision: "Advance",
  //             ruleGroupId: 5,
  //           },
  //         ],
  //         analyticModelVersionId: 65,
  //         analysisSubTypeId: 58,
  //       },
  //     },
  //   });
  //   const jsonModal: IEvaRunModel = await createRunJsonModal(props.selectedParams,props.selectedVersion,props.template,props.userId);
  //   expect(jsonModal.reportName).toBe("AdvProd_InbredEVA_Corn_SAF_WHITE_PS1_2020_Grain_All_subMarket");
  //   expect(jsonModal.configurations.model.toLowerCase()).toBe("inbred eva");
  //   expect(jsonModal.configurations.Required).not.toBeNull();
  //   expect(jsonModal.configurations.Required.rules.length).toBeGreaterThan(0);
  //   expect(jsonModal.configurations.Required.constraints.length).toBeGreaterThan(0);
  //   expect(jsonModal.configurations.Required.comparables.length).toBeGreaterThan(0);
  // });
});
