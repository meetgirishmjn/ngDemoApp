interface IStringKvp extends IKvp<string, string> {}
