import React, { Component } from "react";
import { connect } from "react-redux";
import _ from "lodash";
import { Tab, TabsContainer } from "@monsantoit/ui-react-tabs";
import "./searchResults.scss";
import ISearchResultsProps, { ITabItem } from "./SearchResultsProps";
import ISearchResultsState, {
  ISearchResultsCache,
  ViewTypes,
  IGraphTabCache
} from "./SearchResultsState";
import VersionSelector from "./versionSelector";
import EngineConfigTab from "./Tabs/EngineConfigTab";
import PipelineEditedSubHeader from "../shared/PipelineEditedSubHeader/PipelineEditedSubHeader";
import {
  getUserPreferences,
  saveToVelocityCache,
  getFromVelocityCache,
} from "../../actions/userPreferences/userPreferencesActions";
import {
  IConfigurationTemplate,
  IModelVersion,
  IVersionHistoryInfo,
} from "../../actions/criteria/models";
import {
  getConfigTemplate,
  updateVersionHistoryComments,
  getModelVersions,
} from "../../actions/criteria/criteriaActions";
import { deleteBlupsData } from "../../actions/pac/pacActions";
import IRootStore from "../../store/IRootStore";
import Spinner from "../../common/spinner";
import RuleGroupsTab from "./Tabs/RuleGroupsTab";
import VersionHistoryTab from "./Tabs/VersionHistoryTab";
import GraphsTab from "./Tabs/GraphsTab";
import { IRuleGroup, ICurrentState } from "@monsantoit/ui-react-ap-rules/dist/CriteriaCreation/ICriteriaCreationProps";
import ResultsView from "./ResultsView";
import { IEntitlements } from "../../models/IEntitlementGroups";
import Constants from "../../shared/constants";

const SEARCHRESULTS_CACHE_KEY = "searchResults";
const GRAPHSTAB_CACHE_KEY = "GraphsTab";

class SearchResults extends Component<
  ISearchResultsProps,
  ISearchResultsState
> {
  public static getDerivedStateFromProps(
    nextProps: ISearchResultsProps,
    prevState: ISearchResultsState
  ) {
    if (!_.isEqual(nextProps.selectedParams, prevState.selectedParams)) {
      return {
        selectedParams: nextProps.selectedParams
          ? nextProps.selectedParams
          : prevState.selectedParams,
      };
    }

    if (!_.isEqual(nextProps.analysisInRun, prevState.analysisInRun)) {
      return { analysisInRun: nextProps.analysisInRun };
    }

    return null;
  }

  public velocityCache: ISearchResultsCache = null;
  public velocityCacheGraphTab: IGraphTabCache = null;

  public readonly Tabs: ITabItem[] = [
    { name: "Graphs", title: "Graphs" },
    { name: "ModelType", title: "" }, // dynamic title
    { name: "RuleGroups", title: "Rule Groups" },
    { name: "VersionHistory", title: "Version History" },
  ];

  constructor(props: ISearchResultsProps) {
    super(props);
    this.state = {
      ViewType: ViewTypes.Default,
      selectedTab: this.Tabs[0].name,
      configTemplate: null,
      isTemplateLoading: true,
      configTemplateError: "",
      selectedParams: null,
      VersionHistoryData: null,
      isVersionHistoryLoading: false,
      ruleGroups: [],
      modelVersions: [],
      selectedVersion: null,
      isVersionDataLoading: true,
      HasEntitlements: null,
    };
  }

  public componentDidMount() {
    const { selectedParams, getUserPreferences, horizonServices } = this.props;
    if (!selectedParams) {
      getUserPreferences(horizonServices);
    } else {
      // if there's a selected params already, update state
      this.setState({ selectedParams });
      this.onUserPreferencesLoaded();
      this.checkForEntitlements();
    }
  }

  public componentDidUpdate(prevProps, prevState) {
    if (!_.isEqual(prevState.selectedParams, this.state.selectedParams)) {
      this.onUserPreferencesLoaded();
      this.checkForEntitlements();
    }

    //if analysis run button click is successful
    if (!_.isEqual(prevState.analysisInRun, this.state.analysisInRun)) {
      let modelVersions: IModelVersion[] = [];

      this.state.modelVersions.forEach((o) => {
        let clonedAnalysis = _.cloneDeep(o);
        if (o.uid === this.state.analysisInRun.uid) {
          clonedAnalysis.isInProgress = true;
        }
        modelVersions.push(clonedAnalysis);
      });

      this.setState({
        modelVersions: modelVersions,
        selectedVersion: modelVersions.find(
          (o) => o.uid === this.state.selectedVersion.uid
        ),
      });
    }
    // clear graph data in redux when pipeline or version changes
    if (
      !_.isEqual(prevState.selectedParams, this.state.selectedParams) ||
      !_.isEqual(prevState.selectedVersion, this.state.selectedVersion)
    ) {
      this.props.deleteBlupsData();
    }
  }

  public onUserPreferencesLoaded = async () => {
    // load SearchResults view specific user preferences
    this.velocityCache = await getFromVelocityCache<ISearchResultsCache>(
      this.props.userId,
      SEARCHRESULTS_CACHE_KEY
    );

      this.velocityCacheGraphTab = await getFromVelocityCache<IGraphTabCache>(
        this.props.userId,
        `${this.getPipelineName(this.props.selectedParams)}_${GRAPHSTAB_CACHE_KEY}`
    );

    this.setState({
      isVersionDataLoading: true,
      selectedTabModelType: this.state.selectedParams.DecisionEngine,
    });

    this.loadModelVersions();

    if (this.velocityCache) {
      // set state from v-cache
      this.setState({
        selectedTab: this.velocityCache.selectedTab || this.state.selectedTab,
      });
    }
  };

  public loadModelVersions = async () => {
    this.setState({
      isVersionDataLoading: true,
    });

    let versions: IModelVersion[] = [];

    const {
      Crop,
      Year,
      HarvestType,
      Region,
      Market,
    } = this.props.selectedParams;

    try {
      versions = await getModelVersions(
        Crop.value,
        +Year,
        Region.key,
        HarvestType.key,
        Market.key
      );
    } catch (ex) {
      console.log("Failed to load model-versions", ex);
      console.log(ex);
    }

    let selectedVersion: IModelVersion = null;

    if (versions.length !== 0) {
      selectedVersion = versions[0];

      const match = versions.find(
        (o) => o.uid === this.getVelocityCache().selectedVersion
      );
      if (match) {
        selectedVersion = match || selectedVersion;
      }
    }

    this.setState({
      modelVersions: versions,
      isVersionDataLoading: false,
    });

    this.onVersionSelectionChanged(selectedVersion);
  };

  public loadConfigTemplate = async (analysisId: string, version: number) => {
    let template: IConfigurationTemplate = null;
    let templateError = "";
    this.setState({ configTemplate: template, isTemplateLoading: true });
    try {
      template = await getConfigTemplate(analysisId, version);
      if (!template.sections.length) {
        templateError =
          "Criteria definition not found for selected Analysis Version";
      }
    } catch (ex) {
      templateError = "Failed to load config-template";
      console.log(templateError, ex);
      console.log(ex);
    }

    this.setState({
      configTemplate: template,
      configTemplateError: templateError,
      isTemplateLoading: false,
    });
  };

    public getVelocityCache() {
        let vCache = this.velocityCache;
        if (!vCache) {
            vCache = {
                selectedVersion: "",
                selectedTab: "",
                selectedRunIdHash: {}
            };
        }

        vCache.selectedRunIdHash = vCache.selectedRunIdHash || {};

        return vCache;
    }

    public getVCacheGraphTab() {
        let vCache = this.velocityCacheGraphTab;
        if (!vCache) {
            vCache = {
                histogramSelectionHash: {},
                scatterSelectionHash: {}
            }
        }
        if (!vCache.histogramSelectionHash) {
            vCache.histogramSelectionHash = { };
        }
        if (!vCache.scatterSelectionHash) {
            vCache.scatterSelectionHash = {};
        }
        return vCache;
    }

    public findLatestRunId = (version: IModelVersion): number | null => {
        let rundId: number | null = null;
        if (version) {
            let runs = (version.runs || []).filter(o => o.currentStatus === "SUCCESS");
            runs = _.orderBy(runs, (o) => o.id, "desc");
            if (runs.length) {
                rundId = runs[0].id;
            }
        }
        return rundId;
    }

  public paramsChanged = (params: IPipeline) => {
    // selections are changed, reload all dependent components or use redux props which reload automatically
  };

  public onEditCriteria = async () => {
    this.setState({ ViewType: ViewTypes.Default });
  };

  public onTabChanged = async (value: string, event: any) => {
    this.setState({ selectedTab: value });
    const vCache = this.getVelocityCache();
    vCache.selectedTab = value;
    saveToVelocityCache(this.props.userId, SEARCHRESULTS_CACHE_KEY, vCache);
    /* if (value === "VersionHistory") {
      // if data not loaded
      if (!this.state.VersionHistoryData) {
        this.setState({ isVersionHistoryLoading: true });
        const data = await getVersionHistoryData(this.state.selectedAnalyseId);
        this.setState({
          isVersionHistoryLoading: false,
          VersionHistoryData: data
        });
      }
    } */
  };

    public onVersionSelectionChanged = async (item: IModelVersion) => {
        const vCache = this.getVelocityCache();
        if (
            this.state.selectedVersion &&
            this.state.selectedVersion.uid === item.uid
        ) {
            return;
        }
        if (item && vCache.selectedVersion !== item.uid) {
            vCache.selectedVersion = item.uid;
            saveToVelocityCache(this.props.userId, SEARCHRESULTS_CACHE_KEY, vCache);
        }

        if (item) {

            let runId = vCache.selectedRunIdHash[item.uid];
            if (!runId) {
                runId = this.findLatestRunId(item);
            }

            this.setState({
                ViewType: ViewTypes.Default,
                selectedAnalyseId: item.analyseId,
                selectedVersion: item,
                selectedRunId: runId
            });
            this.loadConfigTemplate(item.analyseId, item.version);
        } else {
            const modelType = this.state.selectedTabModelType
                ? this.state.selectedTabModelType.value
                : "";

            this.setState({
                configTemplate: {
                    sections: [],
                },
                configTemplateError: `Please select Analysis model version to load ${modelType} definition`,
                isTemplateLoading: false,
                ViewType: ViewTypes.Default,
                selectedVersion: item,
                selectedRunId: null
            });
        }
        console.log(this.state.selectedVersion);
    };

  public onVersionCreated = async (newVersion: IModelVersion) => {
    const versions = [...this.state.modelVersions, newVersion];
    this.setState({
      modelVersions: versions,
    });
    this.onVersionSelectionChanged(newVersion);
  };

    public onVersionRunIdSelectionChanged = async (version: IModelVersion, runId: number | undefined) => {
        this.setState({ selectedRunId: runId });
        const vCache = this.getVelocityCache();
        vCache.selectedRunIdHash[version.uid] = runId;
        saveToVelocityCache(this.props.userId, SEARCHRESULTS_CACHE_KEY, vCache);
    }

  public onViewResultsClick = async () => {
    this.setState({ ViewType: ViewTypes.ViewResults });
  };

  public onHistoryCellValueChanged = async (
    item: IVersionHistoryInfo,
    newValue: string
  ) => {
    const flag = await updateVersionHistoryComments("", "", "");
    const { horizonServices } = this.props;
    if (flag === true) {
      horizonServices.toast.success("Comments updated.");
    } else {
      horizonServices.toast.error("failed to update comments");
    }
  };

    private getPipelineName = (pipeline: IPipeline) => {
        const {
            Crop,
            Region,
            Year,
            HarvestType,
            Market,
            SubMarket,
            ProductStage,
            StageType,
            DecisionEngine,
        } = pipeline;
        const name = `${Crop.value}_${Year}_${Region.value}_${HarvestType.value}_${Market.value}_${SubMarket.value}_${ProductStage.value}_${StageType.value}_${DecisionEngine.value}`;
        return name.replace(/\s/g, "_");
    }

    public onGraphTabTraitSelectionChange = (graphType: string, keyTrait: string, traits: string[]) => {

        if (!traits.length)
            return;

        let vCache = this.getVCacheGraphTab();
       
        switch (graphType) {
            case 'Histogram':
                vCache.histogramSelectionHash[keyTrait] = traits[0];
                break;
            case 'Scatter':
                vCache.scatterSelectionHash[keyTrait] = [traits[0], traits[1]];
                break;
        }

        saveToVelocityCache(this.props.userId, `${this.getPipelineName(this.props.selectedParams)}_${GRAPHSTAB_CACHE_KEY}`, vCache).then((saveFlag) => {
            if (!saveFlag) {
                this.props.horizonServices.toast.warning("Failed to save trait selection.");
            }
        });
    }

  //RuleGroupsTab events
  public onRuleGroupsModified = (ruleGroups: IRuleGroup[]) => {
    console.log(ruleGroups);
    this.setState({ ruleGroups });
    };

    public onRuleGroupsStateModified = (componentState: ICurrentState) => {
        console.log(componentState);
        this.setState({ ruleGroupsComponentState: componentState });
    };
  //-------------

    public renderGraphTab = () => {
        return (
            <Tab key="Graphs" name={this.Tabs[0].name} title={this.Tabs[0].title}>
                {this.state.selectedVersion && (
                    <GraphsTab
                        key="graphTab"
                        userId={this.props.userId}
                        selectedParams={this.props.selectedParams}
                        horizonServices={this.props.horizonServices}
                        selectedVersion={this.state.selectedVersion}
                        onTraitSelectionChange={this.onGraphTabTraitSelectionChange}
                        velocityCache={this.velocityCacheGraphTab}
                        selectedRunId={this.state.selectedRunId}
                    />
                )}
            </Tab>
        );
    };

  public renderModalTab = () => {
    const { horizonServices } = this.props;
    const isConfigTemplateError =
      (this.state.configTemplateError || "").length > 0;

    let isEditable = true;
    if (
      this.state.selectedVersion &&
      (this.state.selectedVersion.isLocked === true ||
        this.state.selectedVersion.isInProgress === true ||
        this.state.HasEntitlements === false)
    ) {
      isEditable = false;
    }
    return (
      <Tab
        key="ModelType"
        name={this.Tabs[1].name}
        title={
          this.state.selectedTabModelType
            ? this.state.selectedTabModelType.value
            : ""
        }
      >
        <>
          {this.state.isTemplateLoading && (
            <div className="loading-div">
              <span
                className="spinner-grow spinner-grow-sm"
                role="status"
                aria-hidden="true"
              />
              Loading...
            </div>
          )}
          {!this.state.isTemplateLoading && isConfigTemplateError && (
            <div className="mt-24">
              {horizonServices.alert.warning(this.state.configTemplateError)}
            </div>
          )}
          {!this.state.isTemplateLoading && this.state.configTemplate && (
            <EngineConfigTab
              template={this.state.configTemplate}
              isEditable={isEditable}
              analysisId={this.state.selectedVersion.analyseId}
              analysisVersion={this.state.selectedVersion.version}
              horizonServices={this.props.horizonServices}
            />
          )}
        </>
      </Tab>
    );
  };

  public renderRuleGroupsTab = () => {
    const { selectedParams, HasEntitlements } = this.state;
    let ruleGroupTitle = this.Tabs[2].title;
    if (this.state.ruleGroups) {
      ruleGroupTitle += ` (${this.state.ruleGroups.length})`;
    }
    return (
      <Tab key="RuleGroups" name={this.Tabs[2].name} title={ruleGroupTitle}>
        {this.state.selectedVersion && (
          <RuleGroupsTab
            horizonServices={this.props.horizonServices}
            selectedParams={selectedParams}
            onRuleGroupsModified={this.onRuleGroupsModified}
            onStateModified={this.onRuleGroupsStateModified}
            selectedVersion={this.state.selectedVersion}
            hasEntitlements={HasEntitlements}
            componentState={this.state.ruleGroupsComponentState || undefined}
          />
        )}
      </Tab>
    );
  };

  public renderVersionHistoryTab = () => {
    const { HasEntitlements } = this.state;
    let VersionHistoryTitle = this.Tabs[3].title;

    if (this.state.VersionHistoryData) {
      VersionHistoryTitle += ` (${this.state.VersionHistoryData.length})`;
    }
    return (
      <Tab
        key="VersionHistory"
        name={this.Tabs[3].name}
        title={VersionHistoryTitle}
      >
        <VersionHistoryTab
          analysesId={this.state.selectedAnalyseId}
          selectedVersion={this.state.selectedVersion}
          onCellValueChanged={this.onHistoryCellValueChanged}
          horizonServices={this.props.horizonServices}
          hasEntitlements={HasEntitlements}
        />
      </Tab>
    );
  };

  public renderViewResultsTabs = (): JSX.Element => {
    return (
      <ResultsView
        selectedVersion={this.state.selectedVersion}
        selectedTab={this.state.selectedTab}
        tabs={this.Tabs}
        horizonServices={this.props.horizonServices}
        selectedParams={this.state.selectedParams}
        userId={this.props.userId}
        velocityCache={this.velocityCacheGraphTab}
            onTraitSelectionChange={this.onGraphTabTraitSelectionChange}
            selectedRunId={this.state.selectedRunId}
      />
    );
  };

  public renderDefaultTabs = (): JSX.Element => {
    return (
      <TabsContainer
        onSelectionTabChanged={this.onTabChanged}
        defaultTab={this.state.selectedTab}
      >
        {this.renderModalTab()}
        {this.renderRuleGroupsTab()}
        {this.renderVersionHistoryTab()}
      </TabsContainer>
    );
  };

  public renderLockedVersionTabs = (): JSX.Element => {
    return (
      <TabsContainer
        onSelectionTabChanged={this.onTabChanged}
        defaultTab={this.state.selectedTab}
      >
        {this.renderGraphTab()}
        {this.renderModalTab()}
        {this.renderRuleGroupsTab()}
        {this.renderVersionHistoryTab()}
      </TabsContainer>
    );
  };

    public render() {
        const { horizonServices } = this.props;
        const { selectedParams, HasEntitlements, selectedVersion } = this.state;

        const isDefaultView = this.state.ViewType === ViewTypes.Default;
        const isViewResultsView = this.state.ViewType === ViewTypes.ViewResults;
        const isVersionLocked = selectedVersion && selectedVersion.isLocked;
        return (
            <>
                {!selectedParams && <Spinner />}
                {selectedParams && (
                    <div className="search-results">
                        <div className="edit-sub-nav color-soft-grey">
                            <PipelineEditedSubHeader
                                horizonServices={horizonServices}
                                onChangeParams={this.paramsChanged}
                                selectedParams={selectedParams}
                                showEditCriteria={isViewResultsView}
                                onEditCriteria={this.onEditCriteria}
                            />
                        </div>
                        {!HasEntitlements && (
                            <div className="alert-horizon">
                                {horizonServices.alert.info(Constants.INFO_MESSAGE, [
                                    { title: "DISMISS", onClick: () => true },
                                    {
                                        title: "ASK BREEDING",
                                        onClick: () =>
                                            (window.location.href =
                                                "mailto:support@askbreeding.freshdesk.com"),
                                    },
                                ])}
                            </div>
                        )}
                        <div className="content">
                          <VersionSelector
                              isVersionDataLoading={this.state.isVersionDataLoading}
                              versions={this.state.modelVersions}
                              selectedVersion={this.state.selectedVersion}
                              userId={this.props.userId}
                              selectedParams={this.props.selectedParams}
                              onViewResultsClick={this.onViewResultsClick}
                              onVersionCreated={this.onVersionCreated}
                              onVersionSelectionChanged={this.onVersionSelectionChanged}
                              horizonServices={this.props.horizonServices}
                              hasEntitlements={HasEntitlements}
                              template={this.state.configTemplate}
                              viewType={this.state.ViewType}
                              onRunIdSelectionChanged={this.onVersionRunIdSelectionChanged}
                              selectedRunId={this.state.selectedRunId}
                          />
                          <div className=" m-24 mt-48">
                              {isDefaultView && !isVersionLocked && this.renderDefaultTabs()}
                              {isDefaultView &&
                                  isVersionLocked &&
                                  this.renderLockedVersionTabs()}
                              {isViewResultsView && this.renderViewResultsTabs()}
                          </div>
                        </div>
                    </div>
                )}
            </>
        );
    }

  private checkForEntitlements = () => {
    const { entitlements } = this.props;
    const { selectedParams } = this.state;
    const selectedCropSubstring = selectedParams.Crop.value.toLowerCase();
    const selectedRegionSubString = selectedParams.Region.value.toLowerCase();
    // const selectedCropSubstring = 'asdasdasd';
    // const selectedRegionSubString = 'asdasdasdasdasd';

    let crops: IEntitlements[] = [];
    let regions: IEntitlements[] = [];

    entitlements.forEach((el) => {
      if (
        el.name.toLowerCase().replace(/\s/g, "").includes(selectedCropSubstring)
      ) {
        crops = [...crops, el];
      }
    });

    if (crops.length > 0) {
      crops.forEach((el) => {
        if (
          el.name
            .toLowerCase()
            .replace(/\s/g, "")
            .includes(selectedRegionSubString)
        ) {
          regions = [...regions, el];
        }
      });
    }

    if (regions.length > 0) {
      if (
        regions[0].name
          .toLowerCase()
          .replace(/\s/g, "")
          .includes(selectedRegionSubString) &&
        regions[0].name
          .toLowerCase()
          .replace(/\s/g, "")
          .includes(selectedCropSubstring)
      ) {
        this.setState({ HasEntitlements: true });
      }
    } else {
      this.setState({ HasEntitlements: false });
    }
  };
}

const mapStateToProps = (state: IRootStore) => {
  return {
    userId: state.auth.user_id,
    selectedParams: state.userPreferences.userPreferences,
    entitlements: state.auth.entitlements,
    analysisInRun: state.criteria.analysisInRun,
  };
};

export default connect(mapStateToProps, {
  getUserPreferences,
  deleteBlupsData,
})(SearchResults);
