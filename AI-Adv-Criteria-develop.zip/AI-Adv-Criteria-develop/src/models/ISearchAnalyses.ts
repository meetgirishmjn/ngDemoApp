export interface IAnalyses {
    id: number;
    version: number;
    lastSuccessfulRun: IAnalyseRun;
    lastRun: IAnalyseRun;
    name: string;
    description: string;
    analyticModelVersionId: number;
    analysisSubType: IAnalysisSubType;
    runs: IAnalyseRun[]
}

export interface IAnalyseRun {
    id: number;
    isFinished: boolean;
    currentStatus: string;
    finalizedStatus: string;
}

export interface IAnalysisSubType {
    id: string;
    name: string;
}
