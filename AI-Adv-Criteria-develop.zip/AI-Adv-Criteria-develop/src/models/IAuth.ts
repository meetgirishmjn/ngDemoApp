import { IEntitlementGroups } from "../shared/constants";

export default interface IAuth {
  isAuthenticated: boolean;
  access_token: string;
  user_id: string;
  entitlements?: IEntitlementGroups;
}
