import initialState from "../store/initialState";
import types from "../actions/ActionTypes";
import _ from "lodash";

export default (state = initialState.criteria, action) => {
  switch (action.type) {
    case types.SAVE_CLICK:
      const newState = state;
      newState.saveClick = action.payload;
          return { ...state, newState };
      case types.ANALYSIS_RUN_SUCCESS:
          return { ...state, analysisInRun: _.cloneDeep(action.payload) };
      case types.ENABLE_RUN_BUTTON:
        const runButtonState = state;
        runButtonState.isRunButtonValid = action.payload;
          return { ...state, runButtonState }
    default:
      return state;
  }
};
