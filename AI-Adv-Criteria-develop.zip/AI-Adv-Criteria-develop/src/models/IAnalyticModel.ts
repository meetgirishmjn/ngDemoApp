export interface IAnalyticModelVersion {
  id: number;
  isDecisionEngine: boolean;
  analyticModel: IAnalyticModel;
}

export interface IAnalyticModel {
  name: string;
  isActive: boolean;
  versions: IVersion[];
  analysisType: IAnalysisType;
}

export interface IVersion {
  id: number;
  releaseUrl: string;
  isActive: boolean;
}

export interface IAnalysisType {
  id: number;
  name: string;
}

export interface IAnalysisSubType {
  uid: string;
  analysisId: string;
  analysisName: string;
  analysisDescription: string;
  analysisSubTypeName: string;
  analysisSubTypeId: string;
  analyticModelType: string;
  hasFulfillment?: boolean;
  fulfillmentID?: number;
}
