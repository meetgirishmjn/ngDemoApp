interface ICrop extends IStringKvp {
  cropId: number;
}
