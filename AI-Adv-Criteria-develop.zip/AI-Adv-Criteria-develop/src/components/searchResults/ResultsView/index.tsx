import React, { Component } from "react";
import { Tab, TabsContainer } from "@monsantoit/ui-react-tabs";
import { find } from "lodash";
import ResultsTab, { ITabType } from "../Tabs/Results";
import GraphsTab, { ITraitAndSubType } from "../Tabs/GraphsTab";
import { ITabItem } from "../SearchResultsProps";
import {
  getRunId,
  getPrescData,
} from "../../../actions/results/advanceActions";
import {
  IResultData,
  ITabData,
  IKey,
  IAnalysisData,
} from "../../../models/IResults";
import {
  getPipelineName,
  IDataByPrescsAndBlups,
  loadBlupsDataByFulfillments,
  IColumnsAndFulfillments,
  getColumnsAndFulfillments,
  filterDataByPrescs,
} from "./helper";
import { IModelVersion } from "../../../actions/criteria/models";
import {
  getFromVelocityCache,
  saveToVelocityCache,
} from "../../../actions/userPreferences/userPreferencesActions";
import { IGraphTabCache } from "../SearchResultsState";

interface IProps {
  selectedVersion: IModelVersion;
  selectedTab: string;
  tabs: ITabItem[];
  horizonServices: any;
  selectedParams: IPipeline;
  userId: string;
  velocityCache: IGraphTabCache;
  onTraitSelectionChange?: (
    graphType: string,
    keyTrait: string,
    traits: string[]
  ) => void;
  selectedRunId?: number;
}

interface IState {
  advanceData: ITabData[];
  dropData: ITabData[];
  noMatchData: ITabData[];
  isDataLoading: boolean;
  columnOrder: any;
  selectedRunId?: number;
}

const RESULTSVIEW_CACHE_KEY = "resultsView";

class ResultsView extends Component<IProps, IState> {
  constructor(props: IProps) {
    super(props);
    this.state = {
      advanceData: [],
      dropData: [],
      noMatchData: [],
      isDataLoading: false,
      columnOrder: {},
      selectedRunId: props.selectedRunId,
    };
  }

  public componentDidMount = async () => {
    this.loadPrescriptions();
  };

  public componentWillReceiveProps(nextProps: IProps) {
    if (nextProps.selectedRunId !== this.state.selectedRunId) {
      this.setState({ selectedRunId: nextProps.selectedRunId }, () => this.loadPrescriptions());
    }
  }

  loadPrescriptions = async () => {
    if (this.state.selectedRunId) {
      this.setState({ isDataLoading: true });
      const runId = this.state.selectedRunId;
      const prescData: IResultData = await getPrescData(runId);
      if (!prescData || (prescData && prescData.errors)) {
        this.props.horizonServices.toast.error(
          `Analysis run not found for runId:${runId}`
        );
        this.setState({
          advanceData: [],
          dropData: [],
          noMatchData: [],
          columnOrder: {},
        });
      } else {
        await this.loadData(prescData);
      }
      this.setState({ isDataLoading: false });
    }
    //} else {
    //  this.setState({ isDataLoading: false });
    //  this.props.horizonServices.toast.error("Unable to get run id");
    //}
  }

  private loadData = async (prescData: IResultData) => {
    const { selectedParams } = this.props;
    let dataByPrescsAndBlups: IDataByPrescsAndBlups = {
      advanceData: [],
      dropData: [],
      noMatchData: [],
    };
    const analysisTypeNames = ["BLUP"];
    const columnsAndFulfillments: IColumnsAndFulfillments[] = await getColumnsAndFulfillments(
      selectedParams,
      analysisTypeNames
    );
    dataByPrescsAndBlups = await filterDataByPrescs(
      prescData,
      dataByPrescsAndBlups
    );
    dataByPrescsAndBlups = await loadBlupsDataByFulfillments(
      columnsAndFulfillments,
      dataByPrescsAndBlups
    );
    const savedState = await getFromVelocityCache(
      this.props.userId,
      RESULTSVIEW_CACHE_KEY
    );
    const { advanceData, dropData, noMatchData } = dataByPrescsAndBlups;
    this.setState({
      advanceData,
      dropData,
      noMatchData,
      columnOrder: savedState || {},
    });
  };

  onColumnOrderChange = async (columnState: any[], type: ITabType) => {
    const { columnOrder } = this.state;
    let newColumnOrder = { ...columnOrder };
    const pipelineKey = getPipelineName(this.props.selectedParams);
    if (!(columnOrder && columnOrder[pipelineKey])) {
      newColumnOrder[pipelineKey] = {};
      newColumnOrder[pipelineKey][type] = columnState;
    } else {
      newColumnOrder[pipelineKey][type] = columnState;
    }
    this.setState({ columnOrder: newColumnOrder });
    const saveFlag = await saveToVelocityCache(
      this.props.userId,
      RESULTSVIEW_CACHE_KEY,
      newColumnOrder
    );
    if (!saveFlag) {
      this.props.horizonServices.toast.warning("Failed to save column order");
    }
  };

  public render() {
    const { selectedVersion, tabs, selectedTab, selectedParams } = this.props;
    const {
      advanceData,
      dropData,
      noMatchData,
      isDataLoading,
      columnOrder,
    } = this.state;
    const pipelineKey = getPipelineName(selectedParams);
    return (
      <TabsContainer defaultTab={selectedTab}>
        <Tab key="Graphs" name={tabs[0].name} title={tabs[0].title}>
          <GraphsTab
            selectedParams={selectedParams}
            horizonServices={this.props.horizonServices}
            selectedVersion={selectedVersion}
            selectedRunId={this.state.selectedRunId}
            velocityCache={this.props.velocityCache}
            onTraitSelectionChange={this.props.onTraitSelectionChange}
          />
        </Tab>
        <Tab key="Advance" name={"Advance"} title={"Advance"}>
          <ResultsTab
            type={ITabType.Advance}
            selectedVersion={selectedVersion.analyseId}
            data={advanceData}
            isDataLoading={isDataLoading}
            columnOrder={
              columnOrder[pipelineKey] &&
              columnOrder[pipelineKey][ITabType.Advance]
            }
            onColumnOrderChange={this.onColumnOrderChange}
          />
        </Tab>
        <Tab key="Drop" name={"Drop"} title={"Drop"}>
          <ResultsTab
            type={ITabType.Drop}
            selectedVersion={selectedVersion.analyseId}
            data={dropData}
            isDataLoading={isDataLoading}
            columnOrder={
              columnOrder[pipelineKey] &&
              columnOrder[pipelineKey][ITabType.Drop]
            }
            onColumnOrderChange={this.onColumnOrderChange}
          />
        </Tab>
        <Tab key="NoMatch" name={"NoMatch"} title={"No Match"}>
          <ResultsTab
            type={ITabType.NoMatch}
            selectedVersion={selectedVersion.analyseId}
            data={noMatchData}
            isDataLoading={isDataLoading}
            columnOrder={
              columnOrder[pipelineKey] &&
              columnOrder[pipelineKey][ITabType.NoMatch]
            }
            onColumnOrderChange={this.onColumnOrderChange}
          />
        </Tab>
      </TabsContainer>
    );
  }
}

export default ResultsView;
