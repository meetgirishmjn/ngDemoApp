import React, { Component } from "react";
import { connect } from "react-redux";
import { each, isEqual, isEmpty } from "lodash";
import { DropDown, LabelPosition } from "@monsantoit/ui-react-base-controls";
import {
  IListItem,
  IDataset,
  IBlupsDataForSelectedVersion,
} from "../../../../models/IGraphTab";
import { advConfigQuery } from "../../../../actions/advConfigDb/advConfigQuery";
import {
  IQueryAdvConfigResponse,
  ITraitsData,
  ITraitAndCalc,
  IFulfillment,
} from "../../../../models/IAdvConfig";
import { IConfigApiBaseRes } from "../../../../actions/advConfigDb/models";
import {
  parseTraitParam,
  findAdvRequistions,
  parseJsonValue,
} from "../EngineConfigTab/helper";
import HistogramGraph from "./histogram/histogramGraph";
import IRootStore from "../../../../store/IRootStore";
import {
  saveGraphsData,
  saveBlupsData,
} from "../../../../actions/pac/pacActions";
import { IResultData, IAnalysisData } from "../../../../models/IResults";
import {
  getRunId,
  getPrescData,
} from "../../../../actions/results/advanceActions";
import "./graphsTab.scss";
import ScatterPlotGraph from "./scatterplot/scatterplotGraph";
import { IModelVersion } from "../../../../actions/criteria/models";
import { IGraphTabCache } from "../../SearchResultsState";
import {
  getColumnsAndFulfillments,
  IColumnsAndFulfillments,
} from "../../../searchResults/ResultsView/helper";

const GRAPHSTAB_CACHE_KEY = "GraphsTab";

export interface IGraphsTabProps {
  userId: string;
  selectedParams: IPipeline;
  horizonServices: any;
    selectedVersion: IModelVersion;
    selectedRunId?: number;
  traitsForSelectedPipeline?: string[];
  prescForSelectedAnalyses?: IResultData;
  blupsDataForSelectedVersion: IBlupsDataForSelectedVersion;
  saveGraphsData: (
    traits: ITraitAndSubType[],
    pipelineName: string,
    prescData: IResultData,
    selectedVersion: IModelVersion
  ) => void;
  saveBlupsData: (key: string, dataSet: IDataset) => void;
  velocityCache: IGraphTabCache;
  onTraitSelectionChange?: (
    graphType: string,
    keyTrait: string,
    traits: string[]
  ) => void;
}

export interface IGraphsTabState {
  selectedParams: IPipeline;
  selectedVersion: IModelVersion;
  traits: ITraitAndSubType[];
  isTraitsLoading: boolean;
  prescData: IResultData;
    isPrescLoading: boolean;
    selectedRunId?: number;
}

export interface ITraitAndSubType {
  fulfillments: IFulfillment[];
  traitName: string;
  subType: string;
  customTraitname: string;
}
const MAX_HISTOGRAMS = 9;
const MAX_SCATTERPLOTS = 2;

const getPipelineName = (pipeline: IPipeline) => {
  const {
    Crop,
    Region,
    Year,
    HarvestType,
    Market,
    SubMarket,
    ProductStage,
    StageType,
    DecisionEngine,
  } = pipeline;
  const name = `${Crop.value}_${Year}_${Region.value}_${HarvestType.value}_${Market.value}_${SubMarket.value}_${ProductStage.value}_${StageType.value}_${DecisionEngine.value}`;
  return name.replace(/\s/g, "_");
};

export class GraphsTab extends Component<IGraphsTabProps, IGraphsTabState> {
  constructor(props: IGraphsTabProps) {
    super(props);
    const {
      selectedParams,
      selectedVersion,
      traitsForSelectedPipeline,
      prescForSelectedAnalyses,
    } = props;
    const pipelineName: string = getPipelineName(selectedParams);
    const prescData =
      prescForSelectedAnalyses &&
      prescForSelectedAnalyses[
        `${pipelineName}_${selectedVersion.analyseId}_${selectedVersion.version}`
      ];
    this.state = {
      traits:
        (traitsForSelectedPipeline &&
          traitsForSelectedPipeline[pipelineName]) ||
        [],
      selectedParams: selectedParams,
      isTraitsLoading:
        traitsForSelectedPipeline && !traitsForSelectedPipeline[pipelineName],
      prescData: prescData,
      isPrescLoading: !prescData,
      selectedVersion: props.selectedVersion,
      selectedRunId: props.selectedRunId
    };
    traitsForSelectedPipeline &&
      !traitsForSelectedPipeline[pipelineName] &&
      this.updateTraits();
    prescForSelectedAnalyses &&
      isEmpty(
        prescForSelectedAnalyses[
          `${pipelineName}_${selectedVersion.analyseId}_${selectedVersion.version}`
        ]
      ) &&
      this.updatePrescriptions(selectedVersion);
  }

  public static getDerivedStateFromProps(
    nextProps: IGraphsTabProps,
    prevState: IGraphsTabState
  ) {
    if (!isEqual(prevState.selectedVersion, nextProps.selectedVersion) || prevState.selectedRunId !== nextProps.selectedRunId) {
        return { selectedVersion: nextProps.selectedVersion, selectedRunId: nextProps.selectedRunId };
    }
    if (!isEqual(prevState.selectedParams, nextProps.selectedParams)) {
      return { selectedParams: nextProps.selectedParams };
    }
    return null;
  }

  componentDidUpdate = async (
    prevProps: IGraphsTabProps,
    prevState: IGraphsTabState
  ) => {
    if (!isEqual(prevProps.selectedParams, this.props.selectedParams)) {
      this.updateTraits();
    }

    if(!isEqual(prevProps.selectedVersion, this.props.selectedVersion) || prevProps.selectedRunId!==this.props.selectedRunId) {
      this.updatePrescriptions(this.props.selectedVersion);
    }
  };

  public genderData = (): IListItem[] => {
    const list: IListItem[] = [];
    list.push({ id: "1", text: "All", isSelected: false });
    list.push({ id: "2", text: "Female", isSelected: false });
    list.push({ id: "3", text: "Male", isSelected: false });
    return list;
  };

  public checkData = (): IListItem[] => {
    const list: IListItem[] = [];
    list.push({ id: "1", text: "Maturity", isSelected: false });
    list.push({ id: "2", text: "Performance", isSelected: false });
    return list;
  };

  updatePrescriptions = async (selectedVersion: IModelVersion) => {
    this.setState({ isPrescLoading: true });
    const prescData = await this.getPrescriptions();
    this.setState({ prescData });
    this.props.saveGraphsData(
      this.state.traits,
      getPipelineName(this.props.selectedParams),
      prescData,
      selectedVersion
    );
    this.setState({ isPrescLoading: false });
  };

  updateTraits = async () => {
    this.setState({ isTraitsLoading: true, traits: [] });
    const traits = await this.loadTraits();
    this.setState({ traits, isTraitsLoading: false });
    this.props.saveGraphsData(
      traits,
      getPipelineName(this.props.selectedParams),
      this.state.prescData,
      this.props.selectedVersion
    );
  };

  getPrescriptions = async () => {
    let prescData: IResultData = null;
    if (this.state.selectedRunId) {
        const runId = this.state.selectedRunId;
        prescData = await getPrescData(runId);
        if (!prescData || (prescData && prescData.errors)) {
            this.props.horizonServices.toast.error(
                `Analysis run not found for runId:${runId}`
            );
            prescData = null;
        }
    }
    return prescData;
  };

  public loadTraits = async () => {
    const {
      Crop,
      Region,
      Year,
      HarvestType,
      Market,
      ProductStage,
      Trait,
      SubMarket,
    } = this.props.selectedParams;
    const response: IConfigApiBaseRes<IQueryAdvConfigResponse> = await advConfigQuery(
      Crop.value,
      Region.key,
      HarvestType.key,
      Year,
      Market.key,
      parseTraitParam(Trait).value,
      SubMarket.key
    );
    let traits: ITraitAndSubType[] = [];
    if (!response.hasError) {
      const requistions = findAdvRequistions(
        response.data,
        SubMarket.key,
        parseTraitParam(Trait).value,
        ProductStage.value
      );
      const pacRequistions = requistions.filter(
        (o) => o.dataProviderName === "PAC"
      );
      const analysisTypeNames = ["PREDICTION", "BLUP"];
      const columnsAndFulfillments: IColumnsAndFulfillments[] = await getColumnsAndFulfillments(
        this.props.selectedParams,
        analysisTypeNames
      );
      columnsAndFulfillments.forEach((colAndFul: IColumnsAndFulfillments) => {
        colAndFul.columnnames.forEach((traitName: string) => {
          traits.push({
            fulfillments: colAndFul.fulfillments,
            subType: colAndFul.analysisSubTypeName,
            customTraitname: `${traitName}(${colAndFul.analysisSubTypeName})`,
            traitName,
          });
        });
      });
    }
    return traits;
  };

  public onChangeOfBlupDataSet = (dataset: IDataset, traitName: string) => {
    const { selectedParams, selectedVersion } = this.state;
    const pipelineName: string = getPipelineName(selectedParams);
    this.props.saveBlupsData(
      `${pipelineName}_${selectedVersion.analyseId}_${selectedVersion.version}_${traitName}`,
      dataset
    );
  };

  public renderGraphTabFilter = () => {
    return (
      <div className="filter-container">
        <div className="cards version-card mb-0">
          <div className="container-fluid">
            <div className="row card-header card-grey">
              <div className="d-flex justify-content-start label-ver-col align-items-center pl-24">
                            <label className="label-ver col-form-label">Filter</label>
                <div className="graph-dropdowns">
                  <div className="gender-dropdown">
                    <DropDown
                      name={"Gender"}
                      label={"Gender"}
                      labelPosition={LabelPosition.Left}
                      isMultiselect={false}
                      sorted={true}
                      data={this.genderData()}
                      textProperty={"text"}
                      hasAllCheckbox={false}
                      // onSelectionChanged={this.onTimeframeYearChange}
                      // isDisabled={hasEntitlements ? marketsForCropData.length > 0 ? false : true : true}
                    />
                  </div>
                  <div className="check-dropdown">
                    <DropDown
                      name={"Check"}
                      label={"Check"}
                      labelPosition={LabelPosition.Left}
                      isMultiselect={false}
                      sorted={true}
                      data={this.checkData()}
                      textProperty={"text"}
                      hasAllCheckbox={false}
                      // onSelectionChanged={this.onTimeframeYearChange}
                      // isDisabled={hasEntitlements ? marketsForCropData.length > 0 ? false : true : true}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  public renderHistograms() {
    const { traits, prescData, selectedParams, selectedVersion } = this.state;
    let histograms = [];
    let vCache = this.props.velocityCache;
    traits.slice(0, MAX_HISTOGRAMS).forEach((traitAndSubType: ITraitAndSubType, index: number) => {
      const pipelineName: string = getPipelineName(selectedParams);
      const customTraitName = `${traitAndSubType.traitName}(${traitAndSubType.subType})`;
      const key = `${pipelineName}_${selectedVersion.analyseId}_${selectedVersion.version}_${customTraitName}`;
      let selectedTrait = traitAndSubType;
      // find trait as per cache
      if (
        vCache &&
        vCache.histogramSelectionHash &&
        vCache.histogramSelectionHash[customTraitName] &&
        traits.find((trait: ITraitAndSubType) => trait.customTraitname === vCache.histogramSelectionHash[customTraitName])
      ) {
        //selected Trait is in cache and also in traits then overwrite
        selectedTrait = traits.find((trait: ITraitAndSubType) => trait.customTraitname === vCache.histogramSelectionHash[customTraitName]);
      }
      histograms.push(
        <HistogramGraph
          key={`Histogram_${index}`}
          keyTrait={customTraitName}
          selectedTrait={selectedTrait}
          traitsAndSubType={traits}
          prescData={prescData}
          dataSet={this.props.blupsDataForSelectedVersion[key]}
          onChangeOfDataSet={this.onChangeOfBlupDataSet}
          onChangeOfTrait={(keyTrait, selectedTrait) => {
            if (this.props.onTraitSelectionChange) {
              this.props.onTraitSelectionChange("Histogram", keyTrait, [
                selectedTrait,
              ]);
            }
          }}
        />
      );
    });
    return <div className="row visualization-row">{histograms}</div>;
  }

  public renderScatterPlots() {
    const { traits, prescData, selectedParams, selectedVersion } = this.state;
    let scatterplots = [];
    let vCache = this.props.velocityCache;
    traits
      .slice(0, MAX_SCATTERPLOTS)
      .forEach((traitAndSubType: ITraitAndSubType, index: number) => {
        const pipelineName: string = getPipelineName(selectedParams);
        const customTraitName = `${traitAndSubType.traitName}(${traitAndSubType.subType})`;
        let selectedTrait: ITraitAndSubType = traitAndSubType;
        let selectedCompareTrait: ITraitAndSubType = null;
        if (vCache && vCache.scatterSelectionHash) {
          const cachedSelections = vCache.scatterSelectionHash[traitAndSubType.customTraitname];
          if (cachedSelections && cachedSelections.length == 2) {
            //selected Trait is in cache and also in traits then overwrite
            const findTrait1 = traits.find((trait: ITraitAndSubType) => trait.customTraitname === cachedSelections[0]);
            const findTrait2 = traits.find((trait: ITraitAndSubType) => trait.customTraitname === cachedSelections[1]);
            if (findTrait1) {
              selectedTrait = findTrait1;
            }
            if (findTrait2) {
              selectedCompareTrait = findTrait2;
            }
          }
        }
        scatterplots.push(
          <ScatterPlotGraph
            key={`ScatterPlot_${index}`}
            keyTrait={customTraitName}
            selectedTrait={selectedTrait}
            selectedCompareTrait={selectedCompareTrait}
            traitsAndSubType={traits}
            prescData={prescData}
            //selectedTraitDataSet ={this.props.blupsDataForSelectedVersion[key]}
            //compareTraitDataSet = {this.props.blupsDataForSelectedVersion[key]}
            //onChangeOfSelectedDataSet ={this.onChangeOfBlupDataSet}
            //onChangeOfCompareDataSet = {this.onChangeOfBlupDataSet}
            onChangeOfTrait={(
              keyTrait: string,
              selectedTrait: string,
              selectedCompareTrait: string
            ) => {
              if (this.props.onTraitSelectionChange) {
                this.props.onTraitSelectionChange("Scatter", keyTrait, [
                  selectedTrait,
                  selectedCompareTrait,
                ]);
              }
            }}
          />
        );
      });

    return <div className="row visualization-row">{scatterplots}</div>;
  }

  public render() {
    const { isTraitsLoading, isPrescLoading, prescData, traits } = this.state;
    return (
      <div className="graphs-container">
        {this.renderGraphTabFilter()}
        {(isTraitsLoading || isPrescLoading) && (
          <div className="loading-div">
            <span
              className="spinner-grow spinner-grow-sm"
              role="status"
              aria-hidden="true"
            />
            Loading...
          </div>
        )}
        {!isTraitsLoading && !traits.length && (
          <div className="mt-24">
            {this.props.horizonServices.alert.error(
              "No selected traits in define data for selected pipeline. Try another pipeline"
            )}
          </div>
        )}
        {!isPrescLoading && !prescData && (
          <div className="mt-24">
            {this.props.horizonServices.alert.error(
              "No prescriptions found for selected version."
            )}
          </div>
        )}
        {prescData && !isPrescLoading && !isTraitsLoading && (
          <>
            {this.renderHistograms()}
            {this.renderScatterPlots()}
          </>
        )}
      </div>
    );
  }
}

const mapStateToProps = (state: IRootStore) => {
  return {
    traitsForSelectedPipeline: state.graphData.traitsForSelectedPipeline,
    prescForSelectedAnalyses: state.graphData.prescForSelectedAnalyses,
    blupsDataForSelectedVersion: state.graphData.blupsDataForSelectedVersion,
  };
};

export default connect(mapStateToProps, { saveGraphsData, saveBlupsData })(
  GraphsTab
);
