import React from "react";
import { shallow, mount } from "enzyme";
import FieldRenderer from "./fieldRenderer";
import { FieldTypes, IConfigField } from "../../../../actions/criteria/models";
import { BrowserRouter } from "react-router-dom";
import configureMockStore from "redux-mock-store";
import thunk from "redux-thunk";
import { Provider } from "react-redux";

const testField: IConfigField = {
  dataType: FieldTypes.Text,
  value: "",
  name:"test",
  display: "Test",
  isReadOnly: false,
  isRequired: true,
  key: "test",
  tooltip: "",
  isNumeric: false,
  criteriaValueId: null,
  criteriaDefaultValueId: 5,
  criteriaDefinitionId: 13,
  validators: ""
};

const mockStore = configureMockStore([thunk]);
const store = mockStore({});

describe("FieldRenderer", () => {
  it("should render FieldRenderer with default props", () => {
    const wrapper = shallow(
      <BrowserRouter>
        <Provider store={store}>
          <FieldRenderer customTooltipCss={{}} field={testField} />
        </Provider>
      </BrowserRouter>
    );
    expect(wrapper.find("div.form-group").length).toBe(0);
  });

  it("should render percentage input", () => {
    testField.dataType = FieldTypes.Percentage;
    const wrapper = mount(
      <BrowserRouter>
        <Provider store={store}>
          <FieldRenderer customTooltipCss={{}} field={testField} />
        </Provider>
      </BrowserRouter>
    );
    expect(wrapper.find("input").length).toBe(1);
  });

  it("should render number input", () => {
    testField.dataType = FieldTypes.Number;
    const wrapper = mount(
      <BrowserRouter>
        <Provider store={store}>
          <FieldRenderer customTooltipCss={{}} field={testField} />
        </Provider>
      </BrowserRouter>
    );
    expect(wrapper.find("input").length).toBe(1);
  });

  it("should trigger inputChange event", () => {
    const wrapper = mount(
      <BrowserRouter>
        <Provider store={store}>
          <FieldRenderer customTooltipCss={{}} field={testField} />
        </Provider>
      </BrowserRouter>
    );
    wrapper.find("input").getDOMNode<HTMLInputElement>().value = "test value";
    wrapper.find("input").simulate("change");
    expect(wrapper.find("input").length).toBe(1);
  });
});
