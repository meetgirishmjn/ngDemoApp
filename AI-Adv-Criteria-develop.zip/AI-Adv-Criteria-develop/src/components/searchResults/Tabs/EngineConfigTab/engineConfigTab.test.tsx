import React from "react";
import { mount } from "enzyme";
import { IConfigurationTemplate } from "../../../../actions/criteria/models";
import EngineConfigTab from ".";

describe("EngineConfigTab", () => {
  it("should render with empty template", () => {
    const template: IConfigurationTemplate = {
      sections: [],
    };

    const wrapper = mount(
      <EngineConfigTab
        isEditable={true}
        template={template}
        analysisId={"7854"}
        analysisVersion={1}
        horizonServices={null}
      />
    );

    expect(wrapper.find("div").length).toBe(1);
  });

  it("should render with sections ", () => {
    const template: IConfigurationTemplate = {
      sections: [
        {
          title: "Section 1",
          fieldRows: [],
          fields: [],
          key: "section1",
          hasRequiredField: false,
        },
        {
          title: "Section 2",
          fieldRows: [],
          fields: [],
          key: "section2",
          hasRequiredField: false,
        },
      ],
    };

    const wrapper = mount(
      <EngineConfigTab
        isEditable={true}
        template={template}
        analysisId={"7854"}
        analysisVersion={1}
        horizonServices={null}
      />
    );

    expect(wrapper.find("h2.sec-title").length).toBe(2);
  });
});
