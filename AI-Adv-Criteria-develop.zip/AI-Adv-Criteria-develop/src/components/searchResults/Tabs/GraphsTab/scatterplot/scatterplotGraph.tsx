import React, { Component } from "react";
import { isEmpty } from "lodash";
import { Plot, IScatterDatum } from "@monsantoit/ui-react-visualizations/dist/Scatter/IScatterPlot";
import { DropDown } from "@monsantoit/ui-react-base-controls";
import { ScatterPlot } from "@monsantoit/ui-react-visualizations/dist/Scatter/ScatterPlot";
import { IResultData, ITabData } from "../../../../../models/IResults";
import "./scatterplot.scss";
import { IDictionary } from "../../../../../models/Common";
import _ from "lodash";
import { filterDataByPrescs, filterDataByBlups } from "../../../ResultsView/helper";
import { ITraitAndSubType } from "..";

export interface IScatterPlotGraphProps {
    selectedTrait: ITraitAndSubType;
    selectedCompareTrait: ITraitAndSubType;
    traitsAndSubType: ITraitAndSubType[];
    prescData: IResultData;
    //selectedTraitDataSet: IScatterDataset;
    //compareTraitDataSet: IScatterDataset;
    //onChangeOfSelectedDataSet: (selectedTraitDataSet: IScatterDataset, selectedTrait: string) => void;
    //onChangeOfCompareDataSet: (compareTraitDataSet: IScatterDataset, conpareTrait: string) => void;
    onChangeOfTrait: (keyTrait: string, selectedTrait: string, selectedCompareTrait:string) => void;
    keyTrait: string;
  }
export interface IScatterPlotGraphState {
    isDataLoading: boolean;
    selectedTrait: ITraitAndSubType;
    selectedCompareTrait: ITraitAndSubType;
    selectedTraitDataSet: IScatterDataset;
    compareTraitDataSet: IScatterDataset;
  }

export default class ScatterPlotGraph extends Component<IScatterPlotGraphProps, IScatterPlotGraphState>{
  
    constructor(props: IScatterPlotGraphProps) {
        super(props);
        this.state = {
            selectedTrait: props.selectedTrait,
            selectedCompareTrait: props.selectedCompareTrait,
            selectedTraitDataSet:null,
            compareTraitDataSet: null,
            isDataLoading:true
        };
    }

    componentDidMount = () => {
      const { selectedTrait, selectedCompareTrait } = this.props;
      selectedTrait && this.loadSelectedTraitsData(this.props.selectedTrait, false);
      selectedCompareTrait && this.loadSelectedTraitsData(this.props.selectedCompareTrait,true);
    };

    loadSelectedTraitsData = async (traitAndSubType : ITraitAndSubType, isCompareTrait:boolean) =>{
      let dataByPrescsAndBlups = {
        advanceData: [],
        dropData: [],
        noMatchData: []
      }
      const traitName = traitAndSubType.traitName;
      dataByPrescsAndBlups = filterDataByPrescs(this.props.prescData, dataByPrescsAndBlups);
      if(traitAndSubType.fulfillments[0] && traitAndSubType.fulfillments[0].externalId) {
        dataByPrescsAndBlups = await filterDataByBlups([traitName], dataByPrescsAndBlups, traitAndSubType.fulfillments[0].externalId);
      }
      const { advanceData, dropData, noMatchData } = dataByPrescsAndBlups;
      let advanceValues: IDictionary<number>[] = [];
      let dropValues: IDictionary<number>[] = [];
      let noMatchValues: IDictionary<number>[] = [];
      let traitDataSet: IScatterDataset = null;
      advanceData.map((a: ITabData) =>
          a[traitName] ? advanceValues.push({ [a.lineName]: parseFloat(a[traitName]) }) : null
      );
      dropData.map((a: ITabData) =>
          a[traitName] ? dropValues.push({ [a.lineName]: parseFloat(a[traitName]) }) : null
      );
      noMatchData.map((a: ITabData) =>
          a[traitName] ? noMatchValues.push({ [a.lineName]: parseFloat(a[traitName]) }) : null
      );

      if(advanceValues.length || dropValues.length || noMatchValues.length) {
       traitDataSet = {
          advanceValues : advanceValues,
          dropValues: dropValues,
          noMatchValues: noMatchValues
        }
        }
        if (!isCompareTrait) {
            this.setState({
                selectedTraitDataSet: traitDataSet,
                isDataLoading: false
            });
        } else {
            this.setState({
                compareTraitDataSet: traitDataSet,
                isDataLoading: false
            });
        }
    };

      public generateTooltip = (chartToolTipsProps: any) => {
        const datum = chartToolTipsProps.payload;
        const plot = `(${datum[0]?.value}, ${datum[1]?.value})`;
        const category = chartToolTipsProps.payload[0].payload.category;
        return <div>
            <div>{category}</div>
            <div>{plot}</div>
        </div>
      }

      public onChangeOfSelectedTrait = async (traitAndSubType: ITraitAndSubType) => {
        await this.setState({ selectedTrait: traitAndSubType, isDataLoading: true });
        this.loadSelectedTraitsData(traitAndSubType,false);
        this.props.onChangeOfTrait(this.props.keyTrait, traitAndSubType.customTraitname, this.state.selectedCompareTrait.customTraitname);
      };
  
      public onChangeOfCompareTrait = async (traitAndSubType: ITraitAndSubType) => {
        await this.setState({ selectedCompareTrait: traitAndSubType, isDataLoading: true });
          this.loadSelectedTraitsData(traitAndSubType,true);
          this.props.onChangeOfTrait(this.props.keyTrait, this.state.selectedTrait.customTraitname, traitAndSubType.customTraitname);
      };

    public mergeValues = (values: IDictionary<number>[], compareValues: IDictionary<number>[]): Plot[] => {
        let results: Plot[] = [];
        let lineNames: string[] = [];
        let compareLineNames: string[] = [];

        const valuesRef = values || [];
        const compareValuesRef = compareValues || [];

        valuesRef.forEach(item => {
            lineNames.push(Object.keys(item)[0]);
        })

        compareValuesRef.forEach(item => {
            compareLineNames.push(Object.keys(item)[0]);
        })

        const findValue=(inputs: IDictionary<number>[], lineName: string):number => {
            const match = inputs.find(o => o.hasOwnProperty(lineName));
            if (match) {
              return  match[lineName] || 0
            }
            return 0;
        }
        _.uniq([...lineNames, ...compareLineNames]).forEach(lineName => {
            const item:Plot = {
                category: lineName,
                x: findValue(valuesRef,lineName),
                y: findValue(compareValuesRef,lineName),
            };
            if (item.x !== 0 || item.y !== 0) {
                results.push(item);
            }
        });
        return results;
    }

    public generatePlotsData = (selectedTraitVaules: IScatterDataset, compareTraitValues: IScatterDataset) => {
        let graphData: IScatterDatum[] = null;
        if (!selectedTraitVaules && !compareTraitValues) {
            return graphData;
        }

        graphData = [
            { name: "advance", plots: this.mergeValues(selectedTraitVaules?.advanceValues, compareTraitValues?.advanceValues) },
            { name: "drop", plots: this.mergeValues(selectedTraitVaules?.dropValues, compareTraitValues?.dropValues ) },
            { name: "noMatch", plots: this.mergeValues(selectedTraitVaules?.noMatchValues, compareTraitValues?.noMatchValues) }
        ];

        return graphData;
    }

      public render() {
        const { traitsAndSubType } = this.props;
        const { selectedTrait, selectedCompareTrait, selectedTraitDataSet, compareTraitDataSet } = this.state;
        const compareTraitName = selectedCompareTrait ? selectedCompareTrait.customTraitname : "";
        
        const vizLoading = (
          <div className=" card p-4">
            <div className="viz-loading">
              <div />
              <div />
              <div />
            </div>
          </div>
        );

       return(
         <>
          {
            <div className="visualization col-md-6">
              {this.state.isDataLoading && vizLoading}
              {!this.state.isDataLoading && (
                   <ScatterPlot
                   data = {this.generatePlotsData(selectedTraitDataSet, compareTraitDataSet)}
                   legend={{hide:false}}
                   xAxisTitle = {selectedTrait.customTraitname}
                   yAxisTitle={compareTraitName}
                   xDomain={['dataMin', 'dataMax']}
                   yDomain={['dataMin', 'dataMax']}
                   tooltip= {{genTooltipContent: this.generateTooltip}}
                   subTitle = {
                     <div className="row visualization-row">
                       <div className="visualization col-md-5">
                       <DropDown  
                          name={selectedTrait.customTraitname}
                          data={traitsAndSubType}
                          textProperty="customTraitname"
                          selectedItem={selectedTrait}
                          onSelectionChanged ={(e,item) => this.onChangeOfSelectedTrait(item)}
                          />
                        </div>
                        <div className="visualization col-md-1"><label className="txt16">vs</label></div>
                        <div className="visualization col-md-5"> 
                          <DropDown
                              name={compareTraitName}
                              data={traitsAndSubType}
                              textProperty="customTraitname"
                              selectedItem={selectedCompareTrait}
                              onSelectionChanged ={(e,item) => this.onChangeOfCompareTrait(item)}
                            />
                        </div>
                     </div>
                   }
                   />
              )}
            </div>
          }
         </>
       );

    }
}

interface IScatterDataset{
    advanceValues: IDictionary<number>[];
    dropValues: IDictionary<number>[];
    noMatchValues: IDictionary<number>[];
}