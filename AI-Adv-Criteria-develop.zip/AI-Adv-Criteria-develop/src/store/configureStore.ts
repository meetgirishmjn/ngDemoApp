import { applyMiddleware, createStore, compose } from "redux";
import rootReducer from "./rootReducer";
import thunk from "redux-thunk";
const devTools =
  (window["__REDUX_DEVTOOLS_EXTENSION_COMPOSE__"] as typeof compose) || compose;
const composeEnhancers = devTools(applyMiddleware(thunk));
const store = createStore(rootReducer, composeEnhancers);
export default function configureStore() {
  return store;
}

export { store };
