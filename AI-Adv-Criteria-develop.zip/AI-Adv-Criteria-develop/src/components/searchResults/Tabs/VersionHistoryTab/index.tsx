import React, { Component } from "react";
import "./versionHistoryTab.scss";
import { GridContainer } from "@monsantoit/ui-react-grid-container";
import { IVersionHistoryTabProps } from "./versionHistoryTabProps";
import { IVersionHistoryTabState } from "./versionHistoryTabState";
import { IVersionHistoryInfo } from "../../../../actions/criteria/models";
import { getVersionHistoryData } from "../../../../actions/criteria/criteriaActions";
import { ColDef } from "ag-grid";
import _ from "lodash";

export default class VersionHistoryTab extends Component<
  IVersionHistoryTabProps,
  IVersionHistoryTabState
> {
  public static getDerivedStateFromProps(
    nextProps: IVersionHistoryTabProps,
    prevState: IVersionHistoryTabState
  ) {
      if (!_.isEqual(prevState.selectedVersion, nextProps.selectedVersion) || 
      parseInt(prevState.analysesId, 10) !== parseInt(nextProps.analysesId, 10)
    ) {
          return { analysesId: nextProps.analysesId, selectedVersion: nextProps.selectedVersion };
    }
    return null;
  }

  private gridContainer = React.createRef<GridContainer>();

  private columns = [
    {
      headerName: "Status",
      field: "status",
      colId: "status",
      filter: "agTextColumnFilter",
      suppressSizeToFit: true,
      suppressResize: true,
      resizable: false,
      width: 50,
      cellRenderer: (params: any) => {
        let content = "";
        let status = params.data.status as string;
        const issavedForAdv = params.data.savedForAdv;
        // make first letter capital
        status = status ? status.toLowerCase() : "";
        const updatedStatus = status && status.length && status.charAt(0).toUpperCase() + status.slice(1);
        switch (status) {
          case "":
            content = '<span class="rectangle-badge bg-color-status-blue">Saved</span>';
            break;
          case "success":
            content = `<span class="rectangle-badge ${issavedForAdv ? "bg-color-status-purple" : "bg-color-status-green"}">${issavedForAdv ? "Saved for Adv" : updatedStatus}</span>`;
            break;
          case "failure":
            content = '<span class="rectangle-badge bg-color-status-red">Failed</span>';
            break;
          case "running":
            content = `<span class="rectangle-badge bg-color-status-orange">${updatedStatus}</span>`;
            break;
          case "queued":
            content = `<span class="rectangle-badge bg-color-status-yellow">${updatedStatus}</span>`;
            break;
          default:
            content = `<span class="rectangle-badge bg-color-status-grey">${updatedStatus || "Unknown"}</span>`;
            break;
        }
        return content;
      },
    },
    {
      headerName: "Analysis Name",
      field: "reportName",
      colId: "reportName",
      filter: "agTextColumnFilter",
      minWidth: 200,
    },
    {
      headerName: "Version",
      field: "version",
      colId: "version",
      filter: "agTextColumnFilter",
      suppressSizeToFit: true,
      suppressResize: true,
      resizable: false,
      width: 100,
    },
    {
      headerName: "Date Modified",
      field: "dateModified",
      colId: "dateModified",
      filter: "agTextColumnFilter",
      width: 150,
    },
    {
      headerName: "Date of Run",
      field: "dateLastRun",
      colId: "dateLastRun",
      filter: "agTextColumnFilter",
      width: 150,
    },
    {
      headerName: "User",
      field: "userName",
      colId: "userName",
      filter: "agTextColumnFilter",
      width: 100,
    },
    {
      headerName: "Run ID",
      field: "runId",
      colId: "runId",
      filter: "agTextColumnFilter",
      width: 100,
    },
    {
      headerName: "Modification Comments",
      field: "comments",
      colId: "comments",
      filter: "agTextColumnFilter",
      editable: this.props.hasEntitlements ? true : false,
      minWidth: 225,
      cellEditor: "agLargeTextCellEditor",
      onCellValueChanged: (arg: any) => {
        const item = arg.data as IVersionHistoryInfo;
        if (item && this.props.onCellValueChanged) {
          this.props.onCellValueChanged(item, arg.newValue);
        }
      },
    },
  ];

  constructor(props: IVersionHistoryTabProps) {
    super(props);
    this.state = {
      isDataLoading: false,
        analysesId: props.analysesId,
      selectedVersion:props.selectedVersion,
      data: [],
    };
  }

  public componentDidMount = async () => {
    if (this.props.analysesId) {
      this.setState({ isDataLoading: true });
      const data = await getVersionHistoryData(this.props.analysesId);
      this.setState({
        isDataLoading: false,
        data: this.applyFilterOnData(data),
      });
    }
  };

  public componentDidUpdate = async (prevProps: IVersionHistoryTabProps) => {
    const { analysesId,selectedVersion } = prevProps;
      if (!_.isEqual(selectedVersion,this.props.selectedVersion)  || analysesId !== this.props.analysesId) {
      this.setState({ isDataLoading: true });
      const data = await getVersionHistoryData(this.props.analysesId);
      this.setState({
        isDataLoading: false,
          data: this.applyFilterOnData(data),
      });
    }
    };

    public applyFilterOnData = (data: IVersionHistoryInfo[]): IVersionHistoryInfo[] => {
        if (data && data.length) {
            return data.filter(o => o.version == this.state.selectedVersion.version);
        }
        return data;
    }

  public render() {
    const menu: JSX.Element = (
      <div className="grid-title h5">Version History</div>
    );
    const { isDataLoading, data } = this.state;

    return (
      <div className="version-history-container">
        {isDataLoading && (
          <div className="loading-div">
            <span
              className="spinner-grow spinner-grow-sm"
              role="status"
              aria-hidden="true"
            />
            Loading...
          </div>
        )}
        {!isDataLoading && !data && (
          <div className="mt-24">
            {this.props.horizonServices.alert.error(
              "System not responding. Please try refreshing your browser or contact Ask Breeding.",
              [
                { title: "DISMISS", onClick: () => true },
                {
                  title: "ASK BREEDING",
                  onClick: () =>
                    (window.location.href =
                      "mailto:support@askbreeding.freshdesk.com"),
                },
              ]
            )}
          </div>
        )}
        {!isDataLoading && data && data.length > 0 && (
          <GridContainer
            ref={this.gridContainer}
            data={this.state.data || []}
            columnDefs={this.columns}
            menu={menu}
            gridConfig={{
              getRowNodeId: (data: IVersionHistoryInfo) => {
                return data.index;
              },
              onGridReady: () => {
                this.gridContainer.current.GridApi.sizeColumnsToFit();
              },
              domLayout: "autoHeight",
            }}
            downloadConfig={{
              customDownload: () => {
                this.downloadReports();
              },
              enabled: true,
            }}
          />
        )}
      </div>
    );
  }

  private download = (fileName: string, content: Blob): void => {
    if (window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(content, fileName);
    } else {
      // Chrome
      const element: HTMLAnchorElement = document.createElement("a");
      const url: string = window.URL.createObjectURL(content);
      element.setAttribute("href", url);
      element.setAttribute("download", fileName);
      element.style.display = "none";
      document.body.appendChild(element);
      element.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(element);
    }
  };

  private downloadReports = async (): Promise<void> => {
    const params = {
      allColumns: false,
      fileName: "version_history.csv",
    };

    try {
      const data: string = this.gridContainer.current.GridApi.getDataAsCsv(
        params
      );
      const blob: Blob = new Blob([data], {
        type: "text/csv;charset=utf-8;",
      });
      this.download(params.fileName, blob);
    } catch (ex) {
      console.log(ex);
    }
  };
}
