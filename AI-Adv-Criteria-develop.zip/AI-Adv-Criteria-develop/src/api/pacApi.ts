import axios from "axios";
import { updateConfig, handle401 } from "./_apiConfigHelper";

const pacApi = axios.create({
  baseURL: process.env.PAC_API,
});

pacApi.interceptors.request.use((config) => {
  let configuration = config;
  configuration = updateConfig(configuration);
  return configuration;
});

pacApi.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    const status = error.response ? error.response.status : null;
    if (status === 401) {
      // will loop if refreshToken returns 401
      return handle401(error);
    }
    return Promise.reject(error);
  }
);

//temp code for testing
export const pacDevApi = axios.create({
    baseURL: process.env.PAC_DEV_API,
});

pacDevApi.interceptors.request.use((config) => {
    let configuration = config;
    configuration = updateConfig(configuration);
    return configuration;
});
////

export default pacApi;
