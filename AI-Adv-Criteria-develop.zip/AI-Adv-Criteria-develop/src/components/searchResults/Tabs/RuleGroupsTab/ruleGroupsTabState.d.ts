import { ICurrentState } from "@monsantoit/ui-react-ap-rules/dist/CriteriaCreation/ICriteriaCreationProps";

export interface IRuleGroupsTabState {
  componentState: ICurrentState;
}
