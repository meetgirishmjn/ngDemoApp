// import {
//  IConfigurationTemplate,
//  IConfigField,
//  IConfigSection,
//  IConfigFieldRow,
//  FieldTypes
// } from "./models";

// export default function configTemplateJsonParser(
//  data: IConfigJsonRes
// ): IConfigurationTemplate {
//  const template: IConfigurationTemplate = {
//    version: data.version,
//    sections: []
//  };
//  data.configurationTemplate.tabs.forEach((tab, tabIndex) => {
//    const sectionKey = `section ${tabIndex + 1}`;
//    const section: IConfigSection = {
//      key: sectionKey,
//      title: tab.display,
//      tooltip: tab.TOOLTIP,
//      fieldRows: [],
//      hasRequiredField: false
//    };

//    const ignoreKeys = ["rules"];

//    // fields
//    Object.keys(tab).forEach(key => {
//      if (!ignoreKeys.includes(key) && isObject(tab[key])) {
//        const fieldObj = tab[key];

//        const field = fieldParse(key, fieldObj);

//        if (field.isComposite && !field.isReferenceRecursive) {
//          const compositeFields = readFields(fieldObj);
//          // create a new row for array Description
//          const fieldRow: IConfigFieldRow = {
//            key: "",
//            title: fieldObj.display,
//            tooltip: fieldObj.TOOLTIP,
//            fields: compositeFields
//          };
//          section.fieldRows.push(fieldRow);
//        } else if (fieldObj.arrayDescription) {
//          const arrayDescFields = readFields(fieldObj.arrayDescription);
//          if (arrayDescFields.length) {
//            // create a new row for array Description
//            const fieldRow: IConfigFieldRow = {
//              key: "",
//              title: fieldObj.display,
//              tooltip: fieldObj.TOOLTIP,
//              fields: arrayDescFields
//            };
//            section.fieldRows.push(fieldRow);
//          }
//        } else {
//          // create new row
//          const fieldRow: IConfigFieldRow = {
//            key: "", // key will be outside loop
//            title: null,
//            tooltip: null,
//            fields: []
//          };

//          const field = fieldParse(key, fieldObj);
//          fieldRow.fields.push(field);
//          section.fieldRows.push(fieldRow);
//        }
//      }
//    });

//    // set row key
//    section.fieldRows.forEach((r, i) => (r.key = `row ${i + 1}`));

//    section.hasRequiredField = checkRequiredField(section);
//    template.sections.push(section);
//  });
//  return template;
// }

// const checkRequiredField = (section: IConfigSection): boolean => {
//  let flag = false;
//  for (const row of section.fieldRows) {
//    const match = row.fields.find(f => f.isRequired);
//    if (match) {
//      flag = true;
//    }
//    if (flag === true) {
//      break;
//    }
//  }
//  return flag;
// };

// const isObject = (obj: any): boolean => {
//  if (!obj) {
//    return false;
//  }

//  if (obj instanceof Array) {
//    return false;
//  }

//  return typeof obj === "object";
// };

// const readFields = (obj: any): IConfigField[] => {
//  const fields: IConfigField[] = [];

//  Object.keys(obj).forEach(key => {
//    if (isObject(obj[key])) {
//      const fieldObj = obj[key];
//      const field = fieldParse(key, fieldObj);
//      fields.push(field);
//    }
//  });

//  return fields;
// };

// const fieldParse = (key: string, fieldRes: IFieldJsonRes): IConfigField => {
//  const validators = fieldRes.VALIDATORS || [];

//  const field: IConfigField = {
//    key,
//    value: fieldRes.value ? fieldRes.value : "",
//    dataType: FieldTypes.Text,
//    display: fieldRes.display,
//    tooltip: fieldRes.TOOLTIP,
//    isReadOnly: fieldRes.READONLY === true,
//    isRequired: validators.find(o => o.NAME === "REQUIRED") ? true : false,
//    isComposite: fieldRes.type === "COMPOSITE",
//    isReferenceRecursive: isObject(fieldRes["REFERENCE-RECURSIVE"]),
//    isNumeric: false,
//    onChangeArguments: fieldRes.onChangeArguments
//      ? fieldRes.onChangeArguments
//      : undefined
//  };

//  if (field.isReferenceRecursive) {
//  }

//  validators.forEach(val => {
//    switch (val.NAME) {
//      case "NUMBER":
//        field.dataType = FieldTypes.Number;
//        field.isNumeric = true;
//        break;
//      case "INTEGER":
//        field.dataType = FieldTypes.Integer;
//        field.isNumeric = true;
//        break;
//      case "POSITIVE_INTEGER":
//        field.dataType = FieldTypes.PositiveInteger;
//        field.isNumeric = true;
//        break;
//      case "PERCENT":
//        field.dataType = FieldTypes.Percentage;
//        field.isNumeric = true;
//        break;
//      case "EMAIL":
//        field.dataType = FieldTypes.Email;
//        break;
//      case "NUMBER_RANGE":
//        field.dataType = FieldTypes.NumberRange;
//        field.isNumeric = true;
//        break;
//      case "PATTERN":
//        break;
//      case "MIN":
//        const minValue = this.readValidationArgument(val, 0);
//        if (minValue !== null) {
//          field.minValue = +minValue;
//        }
//        break;
//      case "MAX":
//        const maxValue = this.readValidationArgument(val, 0);
//        if (maxValue !== null) {
//          field.maxValue = +maxValue;
//        }
//        break;
//      case "MIN_LENGTH":
//        const minLength = this.readValidationArgument(val, 0);
//        if (minLength !== null) {
//          field.minLength = +minLength;
//        }
//        break;
//      case "MAX_LENGTH":
//        const maxLength = this.readValidationArgument(val, 0);
//        if (maxLength !== null) {
//          field.maxLength = +maxLength;
//        }
//        break;
//    }
//  });

//  if (field.dataType === FieldTypes.Text) {
//    field.hideIcon = true;
//  }

//  return field;
// };

// const readValidationArgument = (
//  validator: IFieldValidator,
//  argIndex = 0
// ): any | null => {
//  if (
//    validator &&
//    validator.ARGUMENTS &&
//    argIndex < validator.ARGUMENTS.length
//  ) {
//    return validator.ARGUMENTS[0];
//  }
//  return null;
// };
// export interface IConfigJsonRes {
//  id: number;
//  crop: string;
//  model: string;
//  version: number;
//  configurationTemplate: {
//    tabs: any[];
//  };
// }

// export interface IArgs {
//  derivedFieldName: string;
// }

// export interface IOnChangeArgs {
//  operation: string;
//  arguments: IArgs;
// }

// export interface IFieldJsonRes {
//  value: string;
//  display: string;
//  TOOLTIP?: string;
//  READONLY?: boolean;
//  VALIDATORS: IFieldValidator[];
//  type?: string;
//  onChangeArguments: IOnChangeArgs;
// }

// export interface IFieldValidator {
//  NAME: string;
//  ARGUMENTS: any[];
// }
