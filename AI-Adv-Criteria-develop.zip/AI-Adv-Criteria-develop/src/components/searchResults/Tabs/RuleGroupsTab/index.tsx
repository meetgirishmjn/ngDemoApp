import React, { Component } from "react";
import "./ruleGroupsTab.scss";
import { CriteriaCreation } from "@monsantoit/ui-react-ap-rules";
import { IRuleGroupsTabProps } from "./ruleGroupsTabProps";
import { IRuleGroupsTabState } from "./ruleGroupsTabState";
import _ from "lodash";

export default class RuleGroupsTab extends Component<
  IRuleGroupsTabProps,
  IRuleGroupsTabState
> {
    constructor(props: IRuleGroupsTabProps) {
        super(props);
        this.state = {
            componentState: props.componentState,
        };
    }

    public componentWillReceiveProps(nextProps: IRuleGroupsTabProps) {
        if (!_.isEqual(nextProps.componentState, this.state.componentState)) {
            this.setState({ componentState: nextProps.componentState });
        }
    }

  checkIfDisabled = () => {
    const { hasEntitlements, selectedVersion } = this.props;

    if(hasEntitlements){      
      if(selectedVersion.isInProgress || selectedVersion.isLocked){
        return true;
      }
      return false;
    }   
    else return true;
  }

  public render() {
    const { selectedParams, selectedVersion } = this.props;
    return (
      <div className="rule-groups-container">
        <CriteriaCreation
                key={`${selectedVersion.analyseId}_${selectedVersion.version}`}
                horizonServices={this.props.horizonServices}
                crop={selectedParams.Crop.value}
                harvestYear={parseInt(selectedParams.Year, 10)}
                region={selectedParams.Region.value}
                harvestType={selectedParams.HarvestType.key}
                market={selectedParams.Market.value}
                subMarket={selectedParams.SubMarket.key}
                productStage={selectedParams.ProductStage.value}
                trait={selectedParams.Trait.key === "-1" ? "" : selectedParams.Trait.value}
                decisionEngine={selectedParams.DecisionEngine.value}
                onRuleGroupsModified={this.props.onRuleGroupsModified}
                analysisId={selectedVersion.analyseId}
                versionId={selectedVersion.version.toString()}
                onStateModified={this.props.onStateModified}
                isDisabled={this.checkIfDisabled()}
                componentState={this.state.componentState}
        />
      </div>
    );
  }
}
