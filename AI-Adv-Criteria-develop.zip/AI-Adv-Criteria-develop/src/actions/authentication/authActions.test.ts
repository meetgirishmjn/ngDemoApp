import thunk from "redux-thunk";
import configureMockStore from "redux-mock-store";
import MockAdapter from "axios-mock-adapter";
import authApi from "../../api/authApi";
import { authenticate } from "./authActions";

const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);
const mockResponse = {
  access_token: "x-token-1234",
  "user-id": "xyz",
};

describe("auth actions", () => {
  it("should disptach AUTHENTICATION_SUCCESS after succesfully authenticates", async () => {
    const mock = new MockAdapter(authApi);
    mock.onGet("/auth-token-info").reply(200, mockResponse);
    const expectedActions = [
      {
        type: "AUTHENTICATION_SUCCESS",
        payload: {
          isAuthenticated: true,
          access_token: "x-token-1234",
          user_id: "xyz",
        },
      },
    ];
    const store = mockStore({});
    await store.dispatch(authenticate());
    expect(store.getActions()).toEqual(expectedActions);
  });

  it("should disptach AUTHENTICATION_FAILED after succesfully authenticates", async () => {
    const mock = new MockAdapter(authApi);
    mock.onGet("/auth-token-info").reply(401, null);
    const expectedActions = [
      {
        type: "AUTHENTICATION_FAILED",
        payload: {
          isAuthenticated: false,
          access_token: null,
          user_id: null,
        },
      },
    ];
    const store = mockStore({});
    await store.dispatch(authenticate());
    expect(store.getActions()).toEqual(expectedActions);
  });
});
