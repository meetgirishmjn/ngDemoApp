export interface IConfigApiBaseRes<T> {
  hasError: boolean;
  errorMessage: string;
  errorCode: ConfigApiErrorCodes;
  data: T;
}

export enum ConfigApiErrorCodes {
  UNKNOWN = "UNKNOWN",
  DUPLICATE = "DUPLICATE",
  UNKNOWN_EXCEPTION = "UNKNOWN EXCEPTION",
}

export const ParseConfigApiResponse = <T>(data: any): IConfigApiBaseRes<T> => {
  const result: IConfigApiBaseRes<T> = {
    hasError: true,
    errorMessage: "",
    errorCode: ConfigApiErrorCodes.UNKNOWN,
    data: null,
  };
  try {
    if (!data) {
      return result;
    }

    if (data.errors && data.errors.length) {
      // has error, take first error
      result.errorMessage = data.errors[0].message;
      result.errorCode = data.errors[0].extensions
        ? data.errors[0].extensions.code
        : ConfigApiErrorCodes.UNKNOWN;
    } else {
      // no error
      if (data.data) {
        result.data = data.data[Object.keys(data.data)[0]];
        if (result.data) {
          result.hasError = false;
        }
      }
    }
  } catch (err) {
    result.errorMessage = "Failed to parse api response";
  }

  return result;
};
