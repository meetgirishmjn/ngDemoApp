export { default } from "./home";
