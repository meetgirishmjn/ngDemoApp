import {
  IModelVersion,
  IConfigurationTemplate,
  IVersionHistoryInfo,
  IGraphqlBaseRes,
  GraphqlApiErrorCodes,
} from "./models";
import { Dispatch } from "redux";
import types from "../ActionTypes";
import { getSearchAnalyses } from "../pac/pacActions";
import { each, orderBy, sortBy, cloneDeep } from "lodash";
import {
  configTemplateJsonParser,
  ICriteriaValueRes,
} from "./configTemplateJsonParser";
import { parseGraphqlApiResponse, convertToAnalysisModel } from "./helpers";
import pacApi from "../../api/pacApi";
import { IAnalyses } from "../../models/ISearchAnalyses";
import { IAnalysisVersion, IRun } from "../../models/IAnalysisVersions";
import _ from "lodash";

export const retrieveCriteriaValues = async (
  analysisId: string,
  version: number
): Promise<IGraphqlBaseRes<ICriteriaValueRes>> => {
  let parsedRes = parseGraphqlApiResponse<ICriteriaValueRes>(null);
  const query = `query retrieveCriteriaValue {
                  analysis(id: ${analysisId}, version: ${version}) {
                    id
                    version
                    criteria {
                      name
                      display
                      isRequired
                      datatype
                      group
                      groupHeader
                      value
                      criteriaDefinitionId
                      criteriaDefaultValueId
                      criteriaValueId
                      defaultValue {
                        scope
                        value
                        isActive
                        validator
                      }
                    }
                  }
                }`;

  await pacApi
    .post("/graphql", {
      operationName: "retrieveCriteriaValue",
      query,
    })
    .then((response) => {
      parsedRes = parseGraphqlApiResponse<ICriteriaValueRes>(response.data);
      if (!parsedRes.hasError) {
        return parsedRes.data;
      }
    })
    .catch((err) => {
      console.log(err);
      parsedRes.errorMessage = "failed to load CriteriaValues";
      // Logger.logError('Failed to get advConfigQuery', getUserId(), getErrorMessage(err, process.env.ADV_CONFIG_API, '/graphql'));
    });
  return parsedRes;
};

export const getConfigTemplate = async (
  analysisId: string,
  version: number
): Promise<IConfigurationTemplate> => {
  const analysisRes = await retrieveCriteriaValues(analysisId, version);
  if (analysisRes.hasError) {
    throw analysisRes.errorMessage;
  }

  const template = configTemplateJsonParser(analysisRes.data);
  return template;
};

export const getModelVersions = async (
    crop: string,
    year: number,
    region: string,
    harvestType: string,
    market: string
): Promise<IModelVersion[]> => {
    const analysises = await getSearchAnalyses(
        crop,
        year,
        region,
        harvestType,
        market
    );
    const results = (analysises || []).map((analysisRes) =>
        convertToAnalysisModel(analysisRes)
    );

    //sort by name and then by version
    let sortedResults: IModelVersion[] = [];

    const dictionary = _.groupBy(results, (o) => o.name);
    const keys = Object.keys(dictionary);
    orderBy(keys, (o) => o.toLowerCase()).reverse().forEach(key => {
        const items = dictionary[key];
        sortedResults = [...sortedResults, ...orderBy(items, (o) => o.version, "desc")];
    });
    
    return sortedResults;
};

export const createAnalysisVersionFromSource = async (
  sourceAnalysisId: number,
  sourceAnalysisVersion: number
): Promise<IGraphqlBaseRes<IModelVersion>> => {
  const result: IGraphqlBaseRes<IModelVersion> = {
    hasError: false,
    errorCode: GraphqlApiErrorCodes.UNKNOWN,
    errorMessage: "",
    data: null,
  };

  const graphQuery = {
    query: `mutation createAnalysisVersionFromSource { createAnalysisVersion(input: {sourceId: ${sourceAnalysisId}, sourceAnalysisVersion: ${sourceAnalysisVersion} })
                    { analysis { id  name version lastSuccessfulRun {
                    id
                    isFinished
                    currentStatus
                    finalizedStatus
                }
                lastRun{
                          id
                          isFinished
                          currentStatus
                          finalizedStatus
                    } } } }`,
  };
  await pacApi
    .post("/graphql", graphQuery)
    .then((response) => {
      if ((response.data.errors || []).length) {
        result.hasError = true;
        result.errorMessage = response.data.errors[0].message;
      } else {
        const analysis =
          response.data &&
          (response.data.data.createAnalysisVersion.analysis as IAnalyses);
        result.data = convertToAnalysisModel(analysis);
      }
    })
    .catch((error) => {
      console.log(error);
      result.hasError = true;
      result.errorMessage = "Unknown error occured on create analysis version";
    });

  return result;
};

export const saveCriteriaValues = async (
  criteriaDefaultValueId: number,
  analysisId: string,
  analysisVersion: number,
  value: string
): Promise<IGraphqlBaseRes<any>> => {
  const result: any = {
    hasError: false,
    errorCode: GraphqlApiErrorCodes.UNKNOWN,
    errorMessage: "",
    data: null,
  };

  const stringifiedValue = JSON.stringify(value);

  const graphQuery = {
    query: `mutation createCriteriaValue {createCriteriaValue(input: {criteriaDefaultValueId: ${criteriaDefaultValueId}, analysisId:${analysisId}, analysisVersion:${analysisVersion}, value: ${stringifiedValue} }){criteriaValue{id
      criteriaDefaultValueId
      value }}}`,
  };

  await pacApi
    .post("/graphql", graphQuery)
    .then((response) => {
      if ((response.data.errors || []).length) {
        result.hasError = true;
        result.errorMessage = response.data.errors[0].message;
      } else {
        result.data = response.data.data.createCriteriaValue.criteriaValue;
      }
    })
    .catch((error) => {
      console.log(error);
      result.hasError = true;
      result.errorMessage =
        "Unknown error occured while saving criteria values.";
    });

  return result;
};

export const updateCriteriaValues = async (
  id: number,
  reactivate: boolean,
  value: string
) => {
  const result: any = {
    hasError: false,
    errorCode: GraphqlApiErrorCodes.UNKNOWN,
    errorMessage: "",
    data: null,
  };

  const stringifiedValue = JSON.stringify(value);

  const graphQuery = {
    query: `mutation updateCriteriaValue {updateCriteriaValue(input: {id: ${id}, reactivate: ${reactivate}, value: ${stringifiedValue}}){criteriaValue{id
      criteriaDefaultValueId
      value }}}`,
  };

  await pacApi
    .post("/graphql", graphQuery)
    .then((response) => {
      if ((response.data.errors || []).length) {
        result.hasError = true;
        result.errorMessage = response.data.errors[0].message;
      } else {
        console.log(response);
      }
    })
    .catch((error) => {
      console.log(error);
      result.hasError = true;
      result.errorMessage =
        "Unknown error occured while updating criteria values.";
    });
  return result;
};

export const getVersionHistoryData = async (
  analyseId: string
): Promise<IVersionHistoryInfo[]> => {
  let data: IVersionHistoryInfo[] = [];
  const graphQuery = {
    query: `query allSuccessfulAnalysisVersions {
      analyses(id: ${analyseId}, allVersions: true, mustHaveSuccessfulRun: false, inactive: true) {
        id
        name
        version
        createUser
        modifiedDate
        modifiedUser
        description
        runs {
          id
          currentStatus
          createdOn
          finalizedDate
          analysisVersion
          isUsedForAdvancements
        }
      }
    }`,
  };
  try {
    const response = await pacApi.post("/graphql", graphQuery);
    const allAnalysesVersions: IAnalysisVersion[] =
      response &&
      response.data &&
      response.data.data &&
      (response.data.data.analyses as IAnalysisVersion[]);
    if (allAnalysesVersions) {
      each(allAnalysesVersions, (analyses: IAnalysisVersion, index: number) => {
        let analysesVersionData: IVersionHistoryInfo = {
          index,
          version: analyses.version,
          dateModified: analyses.modifiedDate,
          reportName: analyses.name,
          userName: analyses.createUser,
        };
        each(analyses.runs, (run: IRun, index: number) => {
          analysesVersionData = cloneDeep(analysesVersionData);
          analysesVersionData.index = index;
          analysesVersionData.status = run.currentStatus;
          analysesVersionData.dateLastRun = run.createdOn;
          analysesVersionData.runId = run.id;
          analysesVersionData.comments = "";
          analysesVersionData.savedForAdv = run.isUsedForAdvancements;
          data.push(analysesVersionData);
        });
        // push only analyses name, version etc., if there's no runs
        analyses.runs.length === 0 && data.push(analysesVersionData);
      });
    }
    data = sortBy(data, "runId").reverse();
  } catch (err) {
    data = null;
    console.log(err);
  }
  return data;
};

export const updateVersionHistoryComments = async (
  crop: string,
  region: string,
  harvestType: string
): Promise<boolean> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve(true);
    }, 700);
  });
};

export const onSaveButtonClick = (customKey: string) => {
  return (dispatch: Dispatch) => {
    dispatch({
      type: types.SAVE_CLICK,
      payload: `save-${new Date().getTime()}`,
    });
  };
};

export const onAnalysisRunSuccess = (analysis: IModelVersion) => {
    return (dispatch: Dispatch) => {
        dispatch({
            type: types.ANALYSIS_RUN_SUCCESS,
            payload: analysis,
        });
    };
};

export const enableRunButton = (isValid: boolean) => {
  return (dispatch: Dispatch) => {
    dispatch({
      type: types.ENABLE_RUN_BUTTON,
      payload: isValid,
    });
  };
}
