import { Dispatch } from "redux";
import _ from "lodash";
import { ApiService } from "@monsantoit/new-horizon-ui";
import configuration from "../../../node_modules/@monsantoit/new-horizon-ui/dist/models/configuration";
import IRootStore from "../../store/IRootStore";
import types, { PipelineAction } from "../ActionTypes";

export const VELOCITY_CACHE_NAMESPACE = "adv-criteria";

export const VELOCITY_CONFIG: Partial<configuration> = {
  VELOCITY_CACHE_API_URL: `${process.env.USER_PREF_API}`,
  TOKEN_INFO: "Advancement product_OAuthTokenInfo",
  APP_ID: "Advancement criteria",
  VELOCITY_URL: `${process.env.TOKEN_URL}/auth-token-info`,
};

export function saveUserPreferences(
  requestData: IPipeline,
  horizonServices: any
): (
  dispatch: Dispatch<PipelineAction>,
  getState: () => IRootStore
) => Promise<void> {
  return async (
    dispatch: Dispatch<PipelineAction>,
    getState: () => IRootStore
  ) => {
    // Save if the parameters are changed in selections
    if (!_.isEqual(getState().userPreferences.userPreferences, requestData)) {
      // update the selected parameters in store and then save it to velocity cache
      dispatch({
        type: types.GET_USER_PREFERENCES_SUCCESS,
        payload: requestData,
      });
      ApiService.setVelocityCacheData(
        "adv-criteria",
        `appConfig-${getState().auth.user_id}-${process.env.ENVIRONMENT}`,
        requestData,
        VELOCITY_CONFIG
      )
        .then((response) => {
          horizonServices.toast.success("User Preferences saved successfully.");
        })
        .catch(() => {
          dispatch({ type: types.GET_USER_PREFERENCES_ERROR });
          horizonServices.toast.error("User Preferences could not be saved.");
        });
    }
  };
}

export function getUserPreferences(
  horizonServices: any
): (
  dispatch: Dispatch<PipelineAction>,
  getState: () => IRootStore
) => Promise<void> {
  return async (
    dispatch: Dispatch<PipelineAction>,
    getState: () => IRootStore
  ) => {
    dispatch({ type: types.LOADING_USER_PREFERENCES });
    ApiService.getVelocityCacheData(
      "adv-criteria",
      `appConfig-${getState().auth.user_id}-${process.env.ENVIRONMENT}`,
      VELOCITY_CONFIG
    )
      .then((response) => {
        dispatch({
          type: types.GET_USER_PREFERENCES_SUCCESS,
          payload: response,
        });
      })
      .catch(() => {
        dispatch({ type: types.GET_USER_PREFERENCES_ERROR });
        horizonServices.toast.error("Fetching User Preferences failed.");
      });
  };
}

export const saveToVelocityCache = async (
  userId: string,
  key: string,
  data: any
): Promise<boolean> => {
  let flag = false;
  try {
    const response = await ApiService.setVelocityCacheData(
      VELOCITY_CACHE_NAMESPACE,
      `${key}-${userId}-${process.env.ENVIRONMENT}`,
      data,
      VELOCITY_CONFIG
    );
    flag = true;
  } catch (err) {
    console.log("failed to saveToCache", err);
  }
  return flag;
};

export const getFromVelocityCache = async <T>(
  userId: string,
  key: string
): Promise<T> => {
  let result: T = null;
  try {
    const response = await ApiService.getVelocityCacheData(
      VELOCITY_CACHE_NAMESPACE,
      `${key}-${userId}-${process.env.ENVIRONMENT}`,
      VELOCITY_CONFIG
    );
    result = response;
  } catch (err) {
    console.log("failed to getFromCache", err);
  }
  return result;
};
