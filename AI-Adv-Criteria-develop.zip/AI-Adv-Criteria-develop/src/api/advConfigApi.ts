import axios from "axios";
import { updateConfig, handle401 } from "./_apiConfigHelper";

const advConfigApi = axios.create({
  baseURL: process.env.ADV_CONFIG_API,
});

advConfigApi.interceptors.request.use((config) => {
  const configRes = updateConfig(config);
  return configRes;
});

advConfigApi.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    const status = error.response ? error.response.status : null;
    if (status === 401) {
      // will loop if refreshToken returns 401
      return handle401(error);
    }
    return Promise.reject(error);
  }
);

export default advConfigApi;
