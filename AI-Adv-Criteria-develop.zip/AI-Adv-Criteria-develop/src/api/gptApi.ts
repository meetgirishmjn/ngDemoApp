import axios from "axios";
import { updateConfig, handle401 } from "./_apiConfigHelper";

const gptApi = axios.create({
  baseURL: process.env.GPT_API,
});

gptApi.interceptors.request.use((config) => {
  let configuration = config;
  configuration = updateConfig(configuration);
  return configuration;
});

gptApi.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    const status = error.response ? error.response.status : null;
    if (status === 401) {
      // will loop if refreshToken returns 401
      return handle401(error);
    }
    return Promise.reject(error);
  }
);

export default gptApi;
