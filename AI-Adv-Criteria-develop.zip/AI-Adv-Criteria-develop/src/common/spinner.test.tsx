import Spinner from "./spinner";

describe("test spinner", () => {
  it("spinner div", () => {
    const spinner = Spinner();
    expect(spinner.props.id).toBe("loading-bar-spinner");
  });
});
