const RouterConstants = {
  BASE_URL: process.env.BASE_PATH,
  HOME: "/",
  RESULTS: "/searchResults",
  LOADING_POPS: "/loadingPops",
  CONFIGURE_DATA: "/configureData",
};

export default RouterConstants;
