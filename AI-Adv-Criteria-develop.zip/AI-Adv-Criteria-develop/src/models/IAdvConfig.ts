export interface IAdvConfig {
  advConfigId: number;
  crop: string;
  year: number;
  region: string;
  harvestType: string;
  market: string;
  advConfigSubsets: IAdvConfigSubset[];
}

export interface IAdvConfigSubset {
  id: number;
  pipelineTrait: string;
  subMarket: string;
  productStageGroup: IProductStageGroup;
}

export interface IProductStageGroup {
  id: number;
  productStageGroupName: string;
  productStageGroupMembers: IProductStageGroupMembers[];
}

export interface IProductStageGroupMembers {
  id: number;
  productStage: string;
}

export interface IConfigDataRequistion {
  advConfigSubset: IAdvConfigSubset;
  requistions: IRequisition[];
}

export interface IRequisition {
  configDataRequisitionId: number;
  // dataProviderId: number;
  dataProviderName: string;
  requisitionItems: IRequisitionItem[];
  fulfillments: IFulfillment[];
}

export interface IRequisitionItem {
  configDataRequisitionItemId: number;
  dataProviderAttributeName: string;
  value: string;
  refActive: boolean;
}

export interface IFulfillment {
  id: number;
  productStageGroupMemberId: number;
  externalId: number;
  externalVersion: number;
  modifiedReason: string;
  refActive: true;
}

export interface IQueryAdvConfigResponse {
  advConfig: IAdvConfig;
  configDataRequisitions: IConfigDataRequistion[];
}

export interface ITraitsData {
  traits: ITraitAndCalc[];
}

export interface ITraitAndCalc {
  calc: IName;
  trait: IName;
}

export interface IName {
  name: string;
}
