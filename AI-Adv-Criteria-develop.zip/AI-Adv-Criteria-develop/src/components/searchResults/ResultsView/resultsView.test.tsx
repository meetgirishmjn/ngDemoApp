import React from "react";
import { shallow } from "enzyme";
import ResultsView from ".";

const selectedParams = {
    Crop: {id: 65601536, key: "CORN", value: "Corn", cropId: 65601536},
    DecisionEngine: {key: "EVA-0.1.23", value: "EVA-0.1.23"},
    HarvestType: {id: 81985536, key: "G", value: "Grain"},
    Market: {id: 32530, key: "RM110", value: "RM110"},
    ProductStage: {key: "10003", value: "PS1"},
    Region: {id: 100001, key: "NA", value: "NA"},
    StageType: {key: "PCM", value: "PCM"},
    SubMarket: {id: -1, key: "", value: "All Sub Markets"},
    Trait: {key: "-1", value: " All Traits"},
    Year: "2020"
}
const selectedTab = "RuleGroups";
const selectedVersion = {
    analyseId: "10028",
    isInProgress: false,
    isLocked: true,
    name: "eva-na-test2",
    uid: "10028_eva-na-test2_2",
    version: 2,
    versionDesc: "eva-na-test2_v2",
    runs:[]
}
const tabs = [
    {name: "Graphs", title: "Graphs"}
]
const userId = "default";


describe("Results View", () => {
    it('test render results view tab', async () => {
        const wrapper = await shallow(<ResultsView
            selectedParams={selectedParams}
            selectedVersion={selectedVersion}
            selectedTab={selectedTab}
            tabs={tabs}
            userId={userId}
            horizonServices={{}}
            velocityCache={null}
        />);
        expect(wrapper.find('TabsContainer').exists()).toBeTruthy();
        expect(wrapper.find('Tab')).toHaveLength(4);
    })
})