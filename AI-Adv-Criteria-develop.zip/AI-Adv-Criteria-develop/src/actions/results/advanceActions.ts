import axios from "axios";
import { each } from "lodash";
import pacResultsApi from "../../api/pacResultsApi";
import pacApi from "../../api/pacApi";
import { IResultData, IAnalysisData } from "../../models/IResults";
import { IModelVersion } from "../criteria/models";
import { ComponentResolver } from "ag-grid/dist/lib/components/framework/componentResolver";

export const getRunId = async (analysisId: string, version: number): Promise<IAnalysisData> => {
  // sample Query
  // `{analysis(id:6517,mustHaveSuccessfulRun:true){ id name lastSuccessfulRun{id isFinished}}}`
  let analysisData: IAnalysisData = null;
  const graphQuery = {
    query: `{analysis(id:${analysisId}, version:${version}, mustHaveSuccessfulRun:true){ id name lastSuccessfulRun{id isFinished}}}`,
  };
  await pacApi
    .post("/graphql", graphQuery)
    .then((response) => {
      analysisData = response.data && (response.data.data as IAnalysisData);
    })
    .catch((error) => console.log(error));
  return analysisData;
};

export const getPrescData = async (runId: number) => {
  let columnData: IResultData = null;
  try {
    const prescData = await getColumnData(runId, "PRESC");
    columnData = prescData.data as IResultData;
  } catch (error) {
    console.log(error);
  }
  return columnData;
};

export const getBlupsData = async (runId: number, columnNames: string[]) => {
  const allBlupRequests: any[] = [];
  const response: any = {};
  each(columnNames, (name: string) => {
    allBlupRequests.push(getColumnData(runId, name));
  });
  try {
    const responses = await axios.all(allBlupRequests);
    each(responses, (resp: any) => {
      response[resp.config.params.columnName] = resp.data;
    });
  } catch (err) {
    console.log(err);
  }
  return response;
};

export const getColumnData = (runId: number, columnName: string) => {
  const graphQuery = {
    query: `query filter {  run(runid: \"${runId}\", columns:[\"${columnName}\"])  { runid  keys {  key { name value  } values { column numvalue strvalue  uom   }    }  }}`,
    operationName: "filter",
  };
  return pacResultsApi.post("/graphql", graphQuery, {
    params: {
      columnName,
    },
  });
};
