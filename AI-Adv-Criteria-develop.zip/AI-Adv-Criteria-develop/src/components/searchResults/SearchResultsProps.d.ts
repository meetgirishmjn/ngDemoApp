import { IEntitlements } from "../../models/IEntitlementGroups";
import { IModelVersion } from "../../actions/criteria/models";

interface ISearchResultsProps {
    userId: string;
    horizonServices: any;
    selectedParams: IPipeline;
    getUserPreferences: (horizonServices: any) => void;
    entitlements?: IEntitlements[];
    analysisInRun: IModelVersion;
    deleteBlupsData: () => void;
}

export interface ITabItem {
  name: string;
  title: string;
}

export default ISearchResultsProps;
