import React from "react";
import { shallow, mount } from "enzyme";
import VersionSelector from ".";
import { IModelVersion } from "../../../actions/criteria/models";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import thunk from "redux-thunk";
import configureMockStore from "redux-mock-store";
import { ModalDialog } from "@monsantoit/ui-react-modal-dialog";
import Modal from "react-bootstrap4-modal";

const mockStore = configureMockStore([thunk]);
const store = mockStore({});

describe("VersionSelectorComponent", () => {
  it("should render with default props", () => {
    const onChanged = jest.fn();

    const wrapper = shallow(
      <BrowserRouter>
        <Provider store={store}>
          <VersionSelector
            onVersionSelectionChanged={onChanged}
            userId={"TestUser"}
            store={store}
          />
        </Provider>
      </BrowserRouter>
    );
    expect(wrapper.find(".version-card").length).toBe(0);
  });

  it("should call version on change", () => {
      const mockVersionData: IModelVersion[] = [
          {
              uid: "1",
              analyseId: "1",
              name: "test-1",
              version: 1,
              versionDesc: "Version 1",
              isLocked: false,
              isInProgress: false,
              runs:[]
      },
      {
        uid: "2",
        analyseId: "2",
        name: "test-2",
        version: 2,
        versionDesc: "Version 2",
        isLocked: true,
          isInProgress: false,
          runs: []
      },
    ];

    const onChanged = jest.fn();

    const wrapper = mount(
      <BrowserRouter>
        <Provider store={store}>
          <VersionSelector
            onVersionSelectionChanged={onChanged}
            userId={"TestUser"}
            store={store}
          />
        </Provider>
      </BrowserRouter>
    );

    wrapper.setState({
      selectedVersion: mockVersionData[0],
      modelVersions: mockVersionData,
      isModelVersionsLoading: false,
    });

    wrapper.find(".dropdown-item").first().simulate("click");
    expect(onChanged).toHaveBeenCalledTimes(1);
  });

  it("should render modal popup on btn click", () => {
    const onChanged = jest.fn();

    const wrapper = mount(
      <BrowserRouter>
        <Provider store={store}>
          <VersionSelector
            onVersionSelectionChanged={onChanged}
            userId={"TestUser"}
            store={store}
          />
        </Provider>
      </BrowserRouter>
    );

    const modal = wrapper.find(ModalDialog);

    wrapper.find(".new-ver").simulate("click");
    expect(modal).toHaveLength(1);
  });

  it("should render Refresh Analysis modal pop-up on button click", () => {
    const onChanged = jest.fn();

    const wrapper = mount(
      <BrowserRouter>
        <Provider store={store}>
          <VersionSelector
            onVersionSelectionChanged={onChanged}
            userId={"TestUser"}
            store={store}
          />
        </Provider>
      </BrowserRouter>
    );

    const modal = wrapper.find(Modal);
    const container = wrapper.find(Modal);
    expect(container.length).toEqual(1);
    container.simulate("click");
    expect(modal).toHaveLength(1);
  });
});
